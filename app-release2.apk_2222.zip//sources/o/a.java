package o;

import io.flutter.embedding.engine.FlutterJNI;
import y.b;

public interface a {
    String a(int i2, String str);

    void b(int i2, String str);

    boolean c(int i2, String str);

    void d(FlutterJNI flutterJNI);

    void destroy();

    void e(b bVar);
}
