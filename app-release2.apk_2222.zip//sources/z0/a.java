package z0;

import h0.g;
import kotlin.jvm.internal.e;
import o0.p;

public final class a implements g.b {

    /* renamed from: f  reason: collision with root package name */
    public static final C0037a f1494f = new C0037a((e) null);

    /* renamed from: d  reason: collision with root package name */
    public final Throwable f1495d;

    /* renamed from: e  reason: collision with root package name */
    private final g.c<?> f1496e = f1494f;

    /* renamed from: z0.a$a  reason: collision with other inner class name */
    public static final class C0037a implements g.c<a> {
        private C0037a() {
        }

        public /* synthetic */ C0037a(e eVar) {
            this();
        }
    }

    public a(Throwable th) {
        this.f1495d = th;
    }

    public <R> R fold(R r2, p<? super R, ? super g.b, ? extends R> pVar) {
        return g.b.a.a(this, r2, pVar);
    }

    public <E extends g.b> E get(g.c<E> cVar) {
        return g.b.a.b(this, cVar);
    }

    public g.c<?> getKey() {
        return this.f1496e;
    }

    public g minusKey(g.c<?> cVar) {
        return g.b.a.c(this, cVar);
    }

    public g plus(g gVar) {
        return g.b.a.d(this, gVar);
    }
}
