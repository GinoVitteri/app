package z0;

import f0.k;
import f0.q;
import h0.g;
import h0.h;
import kotlin.coroutines.jvm.internal.d;
import kotlin.coroutines.jvm.internal.e;
import kotlin.jvm.internal.j;
import o0.p;
import v0.o1;

public final class c<T> extends d implements y0.c<T> {

    /* renamed from: d  reason: collision with root package name */
    public final y0.c<T> f1499d;

    /* renamed from: e  reason: collision with root package name */
    public final g f1500e;

    /* renamed from: f  reason: collision with root package name */
    public final int f1501f;

    /* renamed from: g  reason: collision with root package name */
    private g f1502g;

    /* renamed from: h  reason: collision with root package name */
    private h0.d<? super q> f1503h;

    static final class a extends j implements p<Integer, g.b, Integer> {

        /* renamed from: d  reason: collision with root package name */
        public static final a f1504d = new a();

        a() {
            super(2);
        }

        public final Integer a(int i2, g.b bVar) {
            return Integer.valueOf(i2 + 1);
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return a(((Number) obj).intValue(), (g.b) obj2);
        }
    }

    public c(y0.c<? super T> cVar, g gVar) {
        super(b.f1497d, h.f166d);
        this.f1499d = cVar;
        this.f1500e = gVar;
        this.f1501f = ((Number) gVar.fold(0, a.f1504d)).intValue();
    }

    private final void b(g gVar, g gVar2, T t2) {
        if (gVar2 instanceof a) {
            e((a) gVar2, t2);
        }
        e.a(this, gVar);
        this.f1502g = gVar;
    }

    private final Object c(h0.d<? super q> dVar, T t2) {
        g context = dVar.getContext();
        o1.d(context);
        g gVar = this.f1502g;
        if (gVar != context) {
            b(context, gVar, t2);
        }
        this.f1503h = dVar;
        return d.f1505a.h(this.f1499d, t2, this);
    }

    private final void e(a aVar, Object obj) {
        throw new IllegalStateException(f.e("\n            Flow exception transparency is violated:\n                Previous 'emit' call has thrown exception " + aVar.f1495d + ", but then emission attempt of value '" + obj + "' has been detected.\n                Emissions from 'catch' blocks are prohibited in order to avoid unspecified behaviour, 'Flow.catch' operator can be used instead.\n                For a more detailed explanation, please refer to Flow documentation.\n            ").toString());
    }

    public Object emit(T t2, h0.d<? super q> dVar) {
        try {
            Object c2 = c(dVar, t2);
            if (c2 == d.c()) {
                kotlin.coroutines.jvm.internal.h.c(dVar);
            }
            return c2 == d.c() ? c2 : q.f152a;
        } catch (Throwable th) {
            this.f1502g = new a(th);
            throw th;
        }
    }

    public e getCallerFrame() {
        h0.d<? super q> dVar = this.f1503h;
        if (dVar instanceof e) {
            return (e) dVar;
        }
        return null;
    }

    public g getContext() {
        h0.d<? super q> dVar = this.f1503h;
        g context = dVar == null ? null : dVar.getContext();
        return context == null ? h.f166d : context;
    }

    public StackTraceElement getStackTraceElement() {
        return null;
    }

    public Object invokeSuspend(Object obj) {
        Throwable b2 = k.b(obj);
        if (b2 != null) {
            this.f1502g = new a(b2);
        }
        h0.d<? super q> dVar = this.f1503h;
        if (dVar != null) {
            dVar.resumeWith(obj);
        }
        return d.c();
    }

    public void releaseIntercepted() {
        super.releaseIntercepted();
    }
}
