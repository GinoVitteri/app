package z0;

import h0.d;
import h0.g;
import h0.h;

final class b implements d<Object> {

    /* renamed from: d  reason: collision with root package name */
    public static final b f1497d = new b();

    /* renamed from: e  reason: collision with root package name */
    private static final g f1498e = h.f166d;

    private b() {
    }

    public g getContext() {
        return f1498e;
    }

    public void resumeWith(Object obj) {
    }
}
