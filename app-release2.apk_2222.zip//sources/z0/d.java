package z0;

import kotlin.jvm.internal.h;
import kotlin.jvm.internal.n;
import o0.q;
import y0.c;

public final class d {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public static final q<c<Object>, Object, h0.d<? super f0.q>, Object> f1505a = ((q) n.a(a.f1506d, 3));

    /* synthetic */ class a extends h implements q {

        /* renamed from: d  reason: collision with root package name */
        public static final a f1506d = new a();

        a() {
            super(3, c.class, "emit", "emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
        }

        /* renamed from: b */
        public final Object h(c<Object> cVar, Object obj, h0.d<? super f0.q> dVar) {
            return cVar.emit(obj, dVar);
        }
    }
}
