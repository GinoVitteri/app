package f;

public final /* synthetic */ class a {
}
