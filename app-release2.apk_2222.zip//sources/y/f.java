package y;

import m.b;
import z.a;
import z.q;

public class f {

    /* renamed from: a  reason: collision with root package name */
    private String f1283a;

    /* renamed from: b  reason: collision with root package name */
    private String f1284b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f1285c;

    /* renamed from: d  reason: collision with root package name */
    private final a<String> f1286d;

    public f(n.a aVar) {
        this((a<String>) new a(aVar, "flutter/lifecycle", q.f1493b));
    }

    public f(a<String> aVar) {
        this.f1283a = "";
        this.f1284b = "";
        this.f1285c = true;
        this.f1286d = aVar;
    }

    private void g(String str, boolean z2) {
        if (this.f1283a != str || z2 != this.f1285c) {
            String str2 = "AppLifecycleState.resumed";
            if (str != str2) {
                str2 = str;
            } else if (!z2) {
                str2 = "AppLifecycleState.inactive";
            }
            this.f1283a = str;
            this.f1285c = z2;
            if (str2 != this.f1284b) {
                b.f("LifecycleChannel", "Sending " + str2 + " message.");
                this.f1286d.c(str2);
                this.f1284b = str2;
            }
        }
    }

    public void a() {
        g(this.f1283a, true);
    }

    public void b() {
        g("AppLifecycleState.detached", this.f1285c);
    }

    public void c() {
        g("AppLifecycleState.inactive", this.f1285c);
    }

    public void d() {
        g("AppLifecycleState.paused", this.f1285c);
    }

    public void e() {
        g("AppLifecycleState.resumed", this.f1285c);
    }

    public void f() {
        g(this.f1283a, false);
    }
}
