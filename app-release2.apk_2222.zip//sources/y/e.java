package y;

import java.util.HashMap;
import java.util.Map;
import z.h;
import z.i;
import z.p;

public class e {

    /* renamed from: a  reason: collision with root package name */
    public final i f1279a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public b f1280b;

    /* renamed from: c  reason: collision with root package name */
    public final i.c f1281c;

    class a implements i.c {
        a() {
        }

        public void a(h hVar, i.d dVar) {
            if (e.this.f1280b != null) {
                String str = hVar.f1475a;
                str.hashCode();
                if (!str.equals("getKeyboardState")) {
                    dVar.c();
                    return;
                }
                Object hashMap = new HashMap();
                try {
                    hashMap = e.this.f1280b.a();
                } catch (IllegalStateException e2) {
                    dVar.a("error", e2.getMessage(), (Object) null);
                }
                dVar.b(hashMap);
            }
        }
    }

    public interface b {
        Map<Long, Long> a();
    }

    public e(n.a aVar) {
        a aVar2 = new a();
        this.f1281c = aVar2;
        i iVar = new i(aVar, "flutter/keyboard", p.f1490b);
        this.f1279a = iVar;
        iVar.e(aVar2);
    }

    public void b(b bVar) {
        this.f1280b = bVar;
    }
}
