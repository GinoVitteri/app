package y;

import android.view.KeyEvent;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;
import z.a;

public class d {

    /* renamed from: a  reason: collision with root package name */
    public final z.a<Object> f1276a;

    public interface a {
        void a(boolean z2);
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public final KeyEvent f1277a;

        /* renamed from: b  reason: collision with root package name */
        public final Character f1278b;

        public b(KeyEvent keyEvent, Character ch) {
            this.f1277a = keyEvent;
            this.f1278b = ch;
        }
    }

    public d(z.b bVar) {
        this.f1276a = new z.a<>(bVar, "flutter/keyevent", z.d.f1473a);
    }

    private static a.e<Object> b(a aVar) {
        return new c(aVar);
    }

    private Map<String, Object> c(b bVar, boolean z2) {
        HashMap hashMap = new HashMap();
        hashMap.put("type", z2 ? "keyup" : "keydown");
        hashMap.put("keymap", "android");
        hashMap.put("flags", Integer.valueOf(bVar.f1277a.getFlags()));
        hashMap.put("plainCodePoint", Integer.valueOf(bVar.f1277a.getUnicodeChar(0)));
        hashMap.put("codePoint", Integer.valueOf(bVar.f1277a.getUnicodeChar()));
        hashMap.put("keyCode", Integer.valueOf(bVar.f1277a.getKeyCode()));
        hashMap.put("scanCode", Integer.valueOf(bVar.f1277a.getScanCode()));
        hashMap.put("metaState", Integer.valueOf(bVar.f1277a.getMetaState()));
        Character ch = bVar.f1278b;
        if (ch != null) {
            hashMap.put("character", ch.toString());
        }
        hashMap.put("source", Integer.valueOf(bVar.f1277a.getSource()));
        hashMap.put("deviceId", Integer.valueOf(bVar.f1277a.getDeviceId()));
        hashMap.put("repeatCount", Integer.valueOf(bVar.f1277a.getRepeatCount()));
        return hashMap;
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void d(a aVar, Object obj) {
        boolean z2 = false;
        if (obj != null) {
            try {
                z2 = ((JSONObject) obj).getBoolean("handled");
            } catch (JSONException e2) {
                m.b.b("KeyEventChannel", "Unable to unpack JSON message: " + e2);
            }
        }
        aVar.a(z2);
    }

    public void e(b bVar, boolean z2, a aVar) {
        this.f1276a.d(c(bVar, z2), b(aVar));
    }
}
