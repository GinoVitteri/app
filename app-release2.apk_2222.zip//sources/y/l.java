package y;

import androidx.window.R;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import z.h;
import z.i;
import z.p;

public class l {

    /* renamed from: a  reason: collision with root package name */
    private final i f1349a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public g f1350b;

    /* renamed from: c  reason: collision with root package name */
    private final i.c f1351c;

    class a implements i.c {
        a() {
        }

        private void c(h hVar, i.d dVar) {
            try {
                l.this.f1350b.a(((Integer) hVar.b()).intValue());
                dVar.b((Object) null);
            } catch (IllegalStateException e2) {
                dVar.a("error", l.c(e2), (Object) null);
            }
        }

        private void d(h hVar, i.d dVar) {
            i.d dVar2 = dVar;
            Map map = (Map) hVar.b();
            boolean z2 = true;
            boolean z3 = map.containsKey("hybrid") && ((Boolean) map.get("hybrid")).booleanValue();
            ByteBuffer wrap = map.containsKey("params") ? ByteBuffer.wrap((byte[]) map.get("params")) : null;
            if (z3) {
                try {
                    l.this.f1350b.h(new d(((Integer) map.get("id")).intValue(), (String) map.get("viewType"), 0.0d, 0.0d, 0.0d, 0.0d, ((Integer) map.get("direction")).intValue(), d.a.HYBRID_ONLY, wrap));
                } catch (IllegalStateException e2) {
                    dVar2.a("error", l.c(e2), (Object) null);
                    return;
                }
            } else {
                if (!map.containsKey("hybridFallback") || !((Boolean) map.get("hybridFallback")).booleanValue()) {
                    z2 = false;
                }
                d.a aVar = z2 ? d.a.TEXTURE_WITH_HYBRID_FALLBACK : d.a.TEXTURE_WITH_VIRTUAL_FALLBACK;
                int intValue = ((Integer) map.get("id")).intValue();
                String str = (String) map.get("viewType");
                double d2 = 0.0d;
                double doubleValue = map.containsKey("top") ? ((Double) map.get("top")).doubleValue() : 0.0d;
                if (map.containsKey("left")) {
                    d2 = ((Double) map.get("left")).doubleValue();
                }
                long e3 = l.this.f1350b.e(new d(intValue, str, doubleValue, d2, ((Double) map.get("width")).doubleValue(), ((Double) map.get("height")).doubleValue(), ((Integer) map.get("direction")).intValue(), aVar, wrap));
                if (e3 != -2) {
                    dVar2.b(Long.valueOf(e3));
                    return;
                } else if (!z2) {
                    throw new AssertionError("Platform view attempted to fall back to hybrid mode when not requested.");
                }
            }
            dVar2.b((Object) null);
        }

        private void e(h hVar, i.d dVar) {
            try {
                l.this.f1350b.g(((Integer) ((Map) hVar.b()).get("id")).intValue());
                dVar.b((Object) null);
            } catch (IllegalStateException e2) {
                dVar.a("error", l.c(e2), (Object) null);
            }
        }

        /* access modifiers changed from: private */
        public static /* synthetic */ void f(i.d dVar, c cVar) {
            if (cVar == null) {
                dVar.a("error", "Failed to resize the platform view", (Object) null);
                return;
            }
            HashMap hashMap = new HashMap();
            hashMap.put("width", Double.valueOf((double) cVar.f1353a));
            hashMap.put("height", Double.valueOf((double) cVar.f1354b));
            dVar.b(hashMap);
        }

        private void g(h hVar, i.d dVar) {
            Map map = (Map) hVar.b();
            try {
                l.this.f1350b.c(((Integer) map.get("id")).intValue(), ((Double) map.get("top")).doubleValue(), ((Double) map.get("left")).doubleValue());
                dVar.b((Object) null);
            } catch (IllegalStateException e2) {
                dVar.a("error", l.c(e2), (Object) null);
            }
        }

        private void h(h hVar, i.d dVar) {
            Map map = (Map) hVar.b();
            try {
                l.this.f1350b.f(new e(((Integer) map.get("id")).intValue(), ((Double) map.get("width")).doubleValue(), ((Double) map.get("height")).doubleValue()), new k(dVar));
            } catch (IllegalStateException e2) {
                dVar.a("error", l.c(e2), (Object) null);
            }
        }

        private void i(h hVar, i.d dVar) {
            Map map = (Map) hVar.b();
            try {
                l.this.f1350b.d(((Integer) map.get("id")).intValue(), ((Integer) map.get("direction")).intValue());
                dVar.b((Object) null);
            } catch (IllegalStateException e2) {
                dVar.a("error", l.c(e2), (Object) null);
            }
        }

        private void j(h hVar, i.d dVar) {
            try {
                l.this.f1350b.b(((Boolean) hVar.b()).booleanValue());
                dVar.b((Object) null);
            } catch (IllegalStateException e2) {
                dVar.a("error", l.c(e2), (Object) null);
            }
        }

        private void k(h hVar, i.d dVar) {
            i.d dVar2;
            i.d dVar3 = dVar;
            List list = (List) hVar.b();
            f fVar = r2;
            f fVar2 = fVar;
            f fVar3 = new f(((Integer) list.get(0)).intValue(), (Number) list.get(1), (Number) list.get(2), ((Integer) list.get(3)).intValue(), ((Integer) list.get(4)).intValue(), list.get(5), list.get(6), ((Integer) list.get(7)).intValue(), ((Integer) list.get(8)).intValue(), (float) ((Double) list.get(9)).doubleValue(), (float) ((Double) list.get(10)).doubleValue(), ((Integer) list.get(11)).intValue(), ((Integer) list.get(12)).intValue(), ((Integer) list.get(13)).intValue(), ((Integer) list.get(14)).intValue(), ((Number) list.get(15)).longValue());
            try {
                l.this.f1350b.i(fVar);
                dVar2 = dVar;
                try {
                    dVar2.b((Object) null);
                } catch (IllegalStateException e2) {
                    e = e2;
                }
            } catch (IllegalStateException e3) {
                e = e3;
                dVar2 = dVar;
                dVar2.a("error", l.c(e), (Object) null);
            }
        }

        public void a(h hVar, i.d dVar) {
            if (l.this.f1350b != null) {
                m.b.f("PlatformViewsChannel", "Received '" + hVar.f1475a + "' message.");
                String str = hVar.f1475a;
                str.hashCode();
                char c2 = 65535;
                switch (str.hashCode()) {
                    case -1352294148:
                        if (str.equals("create")) {
                            c2 = 0;
                            break;
                        }
                        break;
                    case -1019779949:
                        if (str.equals("offset")) {
                            c2 = 1;
                            break;
                        }
                        break;
                    case -934437708:
                        if (str.equals("resize")) {
                            c2 = 2;
                            break;
                        }
                        break;
                    case -756050293:
                        if (str.equals("clearFocus")) {
                            c2 = 3;
                            break;
                        }
                        break;
                    case -308988850:
                        if (str.equals("synchronizeToNativeViewHierarchy")) {
                            c2 = 4;
                            break;
                        }
                        break;
                    case 110550847:
                        if (str.equals("touch")) {
                            c2 = 5;
                            break;
                        }
                        break;
                    case 576796989:
                        if (str.equals("setDirection")) {
                            c2 = 6;
                            break;
                        }
                        break;
                    case 1671767583:
                        if (str.equals("dispose")) {
                            c2 = 7;
                            break;
                        }
                        break;
                }
                switch (c2) {
                    case 0:
                        d(hVar, dVar);
                        return;
                    case 1:
                        g(hVar, dVar);
                        return;
                    case 2:
                        h(hVar, dVar);
                        return;
                    case 3:
                        c(hVar, dVar);
                        return;
                    case 4:
                        j(hVar, dVar);
                        return;
                    case R.styleable.SplitPairRule_splitMinWidth:
                        k(hVar, dVar);
                        return;
                    case R.styleable.SplitPairRule_splitRatio:
                        i(hVar, dVar);
                        return;
                    case 7:
                        e(hVar, dVar);
                        return;
                    default:
                        dVar.c();
                        return;
                }
            }
        }
    }

    public interface b {
        void a(c cVar);
    }

    public static class c {

        /* renamed from: a  reason: collision with root package name */
        public final int f1353a;

        /* renamed from: b  reason: collision with root package name */
        public final int f1354b;

        public c(int i2, int i3) {
            this.f1353a = i2;
            this.f1354b = i3;
        }
    }

    public static class d {

        /* renamed from: a  reason: collision with root package name */
        public final int f1355a;

        /* renamed from: b  reason: collision with root package name */
        public final String f1356b;

        /* renamed from: c  reason: collision with root package name */
        public final double f1357c;

        /* renamed from: d  reason: collision with root package name */
        public final double f1358d;

        /* renamed from: e  reason: collision with root package name */
        public final double f1359e;

        /* renamed from: f  reason: collision with root package name */
        public final double f1360f;

        /* renamed from: g  reason: collision with root package name */
        public final int f1361g;

        /* renamed from: h  reason: collision with root package name */
        public final a f1362h;

        /* renamed from: i  reason: collision with root package name */
        public final ByteBuffer f1363i;

        public enum a {
            TEXTURE_WITH_VIRTUAL_FALLBACK,
            TEXTURE_WITH_HYBRID_FALLBACK,
            HYBRID_ONLY
        }

        public d(int i2, String str, double d2, double d3, double d4, double d5, int i3, a aVar, ByteBuffer byteBuffer) {
            this.f1355a = i2;
            this.f1356b = str;
            this.f1359e = d2;
            this.f1360f = d3;
            this.f1357c = d4;
            this.f1358d = d5;
            this.f1361g = i3;
            this.f1362h = aVar;
            this.f1363i = byteBuffer;
        }
    }

    public static class e {

        /* renamed from: a  reason: collision with root package name */
        public final int f1368a;

        /* renamed from: b  reason: collision with root package name */
        public final double f1369b;

        /* renamed from: c  reason: collision with root package name */
        public final double f1370c;

        public e(int i2, double d2, double d3) {
            this.f1368a = i2;
            this.f1369b = d2;
            this.f1370c = d3;
        }
    }

    public static class f {

        /* renamed from: a  reason: collision with root package name */
        public final int f1371a;

        /* renamed from: b  reason: collision with root package name */
        public final Number f1372b;

        /* renamed from: c  reason: collision with root package name */
        public final Number f1373c;

        /* renamed from: d  reason: collision with root package name */
        public final int f1374d;

        /* renamed from: e  reason: collision with root package name */
        public final int f1375e;

        /* renamed from: f  reason: collision with root package name */
        public final Object f1376f;

        /* renamed from: g  reason: collision with root package name */
        public final Object f1377g;

        /* renamed from: h  reason: collision with root package name */
        public final int f1378h;

        /* renamed from: i  reason: collision with root package name */
        public final int f1379i;

        /* renamed from: j  reason: collision with root package name */
        public final float f1380j;

        /* renamed from: k  reason: collision with root package name */
        public final float f1381k;

        /* renamed from: l  reason: collision with root package name */
        public final int f1382l;

        /* renamed from: m  reason: collision with root package name */
        public final int f1383m;

        /* renamed from: n  reason: collision with root package name */
        public final int f1384n;

        /* renamed from: o  reason: collision with root package name */
        public final int f1385o;

        /* renamed from: p  reason: collision with root package name */
        public final long f1386p;

        public f(int i2, Number number, Number number2, int i3, int i4, Object obj, Object obj2, int i5, int i6, float f2, float f3, int i7, int i8, int i9, int i10, long j2) {
            this.f1371a = i2;
            this.f1372b = number;
            this.f1373c = number2;
            this.f1374d = i3;
            this.f1375e = i4;
            this.f1376f = obj;
            this.f1377g = obj2;
            this.f1378h = i5;
            this.f1379i = i6;
            this.f1380j = f2;
            this.f1381k = f3;
            this.f1382l = i7;
            this.f1383m = i8;
            this.f1384n = i9;
            this.f1385o = i10;
            this.f1386p = j2;
        }
    }

    public interface g {
        void a(int i2);

        void b(boolean z2);

        void c(int i2, double d2, double d3);

        void d(int i2, int i3);

        long e(d dVar);

        void f(e eVar, b bVar);

        void g(int i2);

        void h(d dVar);

        void i(f fVar);
    }

    public l(n.a aVar) {
        a aVar2 = new a();
        this.f1351c = aVar2;
        i iVar = new i(aVar, "flutter/platform_views", p.f1490b);
        this.f1349a = iVar;
        iVar.e(aVar2);
    }

    /* access modifiers changed from: private */
    public static String c(Exception exc) {
        return m.b.d(exc);
    }

    public void d(int i2) {
        i iVar = this.f1349a;
        if (iVar != null) {
            iVar.c("viewFocused", Integer.valueOf(i2));
        }
    }

    public void e(g gVar) {
        this.f1350b = gVar;
    }
}
