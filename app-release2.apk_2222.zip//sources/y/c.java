package y;

import y.d;
import z.a;

public final /* synthetic */ class c implements a.e {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ d.a f1275a;

    public /* synthetic */ c(d.a aVar) {
        this.f1275a = aVar;
    }

    public final void a(Object obj) {
        d.d(this.f1275a, obj);
    }
}
