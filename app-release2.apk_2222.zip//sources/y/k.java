package y;

import y.l;
import z.i;

public final /* synthetic */ class k implements l.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ i.d f1348a;

    public /* synthetic */ k(i.d dVar) {
        this.f1348a = dVar;
    }

    public final void a(l.c cVar) {
        l.a.f(this.f1348a, cVar);
    }
}
