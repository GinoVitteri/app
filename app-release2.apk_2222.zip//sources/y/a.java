package y;

import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.view.j;
import java.util.HashMap;
import z.a;
import z.o;

public class a {

    /* renamed from: a  reason: collision with root package name */
    public final z.a<Object> f1265a;

    /* renamed from: b  reason: collision with root package name */
    public final FlutterJNI f1266b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public b f1267c;

    /* renamed from: d  reason: collision with root package name */
    final a.d<Object> f1268d;

    /* renamed from: y.a$a  reason: collision with other inner class name */
    class C0030a implements a.d<Object> {
        C0030a() {
        }

        public void a(Object obj, a.e<Object> eVar) {
            if (a.this.f1267c == null) {
                eVar.a(null);
                return;
            }
            HashMap hashMap = (HashMap) obj;
            String str = (String) hashMap.get("type");
            HashMap hashMap2 = (HashMap) hashMap.get("data");
            m.b.f("AccessibilityChannel", "Received " + str + " message.");
            str.hashCode();
            char c2 = 65535;
            switch (str.hashCode()) {
                case -1140076541:
                    if (str.equals("tooltip")) {
                        c2 = 0;
                        break;
                    }
                    break;
                case -649620375:
                    if (str.equals("announce")) {
                        c2 = 1;
                        break;
                    }
                    break;
                case 114595:
                    if (str.equals("tap")) {
                        c2 = 2;
                        break;
                    }
                    break;
                case 114203431:
                    if (str.equals("longPress")) {
                        c2 = 3;
                        break;
                    }
                    break;
            }
            switch (c2) {
                case 0:
                    String str2 = (String) hashMap2.get("message");
                    if (str2 != null) {
                        a.this.f1267c.c(str2);
                        break;
                    }
                    break;
                case 1:
                    String str3 = (String) hashMap2.get("message");
                    if (str3 != null) {
                        a.this.f1267c.e(str3);
                        break;
                    }
                    break;
                case 2:
                    Integer num = (Integer) hashMap.get("nodeId");
                    if (num != null) {
                        a.this.f1267c.f(num.intValue());
                        break;
                    }
                    break;
                case 3:
                    Integer num2 = (Integer) hashMap.get("nodeId");
                    if (num2 != null) {
                        a.this.f1267c.d(num2.intValue());
                        break;
                    }
                    break;
            }
            eVar.a(null);
        }
    }

    public interface b extends FlutterJNI.a {
        void c(String str);

        void d(int i2);

        void e(String str);

        void f(int i2);
    }

    public a(n.a aVar, FlutterJNI flutterJNI) {
        C0030a aVar2 = new C0030a();
        this.f1268d = aVar2;
        z.a<Object> aVar3 = new z.a<>(aVar, "flutter/accessibility", o.f1487a);
        this.f1265a = aVar3;
        aVar3.e(aVar2);
        this.f1266b = flutterJNI;
    }

    public void b(int i2, j.g gVar) {
        this.f1266b.dispatchSemanticsAction(i2, gVar);
    }

    public void c(int i2, j.g gVar, Object obj) {
        this.f1266b.dispatchSemanticsAction(i2, gVar, obj);
    }

    public void d() {
        this.f1266b.setSemanticsEnabled(false);
    }

    public void e() {
        this.f1266b.setSemanticsEnabled(true);
    }

    public void f(int i2) {
        this.f1266b.setAccessibilityFeatures(i2);
    }

    public void g(b bVar) {
        this.f1267c = bVar;
        this.f1266b.setAccessibilityDelegate(bVar);
    }
}
