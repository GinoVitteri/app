package y;

import java.util.HashMap;
import java.util.Map;
import z.d;

public class n {

    /* renamed from: a  reason: collision with root package name */
    public final z.a<Object> f1397a;

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        private final z.a<Object> f1398a;

        /* renamed from: b  reason: collision with root package name */
        private Map<String, Object> f1399b = new HashMap();

        a(z.a<Object> aVar) {
            this.f1398a = aVar;
        }

        public void a() {
            m.b.f("SettingsChannel", "Sending message: \ntextScaleFactor: " + this.f1399b.get("textScaleFactor") + "\nalwaysUse24HourFormat: " + this.f1399b.get("alwaysUse24HourFormat") + "\nplatformBrightness: " + this.f1399b.get("platformBrightness"));
            this.f1398a.c(this.f1399b);
        }

        public a b(boolean z2) {
            this.f1399b.put("brieflyShowPassword", Boolean.valueOf(z2));
            return this;
        }

        public a c(boolean z2) {
            this.f1399b.put("nativeSpellCheckServiceDefined", Boolean.valueOf(z2));
            return this;
        }

        public a d(b bVar) {
            this.f1399b.put("platformBrightness", bVar.f1403d);
            return this;
        }

        public a e(float f2) {
            this.f1399b.put("textScaleFactor", Float.valueOf(f2));
            return this;
        }

        public a f(boolean z2) {
            this.f1399b.put("alwaysUse24HourFormat", Boolean.valueOf(z2));
            return this;
        }
    }

    public enum b {
        light("light"),
        dark("dark");
        

        /* renamed from: d  reason: collision with root package name */
        public String f1403d;

        private b(String str) {
            this.f1403d = str;
        }
    }

    public n(n.a aVar) {
        this.f1397a = new z.a<>(aVar, "flutter/settings", d.f1473a);
    }

    public a a() {
        return new a(this.f1397a);
    }
}
