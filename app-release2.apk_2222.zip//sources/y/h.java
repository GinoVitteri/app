package y;

import java.util.HashMap;
import z.i;
import z.p;

public class h {

    /* renamed from: a  reason: collision with root package name */
    public final i f1291a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public b f1292b;

    /* renamed from: c  reason: collision with root package name */
    private final i.c f1293c;

    class a implements i.c {
        a() {
        }

        public void a(z.h hVar, i.d dVar) {
            if (h.this.f1292b != null) {
                String str = hVar.f1475a;
                m.b.f("MouseCursorChannel", "Received '" + str + "' message.");
                char c2 = 65535;
                try {
                    if (str.hashCode() == -1307105544) {
                        if (str.equals("activateSystemCursor")) {
                            c2 = 0;
                        }
                    }
                    if (c2 == 0) {
                        try {
                            h.this.f1292b.a((String) ((HashMap) hVar.f1476b).get("kind"));
                            dVar.b(Boolean.TRUE);
                        } catch (Exception e2) {
                            dVar.a("error", "Error when setting cursors: " + e2.getMessage(), (Object) null);
                        }
                    }
                } catch (Exception e3) {
                    dVar.a("error", "Unhandled error: " + e3.getMessage(), (Object) null);
                }
            }
        }
    }

    public interface b {
        void a(String str);
    }

    public h(n.a aVar) {
        a aVar2 = new a();
        this.f1293c = aVar2;
        i iVar = new i(aVar, "flutter/mousecursor", p.f1490b);
        this.f1291a = iVar;
        iVar.e(aVar2);
    }

    public void b(b bVar) {
        this.f1292b = bVar;
    }
}
