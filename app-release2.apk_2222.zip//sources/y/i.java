package y;

import java.util.HashMap;
import m.b;
import z.e;
import z.h;
import z.i;

public class i {

    /* renamed from: a  reason: collision with root package name */
    public final z.i f1295a;

    /* renamed from: b  reason: collision with root package name */
    private final i.c f1296b;

    class a implements i.c {
        a() {
        }

        public void a(h hVar, i.d dVar) {
            dVar.b((Object) null);
        }
    }

    public i(n.a aVar) {
        a aVar2 = new a();
        this.f1296b = aVar2;
        z.i iVar = new z.i(aVar, "flutter/navigation", e.f1474a);
        this.f1295a = iVar;
        iVar.e(aVar2);
    }

    public void a() {
        b.f("NavigationChannel", "Sending message to pop route.");
        this.f1295a.c("popRoute", (Object) null);
    }

    public void b(String str) {
        b.f("NavigationChannel", "Sending message to push route information '" + str + "'");
        HashMap hashMap = new HashMap();
        hashMap.put("location", str);
        this.f1295a.c("pushRouteInformation", hashMap);
    }

    public void c(String str) {
        b.f("NavigationChannel", "Sending message to set initial route to '" + str + "'");
        this.f1295a.c("setInitialRoute", str);
    }
}
