package y;

import java.util.HashMap;
import m.b;
import z.a;
import z.d;

public class p {

    /* renamed from: a  reason: collision with root package name */
    public final a<Object> f1408a;

    public p(n.a aVar) {
        this.f1408a = new a<>(aVar, "flutter/system", d.f1473a);
    }

    public void a() {
        b.f("SystemChannel", "Sending memory pressure warning to Flutter.");
        HashMap hashMap = new HashMap(1);
        hashMap.put("type", "memoryPressure");
        this.f1408a.c(hashMap);
    }
}
