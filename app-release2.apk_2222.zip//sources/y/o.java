package y;

import java.util.ArrayList;
import z.h;
import z.i;
import z.p;

public class o {

    /* renamed from: a  reason: collision with root package name */
    public final i f1404a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public b f1405b;

    /* renamed from: c  reason: collision with root package name */
    public final i.c f1406c;

    class a implements i.c {
        a() {
        }

        public void a(h hVar, i.d dVar) {
            if (o.this.f1405b == null) {
                m.b.f("SpellCheckChannel", "No SpellCheckeMethodHandler registered, call not forwarded to spell check API.");
                return;
            }
            String str = hVar.f1475a;
            Object obj = hVar.f1476b;
            m.b.f("SpellCheckChannel", "Received '" + str + "' message.");
            str.hashCode();
            if (!str.equals("SpellCheck.initiateSpellCheck")) {
                dVar.c();
                return;
            }
            try {
                ArrayList arrayList = (ArrayList) obj;
                o.this.f1405b.a((String) arrayList.get(0), (String) arrayList.get(1), dVar);
            } catch (IllegalStateException e2) {
                dVar.a("error", e2.getMessage(), (Object) null);
            }
        }
    }

    public interface b {
        void a(String str, String str2, i.d dVar);
    }

    public o(n.a aVar) {
        a aVar2 = new a();
        this.f1406c = aVar2;
        i iVar = new i(aVar, "flutter/spellcheck", p.f1490b);
        this.f1404a = iVar;
        iVar.e(aVar2);
    }

    public void b(b bVar) {
        this.f1405b = bVar;
    }
}
