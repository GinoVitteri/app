package y;

import java.util.HashMap;
import java.util.Map;
import z.h;
import z.i;
import z.p;

public class m {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f1387a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public byte[] f1388b;

    /* renamed from: c  reason: collision with root package name */
    private i f1389c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public i.d f1390d;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public boolean f1391e;
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public boolean f1392f;

    /* renamed from: g  reason: collision with root package name */
    private final i.c f1393g;

    class a implements i.d {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ byte[] f1394a;

        a(byte[] bArr) {
            this.f1394a = bArr;
        }

        public void a(String str, String str2, Object obj) {
            m.b.b("RestorationChannel", "Error " + str + " while sending restoration data to framework: " + str2);
        }

        public void b(Object obj) {
            byte[] unused = m.this.f1388b = this.f1394a;
        }

        public void c() {
        }
    }

    class b implements i.c {
        b() {
        }

        public void a(h hVar, i.d dVar) {
            Map e2;
            String str = hVar.f1475a;
            Object obj = hVar.f1476b;
            str.hashCode();
            if (str.equals("get")) {
                boolean unused = m.this.f1392f = true;
                if (!m.this.f1391e) {
                    m mVar = m.this;
                    if (mVar.f1387a) {
                        i.d unused2 = mVar.f1390d = dVar;
                        return;
                    }
                }
                m mVar2 = m.this;
                e2 = mVar2.i(mVar2.f1388b);
            } else if (!str.equals("put")) {
                dVar.c();
                return;
            } else {
                byte[] unused3 = m.this.f1388b = (byte[]) obj;
                e2 = null;
            }
            dVar.b(e2);
        }
    }

    public m(n.a aVar, boolean z2) {
        this(new i(aVar, "flutter/restoration", p.f1490b), z2);
    }

    m(i iVar, boolean z2) {
        this.f1391e = false;
        this.f1392f = false;
        b bVar = new b();
        this.f1393g = bVar;
        this.f1389c = iVar;
        this.f1387a = z2;
        iVar.e(bVar);
    }

    /* access modifiers changed from: private */
    public Map<String, Object> i(byte[] bArr) {
        HashMap hashMap = new HashMap();
        hashMap.put("enabled", Boolean.TRUE);
        hashMap.put("data", bArr);
        return hashMap;
    }

    public void g() {
        this.f1388b = null;
    }

    public byte[] h() {
        return this.f1388b;
    }

    public void j(byte[] bArr) {
        this.f1391e = true;
        i.d dVar = this.f1390d;
        if (dVar != null) {
            dVar.b(i(bArr));
            this.f1390d = null;
        } else if (this.f1392f) {
            this.f1389c.d("push", i(bArr), new a(bArr));
            return;
        }
        this.f1388b = bArr;
    }
}
