package y;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import z.h;
import z.i;
import z.p;

public class b {

    /* renamed from: a  reason: collision with root package name */
    private final i f1270a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public o.a f1271b = m.a.e().a();
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public Map<String, List<i.d>> f1272c = new HashMap();

    /* renamed from: d  reason: collision with root package name */
    final i.c f1273d;

    class a implements i.c {
        a() {
        }

        public void a(h hVar, i.d dVar) {
            String str;
            if (b.this.f1271b != null) {
                String str2 = hVar.f1475a;
                Map map = (Map) hVar.b();
                m.b.f("DeferredComponentChannel", "Received '" + str2 + "' message.");
                int intValue = ((Integer) map.get("loadingUnitId")).intValue();
                String str3 = (String) map.get("componentName");
                str2.hashCode();
                char c2 = 65535;
                switch (str2.hashCode()) {
                    case -1004447972:
                        if (str2.equals("uninstallDeferredComponent")) {
                            c2 = 0;
                            break;
                        }
                        break;
                    case 399701758:
                        if (str2.equals("getDeferredComponentInstallState")) {
                            c2 = 1;
                            break;
                        }
                        break;
                    case 520962947:
                        if (str2.equals("installDeferredComponent")) {
                            c2 = 2;
                            break;
                        }
                        break;
                }
                switch (c2) {
                    case 0:
                        b.this.f1271b.c(intValue, str3);
                        str = null;
                        break;
                    case 1:
                        str = b.this.f1271b.a(intValue, str3);
                        break;
                    case 2:
                        b.this.f1271b.b(intValue, str3);
                        if (!b.this.f1272c.containsKey(str3)) {
                            b.this.f1272c.put(str3, new ArrayList());
                        }
                        ((List) b.this.f1272c.get(str3)).add(dVar);
                        return;
                    default:
                        dVar.c();
                        return;
                }
                dVar.b(str);
            }
        }
    }

    public b(n.a aVar) {
        a aVar2 = new a();
        this.f1273d = aVar2;
        i iVar = new i(aVar, "flutter/deferredcomponent", p.f1490b);
        this.f1270a = iVar;
        iVar.e(aVar2);
    }

    public void c(o.a aVar) {
        this.f1271b = aVar;
    }
}
