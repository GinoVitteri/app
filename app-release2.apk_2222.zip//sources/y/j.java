package y;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import z.i;

public class j {

    /* renamed from: a  reason: collision with root package name */
    public final z.i f1298a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public h f1299b;

    /* renamed from: c  reason: collision with root package name */
    final i.c f1300c;

    class a implements i.c {
        a() {
        }

        /* JADX WARNING: Can't wrap try/catch for region: R(2:58|59) */
        /* JADX WARNING: Code restructure failed: missing block: B:108:?, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:53:0x00f0, code lost:
            r7.b((java.lang.Object) null);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:59:?, code lost:
            r7.a("error", "No such clipboard content format: " + r6, (java.lang.Object) null);
         */
        /* JADX WARNING: Missing exception handler attribute for start block: B:58:0x00fe */
        /* JADX WARNING: Removed duplicated region for block: B:63:0x011f A[Catch:{ JSONException -> 0x0216 }] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void a(z.h r6, z.i.d r7) {
            /*
                r5 = this;
                java.lang.String r0 = "error"
                y.j r1 = y.j.this
                y.j$h r1 = r1.f1299b
                if (r1 != 0) goto L_0x000b
                return
            L_0x000b:
                java.lang.String r1 = r6.f1475a
                java.lang.Object r6 = r6.f1476b
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = "Received '"
                r2.append(r3)
                r2.append(r1)
                java.lang.String r3 = "' message."
                r2.append(r3)
                java.lang.String r2 = r2.toString()
                java.lang.String r3 = "PlatformChannel"
                m.b.f(r3, r2)
                r2 = -1
                r3 = 0
                int r4 = r1.hashCode()     // Catch:{ JSONException -> 0x0216 }
                switch(r4) {
                    case -766342101: goto L_0x00b4;
                    case -720677196: goto L_0x00a9;
                    case -577225884: goto L_0x009f;
                    case -548468504: goto L_0x0095;
                    case -247230243: goto L_0x008b;
                    case -215273374: goto L_0x0081;
                    case 241845679: goto L_0x0077;
                    case 875995648: goto L_0x006c;
                    case 1128339786: goto L_0x0062;
                    case 1390477857: goto L_0x0057;
                    case 1514180520: goto L_0x004b;
                    case 1674312266: goto L_0x0040;
                    case 2119655719: goto L_0x0035;
                    default: goto L_0x0033;
                }     // Catch:{ JSONException -> 0x0216 }
            L_0x0033:
                goto L_0x00be
            L_0x0035:
                java.lang.String r4 = "SystemChrome.setPreferredOrientations"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 2
                goto L_0x00be
            L_0x0040:
                java.lang.String r4 = "SystemChrome.setEnabledSystemUIOverlays"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 4
                goto L_0x00be
            L_0x004b:
                java.lang.String r4 = "Clipboard.getData"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 10
                goto L_0x00be
            L_0x0057:
                java.lang.String r4 = "SystemChrome.setSystemUIOverlayStyle"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 8
                goto L_0x00be
            L_0x0062:
                java.lang.String r4 = "SystemChrome.setEnabledSystemUIMode"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 5
                goto L_0x00be
            L_0x006c:
                java.lang.String r4 = "Clipboard.hasStrings"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 12
                goto L_0x00be
            L_0x0077:
                java.lang.String r4 = "SystemChrome.restoreSystemUIOverlays"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 7
                goto L_0x00be
            L_0x0081:
                java.lang.String r4 = "SystemSound.play"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 0
                goto L_0x00be
            L_0x008b:
                java.lang.String r4 = "HapticFeedback.vibrate"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 1
                goto L_0x00be
            L_0x0095:
                java.lang.String r4 = "SystemChrome.setApplicationSwitcherDescription"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 3
                goto L_0x00be
            L_0x009f:
                java.lang.String r4 = "SystemChrome.setSystemUIChangeListener"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 6
                goto L_0x00be
            L_0x00a9:
                java.lang.String r4 = "Clipboard.setData"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 11
                goto L_0x00be
            L_0x00b4:
                java.lang.String r4 = "SystemNavigator.pop"
                boolean r1 = r1.equals(r4)     // Catch:{ JSONException -> 0x0216 }
                if (r1 == 0) goto L_0x00be
                r2 = 9
            L_0x00be:
                java.lang.String r1 = "text"
                switch(r2) {
                    case 0: goto L_0x01fc;
                    case 1: goto L_0x01e2;
                    case 2: goto L_0x01c4;
                    case 3: goto L_0x01a8;
                    case 4: goto L_0x018a;
                    case 5: goto L_0x016c;
                    case 6: goto L_0x0162;
                    case 7: goto L_0x0158;
                    case 8: goto L_0x0136;
                    case 9: goto L_0x012c;
                    case 10: goto L_0x00f5;
                    case 11: goto L_0x00e1;
                    case 12: goto L_0x00c8;
                    default: goto L_0x00c3;
                }
            L_0x00c3:
                r7.c()     // Catch:{ JSONException -> 0x0216 }
                goto L_0x022f
            L_0x00c8:
                y.j r6 = y.j.this     // Catch:{ JSONException -> 0x0216 }
                y.j$h r6 = r6.f1299b     // Catch:{ JSONException -> 0x0216 }
                boolean r6 = r6.m()     // Catch:{ JSONException -> 0x0216 }
                org.json.JSONObject r1 = new org.json.JSONObject     // Catch:{ JSONException -> 0x0216 }
                r1.<init>()     // Catch:{ JSONException -> 0x0216 }
                java.lang.String r2 = "value"
                r1.put(r2, r6)     // Catch:{ JSONException -> 0x0216 }
                r7.b(r1)     // Catch:{ JSONException -> 0x0216 }
                goto L_0x022f
            L_0x00e1:
                org.json.JSONObject r6 = (org.json.JSONObject) r6     // Catch:{ JSONException -> 0x0216 }
                java.lang.String r6 = r6.getString(r1)     // Catch:{ JSONException -> 0x0216 }
                y.j r1 = y.j.this     // Catch:{ JSONException -> 0x0216 }
                y.j$h r1 = r1.f1299b     // Catch:{ JSONException -> 0x0216 }
                r1.d(r6)     // Catch:{ JSONException -> 0x0216 }
            L_0x00f0:
                r7.b(r3)     // Catch:{ JSONException -> 0x0216 }
                goto L_0x022f
            L_0x00f5:
                java.lang.String r6 = (java.lang.String) r6     // Catch:{ JSONException -> 0x0216 }
                if (r6 == 0) goto L_0x0112
                y.j$e r6 = y.j.e.a(r6)     // Catch:{ NoSuchFieldException -> 0x00fe }
                goto L_0x0113
            L_0x00fe:
                java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ JSONException -> 0x0216 }
                r2.<init>()     // Catch:{ JSONException -> 0x0216 }
                java.lang.String r4 = "No such clipboard content format: "
                r2.append(r4)     // Catch:{ JSONException -> 0x0216 }
                r2.append(r6)     // Catch:{ JSONException -> 0x0216 }
                java.lang.String r6 = r2.toString()     // Catch:{ JSONException -> 0x0216 }
                r7.a(r0, r6, r3)     // Catch:{ JSONException -> 0x0216 }
            L_0x0112:
                r6 = r3
            L_0x0113:
                y.j r2 = y.j.this     // Catch:{ JSONException -> 0x0216 }
                y.j$h r2 = r2.f1299b     // Catch:{ JSONException -> 0x0216 }
                java.lang.CharSequence r6 = r2.e(r6)     // Catch:{ JSONException -> 0x0216 }
                if (r6 == 0) goto L_0x00f0
                org.json.JSONObject r2 = new org.json.JSONObject     // Catch:{ JSONException -> 0x0216 }
                r2.<init>()     // Catch:{ JSONException -> 0x0216 }
                r2.put(r1, r6)     // Catch:{ JSONException -> 0x0216 }
                r7.b(r2)     // Catch:{ JSONException -> 0x0216 }
                goto L_0x022f
            L_0x012c:
                y.j r6 = y.j.this     // Catch:{ JSONException -> 0x0216 }
                y.j$h r6 = r6.f1299b     // Catch:{ JSONException -> 0x0216 }
                r6.a()     // Catch:{ JSONException -> 0x0216 }
                goto L_0x00f0
            L_0x0136:
                y.j r1 = y.j.this     // Catch:{ JSONException -> 0x014e, NoSuchFieldException -> 0x014c }
                org.json.JSONObject r6 = (org.json.JSONObject) r6     // Catch:{ JSONException -> 0x014e, NoSuchFieldException -> 0x014c }
                y.j$j r6 = r1.i(r6)     // Catch:{ JSONException -> 0x014e, NoSuchFieldException -> 0x014c }
                y.j r1 = y.j.this     // Catch:{ JSONException -> 0x014e, NoSuchFieldException -> 0x014c }
                y.j$h r1 = r1.f1299b     // Catch:{ JSONException -> 0x014e, NoSuchFieldException -> 0x014c }
                r1.l(r6)     // Catch:{ JSONException -> 0x014e, NoSuchFieldException -> 0x014c }
                r7.b(r3)     // Catch:{ JSONException -> 0x014e, NoSuchFieldException -> 0x014c }
                goto L_0x022f
            L_0x014c:
                r6 = move-exception
                goto L_0x014f
            L_0x014e:
                r6 = move-exception
            L_0x014f:
                java.lang.String r6 = r6.getMessage()     // Catch:{ JSONException -> 0x0216 }
            L_0x0153:
                r7.a(r0, r6, r3)     // Catch:{ JSONException -> 0x0216 }
                goto L_0x022f
            L_0x0158:
                y.j r6 = y.j.this     // Catch:{ JSONException -> 0x0216 }
                y.j$h r6 = r6.f1299b     // Catch:{ JSONException -> 0x0216 }
                r6.c()     // Catch:{ JSONException -> 0x0216 }
                goto L_0x00f0
            L_0x0162:
                y.j r6 = y.j.this     // Catch:{ JSONException -> 0x0216 }
                y.j$h r6 = r6.f1299b     // Catch:{ JSONException -> 0x0216 }
                r6.b()     // Catch:{ JSONException -> 0x0216 }
                goto L_0x00f0
            L_0x016c:
                y.j r1 = y.j.this     // Catch:{ JSONException -> 0x0184, NoSuchFieldException -> 0x0182 }
                java.lang.String r6 = (java.lang.String) r6     // Catch:{ JSONException -> 0x0184, NoSuchFieldException -> 0x0182 }
                y.j$k r6 = r1.j(r6)     // Catch:{ JSONException -> 0x0184, NoSuchFieldException -> 0x0182 }
                y.j r1 = y.j.this     // Catch:{ JSONException -> 0x0184, NoSuchFieldException -> 0x0182 }
                y.j$h r1 = r1.f1299b     // Catch:{ JSONException -> 0x0184, NoSuchFieldException -> 0x0182 }
                r1.j(r6)     // Catch:{ JSONException -> 0x0184, NoSuchFieldException -> 0x0182 }
                r7.b(r3)     // Catch:{ JSONException -> 0x0184, NoSuchFieldException -> 0x0182 }
                goto L_0x022f
            L_0x0182:
                r6 = move-exception
                goto L_0x0185
            L_0x0184:
                r6 = move-exception
            L_0x0185:
                java.lang.String r6 = r6.getMessage()     // Catch:{ JSONException -> 0x0216 }
                goto L_0x0153
            L_0x018a:
                y.j r1 = y.j.this     // Catch:{ JSONException -> 0x01a2, NoSuchFieldException -> 0x01a0 }
                org.json.JSONArray r6 = (org.json.JSONArray) r6     // Catch:{ JSONException -> 0x01a2, NoSuchFieldException -> 0x01a0 }
                java.util.List r6 = r1.k(r6)     // Catch:{ JSONException -> 0x01a2, NoSuchFieldException -> 0x01a0 }
                y.j r1 = y.j.this     // Catch:{ JSONException -> 0x01a2, NoSuchFieldException -> 0x01a0 }
                y.j$h r1 = r1.f1299b     // Catch:{ JSONException -> 0x01a2, NoSuchFieldException -> 0x01a0 }
                r1.k(r6)     // Catch:{ JSONException -> 0x01a2, NoSuchFieldException -> 0x01a0 }
                r7.b(r3)     // Catch:{ JSONException -> 0x01a2, NoSuchFieldException -> 0x01a0 }
                goto L_0x022f
            L_0x01a0:
                r6 = move-exception
                goto L_0x01a3
            L_0x01a2:
                r6 = move-exception
            L_0x01a3:
                java.lang.String r6 = r6.getMessage()     // Catch:{ JSONException -> 0x0216 }
                goto L_0x0153
            L_0x01a8:
                y.j r1 = y.j.this     // Catch:{ JSONException -> 0x01be }
                org.json.JSONObject r6 = (org.json.JSONObject) r6     // Catch:{ JSONException -> 0x01be }
                y.j$c r6 = r1.g(r6)     // Catch:{ JSONException -> 0x01be }
                y.j r1 = y.j.this     // Catch:{ JSONException -> 0x01be }
                y.j$h r1 = r1.f1299b     // Catch:{ JSONException -> 0x01be }
                r1.g(r6)     // Catch:{ JSONException -> 0x01be }
                r7.b(r3)     // Catch:{ JSONException -> 0x01be }
                goto L_0x022f
            L_0x01be:
                r6 = move-exception
                java.lang.String r6 = r6.getMessage()     // Catch:{ JSONException -> 0x0216 }
                goto L_0x0153
            L_0x01c4:
                y.j r1 = y.j.this     // Catch:{ JSONException -> 0x01db, NoSuchFieldException -> 0x01d9 }
                org.json.JSONArray r6 = (org.json.JSONArray) r6     // Catch:{ JSONException -> 0x01db, NoSuchFieldException -> 0x01d9 }
                int r6 = r1.h(r6)     // Catch:{ JSONException -> 0x01db, NoSuchFieldException -> 0x01d9 }
                y.j r1 = y.j.this     // Catch:{ JSONException -> 0x01db, NoSuchFieldException -> 0x01d9 }
                y.j$h r1 = r1.f1299b     // Catch:{ JSONException -> 0x01db, NoSuchFieldException -> 0x01d9 }
                r1.h(r6)     // Catch:{ JSONException -> 0x01db, NoSuchFieldException -> 0x01d9 }
                r7.b(r3)     // Catch:{ JSONException -> 0x01db, NoSuchFieldException -> 0x01d9 }
                goto L_0x022f
            L_0x01d9:
                r6 = move-exception
                goto L_0x01dc
            L_0x01db:
                r6 = move-exception
            L_0x01dc:
                java.lang.String r6 = r6.getMessage()     // Catch:{ JSONException -> 0x0216 }
                goto L_0x0153
            L_0x01e2:
                java.lang.String r6 = (java.lang.String) r6     // Catch:{ NoSuchFieldException -> 0x01f5 }
                y.j$g r6 = y.j.g.a(r6)     // Catch:{ NoSuchFieldException -> 0x01f5 }
                y.j r1 = y.j.this     // Catch:{ NoSuchFieldException -> 0x01f5 }
                y.j$h r1 = r1.f1299b     // Catch:{ NoSuchFieldException -> 0x01f5 }
                r1.i(r6)     // Catch:{ NoSuchFieldException -> 0x01f5 }
                r7.b(r3)     // Catch:{ NoSuchFieldException -> 0x01f5 }
                goto L_0x022f
            L_0x01f5:
                r6 = move-exception
                java.lang.String r6 = r6.getMessage()     // Catch:{ JSONException -> 0x0216 }
                goto L_0x0153
            L_0x01fc:
                java.lang.String r6 = (java.lang.String) r6     // Catch:{ NoSuchFieldException -> 0x020f }
                y.j$i r6 = y.j.i.a(r6)     // Catch:{ NoSuchFieldException -> 0x020f }
                y.j r1 = y.j.this     // Catch:{ NoSuchFieldException -> 0x020f }
                y.j$h r1 = r1.f1299b     // Catch:{ NoSuchFieldException -> 0x020f }
                r1.f(r6)     // Catch:{ NoSuchFieldException -> 0x020f }
                r7.b(r3)     // Catch:{ NoSuchFieldException -> 0x020f }
                goto L_0x022f
            L_0x020f:
                r6 = move-exception
                java.lang.String r6 = r6.getMessage()     // Catch:{ JSONException -> 0x0216 }
                goto L_0x0153
            L_0x0216:
                r6 = move-exception
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = "JSON error: "
                r1.append(r2)
                java.lang.String r6 = r6.getMessage()
                r1.append(r6)
                java.lang.String r6 = r1.toString()
                r7.a(r0, r6, r3)
            L_0x022f:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: y.j.a.a(z.h, z.i$d):void");
        }
    }

    static /* synthetic */ class b {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f1302a;

        /* renamed from: b  reason: collision with root package name */
        static final /* synthetic */ int[] f1303b;

        /* renamed from: c  reason: collision with root package name */
        static final /* synthetic */ int[] f1304c;

        /* JADX WARNING: Can't wrap try/catch for region: R(23:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|17|18|19|20|21|23|24|25|26|27|28|29|30|32) */
        /* JADX WARNING: Can't wrap try/catch for region: R(26:0|1|2|3|(2:5|6)|7|9|10|11|13|14|15|17|18|19|20|21|23|24|25|26|27|28|29|30|32) */
        /* JADX WARNING: Code restructure failed: missing block: B:33:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:19:0x0044 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x005f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:27:0x0069 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:29:0x0073 */
        static {
            /*
                y.j$k[] r0 = y.j.k.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f1304c = r0
                r1 = 1
                y.j$k r2 = y.j.k.LEAN_BACK     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r2 = r2.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                r0 = 2
                int[] r2 = f1304c     // Catch:{ NoSuchFieldError -> 0x001d }
                y.j$k r3 = y.j.k.IMMERSIVE     // Catch:{ NoSuchFieldError -> 0x001d }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2[r3] = r0     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                r2 = 3
                int[] r3 = f1304c     // Catch:{ NoSuchFieldError -> 0x0028 }
                y.j$k r4 = y.j.k.IMMERSIVE_STICKY     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r3[r4] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                r3 = 4
                int[] r4 = f1304c     // Catch:{ NoSuchFieldError -> 0x0033 }
                y.j$k r5 = y.j.k.EDGE_TO_EDGE     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r5 = r5.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r4[r5] = r3     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                y.j$l[] r4 = y.j.l.values()
                int r4 = r4.length
                int[] r4 = new int[r4]
                f1303b = r4
                y.j$l r5 = y.j.l.TOP_OVERLAYS     // Catch:{ NoSuchFieldError -> 0x0044 }
                int r5 = r5.ordinal()     // Catch:{ NoSuchFieldError -> 0x0044 }
                r4[r5] = r1     // Catch:{ NoSuchFieldError -> 0x0044 }
            L_0x0044:
                int[] r4 = f1303b     // Catch:{ NoSuchFieldError -> 0x004e }
                y.j$l r5 = y.j.l.BOTTOM_OVERLAYS     // Catch:{ NoSuchFieldError -> 0x004e }
                int r5 = r5.ordinal()     // Catch:{ NoSuchFieldError -> 0x004e }
                r4[r5] = r0     // Catch:{ NoSuchFieldError -> 0x004e }
            L_0x004e:
                y.j$f[] r4 = y.j.f.values()
                int r4 = r4.length
                int[] r4 = new int[r4]
                f1302a = r4
                y.j$f r5 = y.j.f.PORTRAIT_UP     // Catch:{ NoSuchFieldError -> 0x005f }
                int r5 = r5.ordinal()     // Catch:{ NoSuchFieldError -> 0x005f }
                r4[r5] = r1     // Catch:{ NoSuchFieldError -> 0x005f }
            L_0x005f:
                int[] r1 = f1302a     // Catch:{ NoSuchFieldError -> 0x0069 }
                y.j$f r4 = y.j.f.PORTRAIT_DOWN     // Catch:{ NoSuchFieldError -> 0x0069 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0069 }
                r1[r4] = r0     // Catch:{ NoSuchFieldError -> 0x0069 }
            L_0x0069:
                int[] r0 = f1302a     // Catch:{ NoSuchFieldError -> 0x0073 }
                y.j$f r1 = y.j.f.LANDSCAPE_LEFT     // Catch:{ NoSuchFieldError -> 0x0073 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0073 }
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0073 }
            L_0x0073:
                int[] r0 = f1302a     // Catch:{ NoSuchFieldError -> 0x007d }
                y.j$f r1 = y.j.f.LANDSCAPE_RIGHT     // Catch:{ NoSuchFieldError -> 0x007d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x007d }
                r0[r1] = r3     // Catch:{ NoSuchFieldError -> 0x007d }
            L_0x007d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: y.j.b.<clinit>():void");
        }
    }

    public static class c {

        /* renamed from: a  reason: collision with root package name */
        public final int f1305a;

        /* renamed from: b  reason: collision with root package name */
        public final String f1306b;

        public c(int i2, String str) {
            this.f1305a = i2;
            this.f1306b = str;
        }
    }

    public enum d {
        LIGHT("Brightness.light"),
        DARK("Brightness.dark");
        

        /* renamed from: d  reason: collision with root package name */
        private String f1310d;

        private d(String str) {
            this.f1310d = str;
        }

        static d a(String str) {
            for (d dVar : values()) {
                if (dVar.f1310d.equals(str)) {
                    return dVar;
                }
            }
            throw new NoSuchFieldException("No such Brightness: " + str);
        }
    }

    public enum e {
        PLAIN_TEXT("text/plain");
        

        /* renamed from: d  reason: collision with root package name */
        private String f1313d;

        private e(String str) {
            this.f1313d = str;
        }

        static e a(String str) {
            for (e eVar : values()) {
                if (eVar.f1313d.equals(str)) {
                    return eVar;
                }
            }
            throw new NoSuchFieldException("No such ClipboardContentFormat: " + str);
        }
    }

    public enum f {
        PORTRAIT_UP("DeviceOrientation.portraitUp"),
        PORTRAIT_DOWN("DeviceOrientation.portraitDown"),
        LANDSCAPE_LEFT("DeviceOrientation.landscapeLeft"),
        LANDSCAPE_RIGHT("DeviceOrientation.landscapeRight");
        

        /* renamed from: d  reason: collision with root package name */
        private String f1319d;

        private f(String str) {
            this.f1319d = str;
        }

        static f a(String str) {
            for (f fVar : values()) {
                if (fVar.f1319d.equals(str)) {
                    return fVar;
                }
            }
            throw new NoSuchFieldException("No such DeviceOrientation: " + str);
        }
    }

    public enum g {
        STANDARD((String) null),
        LIGHT_IMPACT("HapticFeedbackType.lightImpact"),
        MEDIUM_IMPACT("HapticFeedbackType.mediumImpact"),
        HEAVY_IMPACT("HapticFeedbackType.heavyImpact"),
        SELECTION_CLICK("HapticFeedbackType.selectionClick");
        

        /* renamed from: d  reason: collision with root package name */
        private final String f1326d;

        private g(String str) {
            this.f1326d = str;
        }

        static g a(String str) {
            for (g gVar : values()) {
                String str2 = gVar.f1326d;
                if ((str2 == null && str == null) || (str2 != null && str2.equals(str))) {
                    return gVar;
                }
            }
            throw new NoSuchFieldException("No such HapticFeedbackType: " + str);
        }
    }

    public interface h {
        void a();

        void b();

        void c();

        void d(String str);

        CharSequence e(e eVar);

        void f(i iVar);

        void g(c cVar);

        void h(int i2);

        void i(g gVar);

        void j(k kVar);

        void k(List<l> list);

        void l(C0031j jVar);

        boolean m();
    }

    public enum i {
        CLICK("SystemSoundType.click"),
        ALERT("SystemSoundType.alert");
        

        /* renamed from: d  reason: collision with root package name */
        private final String f1330d;

        private i(String str) {
            this.f1330d = str;
        }

        static i a(String str) {
            for (i iVar : values()) {
                if (iVar.f1330d.equals(str)) {
                    return iVar;
                }
            }
            throw new NoSuchFieldException("No such SoundType: " + str);
        }
    }

    /* renamed from: y.j$j  reason: collision with other inner class name */
    public static class C0031j {

        /* renamed from: a  reason: collision with root package name */
        public final Integer f1331a;

        /* renamed from: b  reason: collision with root package name */
        public final d f1332b;

        /* renamed from: c  reason: collision with root package name */
        public final Boolean f1333c;

        /* renamed from: d  reason: collision with root package name */
        public final Integer f1334d;

        /* renamed from: e  reason: collision with root package name */
        public final d f1335e;

        /* renamed from: f  reason: collision with root package name */
        public final Integer f1336f;

        /* renamed from: g  reason: collision with root package name */
        public final Boolean f1337g;

        public C0031j(Integer num, d dVar, Boolean bool, Integer num2, d dVar2, Integer num3, Boolean bool2) {
            this.f1331a = num;
            this.f1332b = dVar;
            this.f1333c = bool;
            this.f1334d = num2;
            this.f1335e = dVar2;
            this.f1336f = num3;
            this.f1337g = bool2;
        }
    }

    public enum k {
        LEAN_BACK("SystemUiMode.leanBack"),
        IMMERSIVE("SystemUiMode.immersive"),
        IMMERSIVE_STICKY("SystemUiMode.immersiveSticky"),
        EDGE_TO_EDGE("SystemUiMode.edgeToEdge");
        

        /* renamed from: d  reason: collision with root package name */
        private String f1343d;

        private k(String str) {
            this.f1343d = str;
        }

        static k a(String str) {
            for (k kVar : values()) {
                if (kVar.f1343d.equals(str)) {
                    return kVar;
                }
            }
            throw new NoSuchFieldException("No such SystemUiMode: " + str);
        }
    }

    public enum l {
        TOP_OVERLAYS("SystemUiOverlay.top"),
        BOTTOM_OVERLAYS("SystemUiOverlay.bottom");
        

        /* renamed from: d  reason: collision with root package name */
        private String f1347d;

        private l(String str) {
            this.f1347d = str;
        }

        static l a(String str) {
            for (l lVar : values()) {
                if (lVar.f1347d.equals(str)) {
                    return lVar;
                }
            }
            throw new NoSuchFieldException("No such SystemUiOverlay: " + str);
        }
    }

    public j(n.a aVar) {
        a aVar2 = new a();
        this.f1300c = aVar2;
        z.i iVar = new z.i(aVar, "flutter/platform", z.e.f1474a);
        this.f1298a = iVar;
        iVar.e(aVar2);
    }

    /* access modifiers changed from: private */
    public c g(JSONObject jSONObject) {
        int i2 = jSONObject.getInt("primaryColor");
        if (i2 != 0) {
            i2 |= -16777216;
        }
        return new c(i2, jSONObject.getString("label"));
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0056, code lost:
        return 0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int h(org.json.JSONArray r10) {
        /*
            r9 = this;
            r0 = 0
            r1 = 0
            r2 = 0
            r3 = 0
        L_0x0004:
            int r4 = r10.length()
            r5 = 4
            r6 = 2
            r7 = 1
            if (r1 >= r4) goto L_0x0038
            java.lang.String r4 = r10.getString(r1)
            y.j$f r4 = y.j.f.a(r4)
            int[] r8 = y.j.b.f1302a
            int r4 = r4.ordinal()
            r4 = r8[r4]
            if (r4 == r7) goto L_0x0030
            if (r4 == r6) goto L_0x002d
            r6 = 3
            if (r4 == r6) goto L_0x002a
            if (r4 == r5) goto L_0x0027
            goto L_0x0032
        L_0x0027:
            r2 = r2 | 8
            goto L_0x0032
        L_0x002a:
            r2 = r2 | 2
            goto L_0x0032
        L_0x002d:
            r2 = r2 | 4
            goto L_0x0032
        L_0x0030:
            r2 = r2 | 1
        L_0x0032:
            if (r3 != 0) goto L_0x0035
            r3 = r2
        L_0x0035:
            int r1 = r1 + 1
            goto L_0x0004
        L_0x0038:
            if (r2 == 0) goto L_0x0057
            r10 = 9
            r1 = 8
            switch(r2) {
                case 2: goto L_0x0056;
                case 3: goto L_0x004d;
                case 4: goto L_0x004c;
                case 5: goto L_0x004a;
                case 6: goto L_0x004d;
                case 7: goto L_0x004d;
                case 8: goto L_0x0049;
                case 9: goto L_0x004d;
                case 10: goto L_0x0046;
                case 11: goto L_0x0045;
                case 12: goto L_0x004d;
                case 13: goto L_0x004d;
                case 14: goto L_0x004d;
                case 15: goto L_0x0042;
                default: goto L_0x0041;
            }
        L_0x0041:
            goto L_0x0053
        L_0x0042:
            r10 = 13
            return r10
        L_0x0045:
            return r6
        L_0x0046:
            r10 = 11
            return r10
        L_0x0049:
            return r1
        L_0x004a:
            r10 = 12
        L_0x004c:
            return r10
        L_0x004d:
            if (r3 == r6) goto L_0x0056
            if (r3 == r5) goto L_0x0055
            if (r3 == r1) goto L_0x0054
        L_0x0053:
            return r7
        L_0x0054:
            return r1
        L_0x0055:
            return r10
        L_0x0056:
            return r0
        L_0x0057:
            r10 = -1
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: y.j.h(org.json.JSONArray):int");
    }

    /* access modifiers changed from: private */
    public C0031j i(JSONObject jSONObject) {
        Boolean bool = null;
        Integer valueOf = !jSONObject.isNull("statusBarColor") ? Integer.valueOf(jSONObject.getInt("statusBarColor")) : null;
        d a2 = !jSONObject.isNull("statusBarIconBrightness") ? d.a(jSONObject.getString("statusBarIconBrightness")) : null;
        Boolean valueOf2 = !jSONObject.isNull("systemStatusBarContrastEnforced") ? Boolean.valueOf(jSONObject.getBoolean("systemStatusBarContrastEnforced")) : null;
        Integer valueOf3 = !jSONObject.isNull("systemNavigationBarColor") ? Integer.valueOf(jSONObject.getInt("systemNavigationBarColor")) : null;
        d a3 = !jSONObject.isNull("systemNavigationBarIconBrightness") ? d.a(jSONObject.getString("systemNavigationBarIconBrightness")) : null;
        Integer valueOf4 = !jSONObject.isNull("systemNavigationBarDividerColor") ? Integer.valueOf(jSONObject.getInt("systemNavigationBarDividerColor")) : null;
        if (!jSONObject.isNull("systemNavigationBarContrastEnforced")) {
            bool = Boolean.valueOf(jSONObject.getBoolean("systemNavigationBarContrastEnforced"));
        }
        return new C0031j(valueOf, a2, valueOf2, valueOf3, a3, valueOf4, bool);
    }

    /* access modifiers changed from: private */
    public k j(String str) {
        int i2 = b.f1304c[k.a(str).ordinal()];
        return i2 != 1 ? i2 != 2 ? i2 != 3 ? i2 != 4 ? k.EDGE_TO_EDGE : k.EDGE_TO_EDGE : k.IMMERSIVE_STICKY : k.IMMERSIVE : k.LEAN_BACK;
    }

    /* access modifiers changed from: private */
    public List<l> k(JSONArray jSONArray) {
        l lVar;
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
            int i3 = b.f1303b[l.a(jSONArray.getString(i2)).ordinal()];
            if (i3 == 1) {
                lVar = l.TOP_OVERLAYS;
            } else if (i3 != 2) {
            } else {
                lVar = l.BOTTOM_OVERLAYS;
            }
            arrayList.add(lVar);
        }
        return arrayList;
    }

    public void l(h hVar) {
        this.f1299b = hVar;
    }

    public void m(boolean z2) {
        m.b.f("PlatformChannel", "Sending 'systemUIChange' message.");
        this.f1298a.c("SystemChrome.systemUIChange", Arrays.asList(new Boolean[]{Boolean.valueOf(z2)}));
    }
}
