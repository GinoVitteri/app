package y;

import android.os.Build;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;
import z.e;
import z.h;
import z.i;

public class g {

    /* renamed from: a  reason: collision with root package name */
    public final i f1287a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public b f1288b;

    /* renamed from: c  reason: collision with root package name */
    public final i.c f1289c;

    class a implements i.c {
        a() {
        }

        public void a(h hVar, i.d dVar) {
            if (g.this.f1288b != null) {
                String str = hVar.f1475a;
                str.hashCode();
                if (!str.equals("Localization.getStringResource")) {
                    dVar.c();
                    return;
                }
                JSONObject jSONObject = (JSONObject) hVar.b();
                try {
                    dVar.b(g.this.f1288b.a(jSONObject.getString("key"), jSONObject.has("locale") ? jSONObject.getString("locale") : null));
                } catch (JSONException e2) {
                    dVar.a("error", e2.getMessage(), (Object) null);
                }
            }
        }
    }

    public interface b {
        String a(String str, String str2);
    }

    public g(n.a aVar) {
        a aVar2 = new a();
        this.f1289c = aVar2;
        i iVar = new i(aVar, "flutter/localization", e.f1474a);
        this.f1287a = iVar;
        iVar.e(aVar2);
    }

    public void b(List<Locale> list) {
        m.b.f("LocalizationChannel", "Sending Locales to Flutter.");
        ArrayList arrayList = new ArrayList();
        for (Locale next : list) {
            m.b.f("LocalizationChannel", "Locale (Language: " + next.getLanguage() + ", Country: " + next.getCountry() + ", Variant: " + next.getVariant() + ")");
            arrayList.add(next.getLanguage());
            arrayList.add(next.getCountry());
            arrayList.add(Build.VERSION.SDK_INT >= 21 ? next.getScript() : "");
            arrayList.add(next.getVariant());
        }
        this.f1287a.c("setLocale", arrayList);
    }

    public void c(b bVar) {
        this.f1288b = bVar;
    }
}
