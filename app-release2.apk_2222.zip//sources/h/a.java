package h;

public interface a<T> {
    void accept(T t2);
}
