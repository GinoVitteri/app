package h;

public final class c {
    public static <T> T a(T t2) {
        t2.getClass();
        return t2;
    }
}
