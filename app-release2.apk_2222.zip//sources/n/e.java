package n;

import android.os.Handler;
import android.os.Looper;
import d0.b;
import n.c;

public class e implements c.b {

    /* renamed from: a  reason: collision with root package name */
    private final Handler f993a = b.a(Looper.getMainLooper());

    public void a(Runnable runnable) {
        this.f993a.post(runnable);
    }
}
