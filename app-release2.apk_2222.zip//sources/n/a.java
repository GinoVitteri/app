package n;

import android.content.res.AssetManager;
import d0.g;
import io.flutter.embedding.engine.FlutterJNI;
import java.nio.ByteBuffer;
import java.util.List;
import z.b;
import z.q;

public class a implements z.b {

    /* renamed from: a  reason: collision with root package name */
    private final FlutterJNI f955a;

    /* renamed from: b  reason: collision with root package name */
    private final AssetManager f956b;

    /* renamed from: c  reason: collision with root package name */
    private final c f957c;

    /* renamed from: d  reason: collision with root package name */
    private final z.b f958d;

    /* renamed from: e  reason: collision with root package name */
    private boolean f959e = false;
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public String f960f;
    /* access modifiers changed from: private */

    /* renamed from: g  reason: collision with root package name */
    public d f961g;

    /* renamed from: h  reason: collision with root package name */
    private final b.a f962h;

    /* renamed from: n.a$a  reason: collision with other inner class name */
    class C0020a implements b.a {
        C0020a() {
        }

        public void a(ByteBuffer byteBuffer, b.C0035b bVar) {
            String unused = a.this.f960f = q.f1493b.a(byteBuffer);
            if (a.this.f961g != null) {
                a.this.f961g.a(a.this.f960f);
            }
        }
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public final String f964a;

        /* renamed from: b  reason: collision with root package name */
        public final String f965b;

        /* renamed from: c  reason: collision with root package name */
        public final String f966c;

        public b(String str, String str2) {
            this.f964a = str;
            this.f965b = null;
            this.f966c = str2;
        }

        public b(String str, String str2, String str3) {
            this.f964a = str;
            this.f965b = str2;
            this.f966c = str3;
        }

        public static b a() {
            p.d c2 = m.a.e().c();
            if (c2.h()) {
                return new b(c2.f(), "main");
            }
            throw new AssertionError("DartEntrypoints can only be created once a FlutterEngine is created.");
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            b bVar = (b) obj;
            if (!this.f964a.equals(bVar.f964a)) {
                return false;
            }
            return this.f966c.equals(bVar.f966c);
        }

        public int hashCode() {
            return (this.f964a.hashCode() * 31) + this.f966c.hashCode();
        }

        public String toString() {
            return "DartEntrypoint( bundle path: " + this.f964a + ", function: " + this.f966c + " )";
        }
    }

    private static class c implements z.b {

        /* renamed from: a  reason: collision with root package name */
        private final c f967a;

        private c(c cVar) {
            this.f967a = cVar;
        }

        /* synthetic */ c(c cVar, C0020a aVar) {
            this(cVar);
        }

        public void b(String str, ByteBuffer byteBuffer, b.C0035b bVar) {
            this.f967a.b(str, byteBuffer, bVar);
        }

        public void d(String str, b.a aVar, b.c cVar) {
            this.f967a.d(str, aVar, cVar);
        }

        public void e(String str, b.a aVar) {
            this.f967a.e(str, aVar);
        }
    }

    public interface d {
        void a(String str);
    }

    public a(FlutterJNI flutterJNI, AssetManager assetManager) {
        C0020a aVar = new C0020a();
        this.f962h = aVar;
        this.f955a = flutterJNI;
        this.f956b = assetManager;
        c cVar = new c(flutterJNI);
        this.f957c = cVar;
        cVar.e("flutter/isolate", aVar);
        this.f958d = new c(cVar, (C0020a) null);
        if (flutterJNI.isAttached()) {
            this.f959e = true;
        }
    }

    @Deprecated
    public void b(String str, ByteBuffer byteBuffer, b.C0035b bVar) {
        this.f958d.b(str, byteBuffer, bVar);
    }

    @Deprecated
    public void d(String str, b.a aVar, b.c cVar) {
        this.f958d.d(str, aVar, cVar);
    }

    @Deprecated
    public void e(String str, b.a aVar) {
        this.f958d.e(str, aVar);
    }

    public void g(b bVar, List<String> list) {
        if (this.f959e) {
            m.b.g("DartExecutor", "Attempted to run a DartExecutor that is already running.");
            return;
        }
        g.a("DartExecutor#executeDartEntrypoint");
        try {
            m.b.f("DartExecutor", "Executing Dart entrypoint: " + bVar);
            this.f955a.runBundleAndSnapshotFromLibrary(bVar.f964a, bVar.f966c, bVar.f965b, this.f956b, list);
            this.f959e = true;
        } finally {
            g.d();
        }
    }

    public String h() {
        return this.f960f;
    }

    public boolean i() {
        return this.f959e;
    }

    public void j() {
        if (this.f955a.isAttached()) {
            this.f955a.notifyLowMemoryWarning();
        }
    }

    public void k() {
        m.b.f("DartExecutor", "Attached to JNI. Registering the platform message handler for this Dart execution context.");
        this.f955a.setPlatformMessageHandler(this.f957c);
    }

    public void l() {
        m.b.f("DartExecutor", "Detached from JNI. De-registering the platform message handler for this Dart execution context.");
        this.f955a.setPlatformMessageHandler((d) null);
    }
}
