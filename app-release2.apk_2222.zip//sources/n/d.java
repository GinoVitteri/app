package n;

import java.nio.ByteBuffer;

public interface d {
    void a(int i2, ByteBuffer byteBuffer);

    void c(String str, ByteBuffer byteBuffer, int i2, long j2);
}
