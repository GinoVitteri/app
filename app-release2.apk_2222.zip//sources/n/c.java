package n;

import d0.g;
import io.flutter.embedding.engine.FlutterJNI;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import z.b;

class c implements z.b, d {

    /* renamed from: a  reason: collision with root package name */
    private final FlutterJNI f974a;

    /* renamed from: b  reason: collision with root package name */
    private final Map<String, d> f975b;

    /* renamed from: c  reason: collision with root package name */
    private Map<String, List<a>> f976c;

    /* renamed from: d  reason: collision with root package name */
    private final Object f977d;

    /* renamed from: e  reason: collision with root package name */
    private final AtomicBoolean f978e;

    /* renamed from: f  reason: collision with root package name */
    private final Map<Integer, b.C0035b> f979f;

    /* renamed from: g  reason: collision with root package name */
    private int f980g;

    /* renamed from: h  reason: collision with root package name */
    private final b f981h;

    /* renamed from: i  reason: collision with root package name */
    private WeakHashMap<b.c, b> f982i;

    /* renamed from: j  reason: collision with root package name */
    private f f983j;

    private static class a {

        /* renamed from: a  reason: collision with root package name */
        public final ByteBuffer f984a;

        /* renamed from: b  reason: collision with root package name */
        int f985b;

        /* renamed from: c  reason: collision with root package name */
        long f986c;

        a(ByteBuffer byteBuffer, int i2, long j2) {
            this.f984a = byteBuffer;
            this.f985b = i2;
            this.f986c = j2;
        }
    }

    interface b {
        void a(Runnable runnable);
    }

    /* renamed from: n.c$c  reason: collision with other inner class name */
    private static class C0021c implements f {

        /* renamed from: a  reason: collision with root package name */
        ExecutorService f987a = m.a.e().b();

        C0021c() {
        }
    }

    private static class d {

        /* renamed from: a  reason: collision with root package name */
        public final b.a f988a;

        /* renamed from: b  reason: collision with root package name */
        public final b f989b;

        d(b.a aVar, b bVar) {
            this.f988a = aVar;
            this.f989b = bVar;
        }
    }

    static class e implements b.C0035b {

        /* renamed from: a  reason: collision with root package name */
        private final FlutterJNI f990a;

        /* renamed from: b  reason: collision with root package name */
        private final int f991b;

        /* renamed from: c  reason: collision with root package name */
        private final AtomicBoolean f992c = new AtomicBoolean(false);

        e(FlutterJNI flutterJNI, int i2) {
            this.f990a = flutterJNI;
            this.f991b = i2;
        }

        public void a(ByteBuffer byteBuffer) {
            if (this.f992c.getAndSet(true)) {
                throw new IllegalStateException("Reply already submitted");
            } else if (byteBuffer == null) {
                this.f990a.invokePlatformMessageEmptyResponseCallback(this.f991b);
            } else {
                this.f990a.invokePlatformMessageResponseCallback(this.f991b, byteBuffer, byteBuffer.position());
            }
        }
    }

    interface f {
    }

    c(FlutterJNI flutterJNI) {
        this(flutterJNI, new C0021c());
    }

    c(FlutterJNI flutterJNI, f fVar) {
        this.f975b = new HashMap();
        this.f976c = new HashMap();
        this.f977d = new Object();
        this.f978e = new AtomicBoolean(false);
        this.f979f = new HashMap();
        this.f980g = 1;
        this.f981h = new e();
        this.f982i = new WeakHashMap<>();
        this.f974a = flutterJNI;
        this.f983j = fVar;
    }

    private void g(String str, d dVar, ByteBuffer byteBuffer, int i2, long j2) {
        d dVar2 = dVar;
        b bVar = dVar2 != null ? dVar2.f989b : null;
        g.b("PlatformChannel ScheduleHandler on " + str, i2);
        b bVar2 = new b(this, str, i2, dVar, byteBuffer, j2);
        if (bVar == null) {
            bVar = this.f981h;
        }
        bVar.a(bVar2);
    }

    private static void h(Error error) {
        Thread currentThread = Thread.currentThread();
        if (currentThread.getUncaughtExceptionHandler() != null) {
            currentThread.getUncaughtExceptionHandler().uncaughtException(currentThread, error);
            return;
        }
        throw error;
    }

    private void i(d dVar, ByteBuffer byteBuffer, int i2) {
        if (dVar != null) {
            try {
                m.b.f("DartMessenger", "Deferring to registered handler to process message.");
                dVar.f988a.a(byteBuffer, new e(this.f974a, i2));
            } catch (Exception e2) {
                m.b.c("DartMessenger", "Uncaught exception in binary message listener", e2);
            } catch (Error e3) {
                h(e3);
            }
        } else {
            m.b.f("DartMessenger", "No registered handler for message. Responding to Dart with empty reply message.");
            this.f974a.invokePlatformMessageEmptyResponseCallback(i2);
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void j(String str, int i2, d dVar, ByteBuffer byteBuffer, long j2) {
        g.e("PlatformChannel ScheduleHandler on " + str, i2);
        g.a("DartMessenger#handleMessageFromDart on " + str);
        try {
            i(dVar, byteBuffer, i2);
            if (byteBuffer != null && byteBuffer.isDirect()) {
                byteBuffer.limit(0);
            }
        } finally {
            this.f974a.cleanupMessageData(j2);
            g.d();
        }
    }

    public void a(int i2, ByteBuffer byteBuffer) {
        m.b.f("DartMessenger", "Received message reply from Dart.");
        b.C0035b remove = this.f979f.remove(Integer.valueOf(i2));
        if (remove != null) {
            try {
                m.b.f("DartMessenger", "Invoking registered callback for reply from Dart.");
                remove.a(byteBuffer);
                if (byteBuffer != null && byteBuffer.isDirect()) {
                    byteBuffer.limit(0);
                }
            } catch (Exception e2) {
                m.b.c("DartMessenger", "Uncaught exception in binary message reply handler", e2);
            } catch (Error e3) {
                h(e3);
            }
        }
    }

    public void b(String str, ByteBuffer byteBuffer, b.C0035b bVar) {
        g.a("DartMessenger#send on " + str);
        try {
            m.b.f("DartMessenger", "Sending message with callback over channel '" + str + "'");
            int i2 = this.f980g;
            this.f980g = i2 + 1;
            if (bVar != null) {
                this.f979f.put(Integer.valueOf(i2), bVar);
            }
            if (byteBuffer == null) {
                this.f974a.dispatchEmptyPlatformMessage(str, i2);
            } else {
                this.f974a.dispatchPlatformMessage(str, byteBuffer, byteBuffer.position(), i2);
            }
        } finally {
            g.d();
        }
    }

    public void c(String str, ByteBuffer byteBuffer, int i2, long j2) {
        d dVar;
        boolean z2;
        m.b.f("DartMessenger", "Received message from Dart over channel '" + str + "'");
        synchronized (this.f977d) {
            dVar = this.f975b.get(str);
            z2 = this.f978e.get() && dVar == null;
            if (z2) {
                if (!this.f976c.containsKey(str)) {
                    this.f976c.put(str, new LinkedList());
                }
                this.f976c.get(str).add(new a(byteBuffer, i2, j2));
            }
        }
        if (!z2) {
            g(str, dVar, byteBuffer, i2, j2);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0076, code lost:
        r10 = r10.iterator();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x007e, code lost:
        if (r10.hasNext() == false) goto L_0x009b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0080, code lost:
        r11 = (n.c.a) r10.next();
        g(r9, r8.f975b.get(r9), r11.f984a, r11.f985b, r11.f986c);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x009b, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void d(java.lang.String r9, z.b.a r10, z.b.c r11) {
        /*
            r8 = this;
            if (r10 != 0) goto L_0x002a
            java.lang.String r10 = "DartMessenger"
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r11.<init>()
            java.lang.String r0 = "Removing handler for channel '"
            r11.append(r0)
            r11.append(r9)
            java.lang.String r0 = "'"
            r11.append(r0)
            java.lang.String r11 = r11.toString()
            m.b.f(r10, r11)
            java.lang.Object r0 = r8.f977d
            monitor-enter(r0)
            java.util.Map<java.lang.String, n.c$d> r10 = r8.f975b     // Catch:{ all -> 0x0027 }
            r10.remove(r9)     // Catch:{ all -> 0x0027 }
            monitor-exit(r0)     // Catch:{ all -> 0x0027 }
            return
        L_0x0027:
            r9 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0027 }
            throw r9
        L_0x002a:
            r0 = 0
            if (r11 == 0) goto L_0x0041
            java.util.WeakHashMap<z.b$c, n.c$b> r0 = r8.f982i
            java.lang.Object r11 = r0.get(r11)
            r0 = r11
            n.c$b r0 = (n.c.b) r0
            if (r0 == 0) goto L_0x0039
            goto L_0x0041
        L_0x0039:
            java.lang.IllegalArgumentException r9 = new java.lang.IllegalArgumentException
            java.lang.String r10 = "Unrecognized TaskQueue, use BinaryMessenger to create your TaskQueue (ex makeBackgroundTaskQueue)."
            r9.<init>(r10)
            throw r9
        L_0x0041:
            java.lang.String r11 = "DartMessenger"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Setting handler for channel '"
            r1.append(r2)
            r1.append(r9)
            java.lang.String r2 = "'"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            m.b.f(r11, r1)
            java.lang.Object r11 = r8.f977d
            monitor-enter(r11)
            java.util.Map<java.lang.String, n.c$d> r1 = r8.f975b     // Catch:{ all -> 0x009c }
            n.c$d r2 = new n.c$d     // Catch:{ all -> 0x009c }
            r2.<init>(r10, r0)     // Catch:{ all -> 0x009c }
            r1.put(r9, r2)     // Catch:{ all -> 0x009c }
            java.util.Map<java.lang.String, java.util.List<n.c$a>> r10 = r8.f976c     // Catch:{ all -> 0x009c }
            java.lang.Object r10 = r10.remove(r9)     // Catch:{ all -> 0x009c }
            java.util.List r10 = (java.util.List) r10     // Catch:{ all -> 0x009c }
            if (r10 != 0) goto L_0x0075
            monitor-exit(r11)     // Catch:{ all -> 0x009c }
            return
        L_0x0075:
            monitor-exit(r11)     // Catch:{ all -> 0x009c }
            java.util.Iterator r10 = r10.iterator()
        L_0x007a:
            boolean r11 = r10.hasNext()
            if (r11 == 0) goto L_0x009b
            java.lang.Object r11 = r10.next()
            n.c$a r11 = (n.c.a) r11
            java.util.Map<java.lang.String, n.c$d> r0 = r8.f975b
            java.lang.Object r0 = r0.get(r9)
            r3 = r0
            n.c$d r3 = (n.c.d) r3
            java.nio.ByteBuffer r4 = r11.f984a
            int r5 = r11.f985b
            long r6 = r11.f986c
            r1 = r8
            r2 = r9
            r1.g(r2, r3, r4, r5, r6)
            goto L_0x007a
        L_0x009b:
            return
        L_0x009c:
            r9 = move-exception
            monitor-exit(r11)     // Catch:{ all -> 0x009c }
            goto L_0x00a0
        L_0x009f:
            throw r9
        L_0x00a0:
            goto L_0x009f
        */
        throw new UnsupportedOperationException("Method not decompiled: n.c.d(java.lang.String, z.b$a, z.b$c):void");
    }

    public void e(String str, b.a aVar) {
        d(str, aVar, (b.c) null);
    }
}
