package n;

import java.nio.ByteBuffer;
import n.c;

public final /* synthetic */ class b implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ c f968d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ String f969e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f970f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ c.d f971g;

    /* renamed from: h  reason: collision with root package name */
    public final /* synthetic */ ByteBuffer f972h;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ long f973i;

    public /* synthetic */ b(c cVar, String str, int i2, c.d dVar, ByteBuffer byteBuffer, long j2) {
        this.f968d = cVar;
        this.f969e = str;
        this.f970f = i2;
        this.f971g = dVar;
        this.f972h = byteBuffer;
        this.f973i = j2;
    }

    public final void run() {
        this.f968d.j(this.f969e, this.f970f, this.f971g, this.f972h, this.f973i);
    }
}
