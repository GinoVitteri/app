package g;

import android.os.Handler;
import h.c;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

public final class a {

    /* renamed from: g.a$a  reason: collision with other inner class name */
    private static class C0004a implements Executor {

        /* renamed from: d  reason: collision with root package name */
        private final Handler f153d;

        C0004a(Handler handler) {
            this.f153d = (Handler) c.a(handler);
        }

        public void execute(Runnable runnable) {
            if (!this.f153d.post((Runnable) c.a(runnable))) {
                throw new RejectedExecutionException(this.f153d + " is shutting down");
            }
        }
    }

    public static Executor a(Handler handler) {
        return new C0004a(handler);
    }
}
