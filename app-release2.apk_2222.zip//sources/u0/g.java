package u0;

class g extends f {
}
