package u0;

class h extends g {
}
