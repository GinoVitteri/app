package u0;

import g0.v;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.i;
import kotlin.jvm.internal.j;
import o0.l;
import o0.p;
import r0.c;

class n extends m {

    static final class a extends j implements p<CharSequence, Integer, f0.j<? extends Integer, ? extends Integer>> {

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ List<String> f1073d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ boolean f1074e;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(List<String> list, boolean z2) {
            super(2);
            this.f1073d = list;
            this.f1074e = z2;
        }

        public final f0.j<Integer, Integer> a(CharSequence charSequence, int i2) {
            i.e(charSequence, "$this$$receiver");
            f0.j p2 = n.s(charSequence, this.f1073d, i2, this.f1074e, false);
            if (p2 != null) {
                return f0.n.a(p2.c(), Integer.valueOf(((String) p2.d()).length()));
            }
            return null;
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return a((CharSequence) obj, ((Number) obj2).intValue());
        }
    }

    static final class b extends j implements l<c, String> {

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ CharSequence f1075d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(CharSequence charSequence) {
            super(1);
            this.f1075d = charSequence;
        }

        /* renamed from: a */
        public final String invoke(c cVar) {
            i.e(cVar, "it");
            return n.P(this.f1075d, cVar);
        }
    }

    public static /* synthetic */ int A(CharSequence charSequence, String str, int i2, boolean z2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = 0;
        }
        if ((i3 & 4) != 0) {
            z2 = false;
        }
        return w(charSequence, str, i2, z2);
    }

    public static final int B(CharSequence charSequence, char[] cArr, int i2, boolean z2) {
        boolean z3;
        i.e(charSequence, "<this>");
        i.e(cArr, "chars");
        if (z2 || cArr.length != 1 || !(charSequence instanceof String)) {
            v d2 = new c(f.a(i2, 0), u(charSequence)).iterator();
            while (d2.hasNext()) {
                int nextInt = d2.nextInt();
                char charAt = charSequence.charAt(nextInt);
                int length = cArr.length;
                int i3 = 0;
                while (true) {
                    if (i3 >= length) {
                        z3 = false;
                        continue;
                        break;
                    } else if (b.d(cArr[i3], charAt, z2)) {
                        z3 = true;
                        continue;
                        break;
                    } else {
                        i3++;
                    }
                }
                if (z3) {
                    return nextInt;
                }
            }
            return -1;
        }
        return ((String) charSequence).indexOf(e.f(cArr), i2);
    }

    public static final int C(CharSequence charSequence, char c2, int i2, boolean z2) {
        i.e(charSequence, "<this>");
        if (!z2 && (charSequence instanceof String)) {
            return ((String) charSequence).lastIndexOf(c2, i2);
        }
        return G(charSequence, new char[]{c2}, i2, z2);
    }

    public static final int D(CharSequence charSequence, String str, int i2, boolean z2) {
        i.e(charSequence, "<this>");
        i.e(str, "string");
        return (z2 || !(charSequence instanceof String)) ? x(charSequence, str, i2, 0, z2, true) : ((String) charSequence).lastIndexOf(str, i2);
    }

    public static /* synthetic */ int E(CharSequence charSequence, char c2, int i2, boolean z2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = u(charSequence);
        }
        if ((i3 & 4) != 0) {
            z2 = false;
        }
        return C(charSequence, c2, i2, z2);
    }

    public static /* synthetic */ int F(CharSequence charSequence, String str, int i2, boolean z2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = u(charSequence);
        }
        if ((i3 & 4) != 0) {
            z2 = false;
        }
        return D(charSequence, str, i2, z2);
    }

    public static final int G(CharSequence charSequence, char[] cArr, int i2, boolean z2) {
        i.e(charSequence, "<this>");
        i.e(cArr, "chars");
        if (z2 || cArr.length != 1 || !(charSequence instanceof String)) {
            for (int c2 = f.c(i2, u(charSequence)); -1 < c2; c2--) {
                char charAt = charSequence.charAt(c2);
                int length = cArr.length;
                boolean z3 = false;
                int i3 = 0;
                while (true) {
                    if (i3 >= length) {
                        break;
                    } else if (b.d(cArr[i3], charAt, z2)) {
                        z3 = true;
                        break;
                    } else {
                        i3++;
                    }
                }
                if (z3) {
                    return c2;
                }
            }
            return -1;
        }
        return ((String) charSequence).lastIndexOf(e.f(cArr), i2);
    }

    public static final t0.b<String> H(CharSequence charSequence) {
        i.e(charSequence, "<this>");
        return O(charSequence, new String[]{"\r\n", "\n", "\r"}, false, 0, 6, (Object) null);
    }

    public static final List<String> I(CharSequence charSequence) {
        i.e(charSequence, "<this>");
        return h.e(H(charSequence));
    }

    private static final t0.b<c> J(CharSequence charSequence, String[] strArr, int i2, boolean z2, int i3) {
        M(i3);
        return new c(charSequence, i2, i3, new a(d.a(strArr), z2));
    }

    static /* synthetic */ t0.b K(CharSequence charSequence, String[] strArr, int i2, boolean z2, int i3, int i4, Object obj) {
        if ((i4 & 2) != 0) {
            i2 = 0;
        }
        if ((i4 & 4) != 0) {
            z2 = false;
        }
        if ((i4 & 8) != 0) {
            i3 = 0;
        }
        return J(charSequence, strArr, i2, z2, i3);
    }

    public static final boolean L(CharSequence charSequence, int i2, CharSequence charSequence2, int i3, int i4, boolean z2) {
        i.e(charSequence, "<this>");
        i.e(charSequence2, "other");
        if (i3 < 0 || i2 < 0 || i2 > charSequence.length() - i4 || i3 > charSequence2.length() - i4) {
            return false;
        }
        for (int i5 = 0; i5 < i4; i5++) {
            if (!b.d(charSequence.charAt(i2 + i5), charSequence2.charAt(i3 + i5), z2)) {
                return false;
            }
        }
        return true;
    }

    public static final void M(int i2) {
        if (!(i2 >= 0)) {
            throw new IllegalArgumentException(("Limit must be non-negative, but was " + i2).toString());
        }
    }

    public static final t0.b<String> N(CharSequence charSequence, String[] strArr, boolean z2, int i2) {
        i.e(charSequence, "<this>");
        i.e(strArr, "delimiters");
        return h.c(K(charSequence, strArr, 0, z2, i2, 2, (Object) null), new b(charSequence));
    }

    public static /* synthetic */ t0.b O(CharSequence charSequence, String[] strArr, boolean z2, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            z2 = false;
        }
        if ((i3 & 4) != 0) {
            i2 = 0;
        }
        return N(charSequence, strArr, z2, i2);
    }

    public static final String P(CharSequence charSequence, c cVar) {
        i.e(charSequence, "<this>");
        i.e(cVar, "range");
        return charSequence.subSequence(cVar.h().intValue(), cVar.g().intValue() + 1).toString();
    }

    public static final String Q(String str, char c2, String str2) {
        i.e(str, "<this>");
        i.e(str2, "missingDelimiterValue");
        int z2 = z(str, c2, 0, false, 6, (Object) null);
        if (z2 == -1) {
            return str2;
        }
        String substring = str.substring(z2 + 1, str.length());
        i.d(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    public static final String R(String str, String str2, String str3) {
        i.e(str, "<this>");
        i.e(str2, "delimiter");
        i.e(str3, "missingDelimiterValue");
        int A = A(str, str2, 0, false, 6, (Object) null);
        if (A == -1) {
            return str3;
        }
        String substring = str.substring(A + str2.length(), str.length());
        i.d(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    public static /* synthetic */ String S(String str, char c2, String str2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            str2 = str;
        }
        return Q(str, c2, str2);
    }

    public static /* synthetic */ String T(String str, String str2, String str3, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            str3 = str;
        }
        return R(str, str2, str3);
    }

    public static final String U(String str, char c2, String str2) {
        i.e(str, "<this>");
        i.e(str2, "missingDelimiterValue");
        int E = E(str, c2, 0, false, 6, (Object) null);
        if (E == -1) {
            return str2;
        }
        String substring = str.substring(E + 1, str.length());
        i.d(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    public static /* synthetic */ String V(String str, char c2, String str2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            str2 = str;
        }
        return U(str, c2, str2);
    }

    public static final String W(String str, char c2, String str2) {
        i.e(str, "<this>");
        i.e(str2, "missingDelimiterValue");
        int z2 = z(str, c2, 0, false, 6, (Object) null);
        if (z2 == -1) {
            return str2;
        }
        String substring = str.substring(0, z2);
        i.d(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    public static final String X(String str, String str2, String str3) {
        i.e(str, "<this>");
        i.e(str2, "delimiter");
        i.e(str3, "missingDelimiterValue");
        int A = A(str, str2, 0, false, 6, (Object) null);
        if (A == -1) {
            return str3;
        }
        String substring = str.substring(0, A);
        i.d(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    public static /* synthetic */ String Y(String str, char c2, String str2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            str2 = str;
        }
        return W(str, c2, str2);
    }

    public static /* synthetic */ String Z(String str, String str2, String str3, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            str3 = str;
        }
        return X(str, str2, str3);
    }

    public static CharSequence a0(CharSequence charSequence) {
        i.e(charSequence, "<this>");
        int length = charSequence.length() - 1;
        int i2 = 0;
        boolean z2 = false;
        while (i2 <= length) {
            boolean c2 = a.c(charSequence.charAt(!z2 ? i2 : length));
            if (!z2) {
                if (!c2) {
                    z2 = true;
                } else {
                    i2++;
                }
            } else if (!c2) {
                break;
            } else {
                length--;
            }
        }
        return charSequence.subSequence(i2, length + 1);
    }

    public static final boolean q(CharSequence charSequence, CharSequence charSequence2, boolean z2) {
        i.e(charSequence, "<this>");
        i.e(charSequence2, "other");
        if (charSequence2 instanceof String) {
            if (A(charSequence, (String) charSequence2, 0, z2, 2, (Object) null) >= 0) {
                return true;
            }
        } else {
            if (y(charSequence, charSequence2, 0, charSequence.length(), z2, false, 16, (Object) null) >= 0) {
                return true;
            }
        }
        return false;
    }

    public static /* synthetic */ boolean r(CharSequence charSequence, CharSequence charSequence2, boolean z2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z2 = false;
        }
        return q(charSequence, charSequence2, z2);
    }

    /* access modifiers changed from: private */
    public static final f0.j<Integer, String> s(CharSequence charSequence, Collection<String> collection, int i2, boolean z2, boolean z3) {
        int i3;
        T t2;
        String str;
        T t3;
        if (z2 || collection.size() != 1) {
            r0.a cVar = !z3 ? new c(f.a(i2, 0), charSequence.length()) : f.f(f.c(i2, u(charSequence)), 0);
            if (charSequence instanceof String) {
                i3 = cVar.a();
                int b2 = cVar.b();
                int c2 = cVar.c();
                if ((c2 > 0 && i3 <= b2) || (c2 < 0 && b2 <= i3)) {
                    while (true) {
                        Iterator<T> it = collection.iterator();
                        while (true) {
                            if (!it.hasNext()) {
                                t3 = null;
                                break;
                            }
                            t3 = it.next();
                            String str2 = (String) t3;
                            if (m.m(str2, 0, (String) charSequence, i3, str2.length(), z2)) {
                                break;
                            }
                        }
                        str = (String) t3;
                        if (str == null) {
                            if (i3 == b2) {
                                break;
                            }
                            i3 += c2;
                        } else {
                            break;
                        }
                    }
                }
                return null;
            }
            int a2 = cVar.a();
            int b3 = cVar.b();
            int c3 = cVar.c();
            if ((c3 > 0 && a2 <= b3) || (c3 < 0 && b3 <= a2)) {
                while (true) {
                    Iterator<T> it2 = collection.iterator();
                    while (true) {
                        if (!it2.hasNext()) {
                            t2 = null;
                            break;
                        }
                        t2 = it2.next();
                        String str3 = (String) t2;
                        if (L(str3, 0, charSequence, i3, str3.length(), z2)) {
                            break;
                        }
                    }
                    str = (String) t2;
                    if (str == null) {
                        if (i3 == b3) {
                            break;
                        }
                        a2 = i3 + c3;
                    } else {
                        break;
                    }
                }
            }
            return null;
            return f0.n.a(Integer.valueOf(i3), str);
        }
        String str4 = (String) q.n(collection);
        CharSequence charSequence2 = charSequence;
        String str5 = str4;
        int i4 = i2;
        int A = !z3 ? A(charSequence2, str5, i4, false, 4, (Object) null) : F(charSequence2, str5, i4, false, 4, (Object) null);
        if (A < 0) {
            return null;
        }
        return f0.n.a(Integer.valueOf(A), str4);
    }

    public static final c t(CharSequence charSequence) {
        i.e(charSequence, "<this>");
        return new c(0, charSequence.length() - 1);
    }

    public static final int u(CharSequence charSequence) {
        i.e(charSequence, "<this>");
        return charSequence.length() - 1;
    }

    public static final int v(CharSequence charSequence, char c2, int i2, boolean z2) {
        i.e(charSequence, "<this>");
        if (!z2 && (charSequence instanceof String)) {
            return ((String) charSequence).indexOf(c2, i2);
        }
        return B(charSequence, new char[]{c2}, i2, z2);
    }

    public static final int w(CharSequence charSequence, String str, int i2, boolean z2) {
        i.e(charSequence, "<this>");
        i.e(str, "string");
        if (!z2 && (charSequence instanceof String)) {
            return ((String) charSequence).indexOf(str, i2);
        }
        return y(charSequence, str, i2, charSequence.length(), z2, false, 16, (Object) null);
    }

    private static final int x(CharSequence charSequence, CharSequence charSequence2, int i2, int i3, boolean z2, boolean z3) {
        r0.a cVar = !z3 ? new c(f.a(i2, 0), f.c(i3, charSequence.length())) : f.f(f.c(i2, u(charSequence)), f.a(i3, 0));
        if (!(charSequence instanceof String) || !(charSequence2 instanceof String)) {
            int a2 = cVar.a();
            int b2 = cVar.b();
            int c2 = cVar.c();
            if ((c2 <= 0 || a2 > b2) && (c2 >= 0 || b2 > a2)) {
                return -1;
            }
            while (true) {
                if (L(charSequence2, 0, charSequence, a2, charSequence2.length(), z2)) {
                    return a2;
                }
                if (a2 == b2) {
                    return -1;
                }
                a2 += c2;
            }
        } else {
            int a3 = cVar.a();
            int b3 = cVar.b();
            int c3 = cVar.c();
            if ((c3 <= 0 || a3 > b3) && (c3 >= 0 || b3 > a3)) {
                return -1;
            }
            while (true) {
                if (m.m((String) charSequence2, 0, (String) charSequence, a3, charSequence2.length(), z2)) {
                    return a3;
                }
                if (a3 == b3) {
                    return -1;
                }
                a3 += c3;
            }
        }
    }

    static /* synthetic */ int y(CharSequence charSequence, CharSequence charSequence2, int i2, int i3, boolean z2, boolean z3, int i4, Object obj) {
        return x(charSequence, charSequence2, i2, i3, z2, (i4 & 16) != 0 ? false : z3);
    }

    public static /* synthetic */ int z(CharSequence charSequence, char c2, int i2, boolean z2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = 0;
        }
        if ((i3 & 4) != 0) {
            z2 = false;
        }
        return v(charSequence, c2, i2, z2);
    }
}
