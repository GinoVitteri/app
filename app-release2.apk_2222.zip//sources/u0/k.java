package u0;

class k extends j {
}
