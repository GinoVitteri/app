package u0;

class o extends n {
}
