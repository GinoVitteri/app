package u0;

class j extends i {
}
