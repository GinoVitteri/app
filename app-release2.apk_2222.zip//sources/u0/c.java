package u0;

import f0.j;
import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.i;
import o0.p;
import t0.b;

final class c implements b<r0.c> {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final CharSequence f1061a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final int f1062b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public final int f1063c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public final p<CharSequence, Integer, j<Integer, Integer>> f1064d;

    public static final class a implements Iterator<r0.c> {

        /* renamed from: d  reason: collision with root package name */
        private int f1065d = -1;

        /* renamed from: e  reason: collision with root package name */
        private int f1066e;

        /* renamed from: f  reason: collision with root package name */
        private int f1067f;

        /* renamed from: g  reason: collision with root package name */
        private r0.c f1068g;

        /* renamed from: h  reason: collision with root package name */
        private int f1069h;

        /* renamed from: i  reason: collision with root package name */
        final /* synthetic */ c f1070i;

        a(c cVar) {
            this.f1070i = cVar;
            int e2 = f.e(cVar.f1062b, 0, cVar.f1061a.length());
            this.f1066e = e2;
            this.f1067f = e2;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:6:0x0021, code lost:
            if (r0 < u0.c.c(r6.f1070i)) goto L_0x0023;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private final void a() {
            /*
                r6 = this;
                int r0 = r6.f1067f
                r1 = 0
                if (r0 >= 0) goto L_0x000c
                r6.f1065d = r1
                r0 = 0
                r6.f1068g = r0
                goto L_0x0099
            L_0x000c:
                u0.c r0 = r6.f1070i
                int r0 = r0.f1063c
                r2 = -1
                r3 = 1
                if (r0 <= 0) goto L_0x0023
                int r0 = r6.f1069h
                int r0 = r0 + r3
                r6.f1069h = r0
                u0.c r4 = r6.f1070i
                int r4 = r4.f1063c
                if (r0 >= r4) goto L_0x0031
            L_0x0023:
                int r0 = r6.f1067f
                u0.c r4 = r6.f1070i
                java.lang.CharSequence r4 = r4.f1061a
                int r4 = r4.length()
                if (r0 <= r4) goto L_0x0047
            L_0x0031:
                r0.c r0 = new r0.c
                int r1 = r6.f1066e
                u0.c r4 = r6.f1070i
                java.lang.CharSequence r4 = r4.f1061a
                int r4 = u0.n.u(r4)
                r0.<init>(r1, r4)
            L_0x0042:
                r6.f1068g = r0
            L_0x0044:
                r6.f1067f = r2
                goto L_0x0097
            L_0x0047:
                u0.c r0 = r6.f1070i
                o0.p r0 = r0.f1064d
                u0.c r4 = r6.f1070i
                java.lang.CharSequence r4 = r4.f1061a
                int r5 = r6.f1067f
                java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
                java.lang.Object r0 = r0.invoke(r4, r5)
                f0.j r0 = (f0.j) r0
                if (r0 != 0) goto L_0x0073
                r0.c r0 = new r0.c
                int r1 = r6.f1066e
                u0.c r4 = r6.f1070i
                java.lang.CharSequence r4 = r4.f1061a
                int r4 = u0.n.u(r4)
                r0.<init>(r1, r4)
                goto L_0x0042
            L_0x0073:
                java.lang.Object r2 = r0.a()
                java.lang.Number r2 = (java.lang.Number) r2
                int r2 = r2.intValue()
                java.lang.Object r0 = r0.b()
                java.lang.Number r0 = (java.lang.Number) r0
                int r0 = r0.intValue()
                int r4 = r6.f1066e
                r0.c r4 = r0.f.g(r4, r2)
                r6.f1068g = r4
                int r2 = r2 + r0
                r6.f1066e = r2
                if (r0 != 0) goto L_0x0095
                r1 = 1
            L_0x0095:
                int r2 = r2 + r1
                goto L_0x0044
            L_0x0097:
                r6.f1065d = r3
            L_0x0099:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: u0.c.a.a():void");
        }

        /* renamed from: b */
        public r0.c next() {
            if (this.f1065d == -1) {
                a();
            }
            if (this.f1065d != 0) {
                r0.c cVar = this.f1068g;
                i.c(cVar, "null cannot be cast to non-null type kotlin.ranges.IntRange");
                this.f1068g = null;
                this.f1065d = -1;
                return cVar;
            }
            throw new NoSuchElementException();
        }

        public boolean hasNext() {
            if (this.f1065d == -1) {
                a();
            }
            return this.f1065d == 1;
        }

        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public c(CharSequence charSequence, int i2, int i3, p<? super CharSequence, ? super Integer, j<Integer, Integer>> pVar) {
        i.e(charSequence, "input");
        i.e(pVar, "getNextMatch");
        this.f1061a = charSequence;
        this.f1062b = i2;
        this.f1063c = i3;
        this.f1064d = pVar;
    }

    public Iterator<r0.c> iterator() {
        return new a(this);
    }
}
