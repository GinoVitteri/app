package u0;

import kotlin.jvm.internal.i;

class p extends o {
    public static final String b0(String str, int i2) {
        i.e(str, "<this>");
        if (i2 >= 0) {
            String substring = str.substring(f.c(i2, str.length()));
            i.d(substring, "this as java.lang.String).substring(startIndex)");
            return substring;
        }
        throw new IllegalArgumentException(("Requested character count " + i2 + " is less than zero.").toString());
    }
}
