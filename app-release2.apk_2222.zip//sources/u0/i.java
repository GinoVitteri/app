package u0;

class i extends h {
}
