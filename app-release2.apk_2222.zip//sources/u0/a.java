package u0;

import r0.c;

class a {
    public static final int a(int i2) {
        if (new c(2, 36).f(i2)) {
            return i2;
        }
        throw new IllegalArgumentException("radix " + i2 + " was not in valid range " + new c(2, 36));
    }

    public static final int b(char c2, int i2) {
        return Character.digit(c2, i2);
    }

    public static final boolean c(char c2) {
        return Character.isWhitespace(c2) || Character.isSpaceChar(c2);
    }
}
