package u0;

public final class d extends p {
}
