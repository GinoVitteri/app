package androidx.savedstate;

import android.annotation.SuppressLint;

@SuppressLint({"RestrictedApi"})
public final class a {
}
