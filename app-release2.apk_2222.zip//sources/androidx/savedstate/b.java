package androidx.savedstate;

import androidx.lifecycle.f;

public interface b extends f {
    a j();
}
