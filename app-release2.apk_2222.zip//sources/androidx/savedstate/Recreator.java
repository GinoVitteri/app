package androidx.savedstate;

import android.annotation.SuppressLint;
import androidx.lifecycle.c;
import androidx.lifecycle.d;
import androidx.lifecycle.f;

@SuppressLint({"RestrictedApi"})
final class Recreator implements d {

    /* renamed from: a  reason: collision with root package name */
    private final b f69a;

    public void d(f fVar, c.a aVar) {
        if (aVar != c.a.ON_CREATE) {
            throw new AssertionError("Next event must be ON_CREATE");
        }
        fVar.e().b(this);
        this.f69a.j();
        throw null;
    }
}
