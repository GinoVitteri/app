package androidx.activity;

import androidx.lifecycle.c;
import androidx.lifecycle.d;
import androidx.lifecycle.f;

class ComponentActivity$2 implements d {
    public void d(f fVar, c.a aVar) {
        if (aVar == c.a.ON_STOP) {
            throw null;
        }
    }
}
