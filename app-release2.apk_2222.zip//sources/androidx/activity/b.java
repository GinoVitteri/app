package androidx.activity;

import androidx.lifecycle.f;

public interface b extends f {
    OnBackPressedDispatcher i();
}
