package androidx.activity;

import androidx.lifecycle.c;
import androidx.lifecycle.d;
import androidx.lifecycle.f;

public final class OnBackPressedDispatcher {

    private class LifecycleOnBackPressedCancellable implements d, a {

        /* renamed from: a  reason: collision with root package name */
        private final c f21a;

        /* renamed from: b  reason: collision with root package name */
        private a f22b;

        public void cancel() {
            this.f21a.b(this);
            throw null;
        }

        public void d(f fVar, c.a aVar) {
            if (aVar == c.a.ON_START) {
                throw null;
            } else if (aVar == c.a.ON_STOP) {
                a aVar2 = this.f22b;
                if (aVar2 != null) {
                    aVar2.cancel();
                }
            } else if (aVar == c.a.ON_DESTROY) {
                cancel();
            }
        }
    }
}
