package androidx.activity;

interface a {
    void cancel();
}
