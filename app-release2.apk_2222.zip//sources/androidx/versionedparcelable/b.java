package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.SparseIntArray;
import b.a;
import java.lang.reflect.Method;

class b extends a {

    /* renamed from: d  reason: collision with root package name */
    private final SparseIntArray f74d;

    /* renamed from: e  reason: collision with root package name */
    private final Parcel f75e;

    /* renamed from: f  reason: collision with root package name */
    private final int f76f;

    /* renamed from: g  reason: collision with root package name */
    private final int f77g;

    /* renamed from: h  reason: collision with root package name */
    private final String f78h;

    /* renamed from: i  reason: collision with root package name */
    private int f79i;

    /* renamed from: j  reason: collision with root package name */
    private int f80j;

    /* renamed from: k  reason: collision with root package name */
    private int f81k;

    b(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new a(), new a(), new a());
    }

    private b(Parcel parcel, int i2, int i3, String str, a<String, Method> aVar, a<String, Method> aVar2, a<String, Class> aVar3) {
        super(aVar, aVar2, aVar3);
        this.f74d = new SparseIntArray();
        this.f79i = -1;
        this.f81k = -1;
        this.f75e = parcel;
        this.f76f = i2;
        this.f77g = i3;
        this.f80j = i2;
        this.f78h = str;
    }

    public void A(byte[] bArr) {
        if (bArr != null) {
            this.f75e.writeInt(bArr.length);
            this.f75e.writeByteArray(bArr);
            return;
        }
        this.f75e.writeInt(-1);
    }

    /* access modifiers changed from: protected */
    public void C(CharSequence charSequence) {
        TextUtils.writeToParcel(charSequence, this.f75e, 0);
    }

    public void E(int i2) {
        this.f75e.writeInt(i2);
    }

    public void G(Parcelable parcelable) {
        this.f75e.writeParcelable(parcelable, 0);
    }

    public void I(String str) {
        this.f75e.writeString(str);
    }

    public void a() {
        int i2 = this.f79i;
        if (i2 >= 0) {
            int i3 = this.f74d.get(i2);
            int dataPosition = this.f75e.dataPosition();
            this.f75e.setDataPosition(i3);
            this.f75e.writeInt(dataPosition - i3);
            this.f75e.setDataPosition(dataPosition);
        }
    }

    /* access modifiers changed from: protected */
    public a b() {
        Parcel parcel = this.f75e;
        int dataPosition = parcel.dataPosition();
        int i2 = this.f80j;
        if (i2 == this.f76f) {
            i2 = this.f77g;
        }
        int i3 = i2;
        return new b(parcel, dataPosition, i3, this.f78h + "  ", this.f71a, this.f72b, this.f73c);
    }

    public boolean g() {
        return this.f75e.readInt() != 0;
    }

    public byte[] i() {
        int readInt = this.f75e.readInt();
        if (readInt < 0) {
            return null;
        }
        byte[] bArr = new byte[readInt];
        this.f75e.readByteArray(bArr);
        return bArr;
    }

    /* access modifiers changed from: protected */
    public CharSequence k() {
        return (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(this.f75e);
    }

    public boolean m(int i2) {
        while (this.f80j < this.f77g) {
            int i3 = this.f81k;
            if (i3 == i2) {
                return true;
            }
            if (String.valueOf(i3).compareTo(String.valueOf(i2)) > 0) {
                return false;
            }
            this.f75e.setDataPosition(this.f80j);
            int readInt = this.f75e.readInt();
            this.f81k = this.f75e.readInt();
            this.f80j += readInt;
        }
        return this.f81k == i2;
    }

    public int o() {
        return this.f75e.readInt();
    }

    public <T extends Parcelable> T q() {
        return this.f75e.readParcelable(getClass().getClassLoader());
    }

    public String s() {
        return this.f75e.readString();
    }

    public void w(int i2) {
        a();
        this.f79i = i2;
        this.f74d.put(i2, this.f75e.dataPosition());
        E(0);
        E(i2);
    }

    public void y(boolean z2) {
        this.f75e.writeInt(z2 ? 1 : 0);
    }
}
