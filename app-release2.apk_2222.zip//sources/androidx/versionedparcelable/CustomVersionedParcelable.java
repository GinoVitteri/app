package androidx.versionedparcelable;

import l.a;

public abstract class CustomVersionedParcelable implements a {
}
