package androidx.window.java.layout;

import f0.q;
import h.a;
import h0.d;
import y0.c;

public final class WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1 implements c<T> {
    final /* synthetic */ a $consumer$inlined;

    public WindowInfoTrackerCallbackAdapter$addListener$1$1$invokeSuspend$$inlined$collect$1(a aVar) {
        this.$consumer$inlined = aVar;
    }

    public Object emit(T t2, d<? super q> dVar) {
        this.$consumer$inlined.accept(t2);
        return q.f152a;
    }
}
