package androidx.window.java;

public final class R {
    private R() {
    }
}
