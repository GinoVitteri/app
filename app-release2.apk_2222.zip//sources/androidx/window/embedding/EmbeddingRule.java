package androidx.window.embedding;

import androidx.window.core.ExperimentalWindowApi;

@ExperimentalWindowApi
public abstract class EmbeddingRule {
}
