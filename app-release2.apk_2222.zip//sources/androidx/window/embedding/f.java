package androidx.window.embedding;

import android.util.Pair;
import java.util.Set;
import java.util.function.Predicate;

public final /* synthetic */ class f implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ EmbeddingAdapter f87a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Set f88b;

    public /* synthetic */ f(EmbeddingAdapter embeddingAdapter, Set set) {
        this.f87a = embeddingAdapter;
        this.f88b = set;
    }

    public final boolean test(Object obj) {
        return EmbeddingAdapter.m1translateActivityPairPredicates$lambda1(this.f87a, this.f88b, (Pair) obj);
    }
}
