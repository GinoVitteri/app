package androidx.window.embedding;

import android.util.Pair;
import java.util.Set;
import java.util.function.Predicate;

public final /* synthetic */ class b implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ EmbeddingAdapter f82a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Set f83b;

    public /* synthetic */ b(EmbeddingAdapter embeddingAdapter, Set set) {
        this.f82a = embeddingAdapter;
        this.f83b = set;
    }

    public final boolean test(Object obj) {
        return EmbeddingAdapter.m0translateActivityIntentPredicates$lambda3(this.f82a, this.f83b, (Pair) obj);
    }
}
