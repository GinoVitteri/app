package androidx.window.embedding;

public final /* synthetic */ class a {
    public static /* synthetic */ int a(boolean z2) {
        return z2 ? 1231 : 1237;
    }
}
