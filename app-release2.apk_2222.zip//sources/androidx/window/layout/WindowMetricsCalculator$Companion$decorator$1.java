package androidx.window.layout;

import kotlin.jvm.internal.i;
import kotlin.jvm.internal.j;
import o0.l;

final class WindowMetricsCalculator$Companion$decorator$1 extends j implements l<WindowMetricsCalculator, WindowMetricsCalculator> {
    public static final WindowMetricsCalculator$Companion$decorator$1 INSTANCE = new WindowMetricsCalculator$Companion$decorator$1();

    WindowMetricsCalculator$Companion$decorator$1() {
        super(1);
    }

    public final WindowMetricsCalculator invoke(WindowMetricsCalculator windowMetricsCalculator) {
        i.e(windowMetricsCalculator, "it");
        return windowMetricsCalculator;
    }
}
