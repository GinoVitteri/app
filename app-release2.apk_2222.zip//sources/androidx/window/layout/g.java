package androidx.window.layout;

import java.util.concurrent.Executor;

public final /* synthetic */ class g implements Executor {
    public final void execute(Runnable runnable) {
        runnable.run();
    }
}
