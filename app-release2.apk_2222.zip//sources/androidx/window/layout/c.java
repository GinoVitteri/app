package androidx.window.layout;

public final /* synthetic */ class c {
}
