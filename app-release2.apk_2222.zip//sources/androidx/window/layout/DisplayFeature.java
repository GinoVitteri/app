package androidx.window.layout;

import android.graphics.Rect;

public interface DisplayFeature {
    Rect getBounds();
}
