package androidx.window.layout;

import h.a;

public final /* synthetic */ class f implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ x0.f f93a;

    public /* synthetic */ f(x0.f fVar) {
        this.f93a = fVar;
    }

    public final void accept(Object obj) {
        WindowInfoTrackerImpl$windowLayoutInfo$1.m7invokeSuspend$lambda0(this.f93a, (WindowLayoutInfo) obj);
    }
}
