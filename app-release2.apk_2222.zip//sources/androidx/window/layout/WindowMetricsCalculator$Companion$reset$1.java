package androidx.window.layout;

import kotlin.jvm.internal.i;
import kotlin.jvm.internal.j;
import o0.l;

final class WindowMetricsCalculator$Companion$reset$1 extends j implements l<WindowMetricsCalculator, WindowMetricsCalculator> {
    public static final WindowMetricsCalculator$Companion$reset$1 INSTANCE = new WindowMetricsCalculator$Companion$reset$1();

    WindowMetricsCalculator$Companion$reset$1() {
        super(1);
    }

    public final WindowMetricsCalculator invoke(WindowMetricsCalculator windowMetricsCalculator) {
        i.e(windowMetricsCalculator, "it");
        return windowMetricsCalculator;
    }
}
