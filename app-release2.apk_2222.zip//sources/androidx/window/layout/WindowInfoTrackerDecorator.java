package androidx.window.layout;

public interface WindowInfoTrackerDecorator {
    WindowInfoTracker decorate(WindowInfoTracker windowInfoTracker);
}
