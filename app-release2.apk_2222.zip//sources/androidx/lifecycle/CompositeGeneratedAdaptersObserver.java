package androidx.lifecycle;

import androidx.lifecycle.c;

class CompositeGeneratedAdaptersObserver implements d {

    /* renamed from: a  reason: collision with root package name */
    private final b[] f42a;

    public void d(f fVar, c.a aVar) {
        i iVar = new i();
        for (b a2 : this.f42a) {
            a2.a(fVar, aVar, false, iVar);
        }
        for (b a3 : this.f42a) {
            a3.a(fVar, aVar, true, iVar);
        }
    }
}
