package androidx.lifecycle;

import androidx.lifecycle.c;

final class Lifecycling$1 implements d {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ d f46a;

    public void d(f fVar, c.a aVar) {
        this.f46a.d(fVar, aVar);
    }
}
