package androidx.lifecycle;

import androidx.lifecycle.c;

class SingleGeneratedAdapterObserver implements d {

    /* renamed from: a  reason: collision with root package name */
    private final b f48a;

    public void d(f fVar, c.a aVar) {
        this.f48a.a(fVar, aVar, false, (i) null);
        this.f48a.a(fVar, aVar, true, (i) null);
    }
}
