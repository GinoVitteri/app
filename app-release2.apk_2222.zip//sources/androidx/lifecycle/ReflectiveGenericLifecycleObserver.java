package androidx.lifecycle;

import androidx.lifecycle.c;

class ReflectiveGenericLifecycleObserver implements d {
    public void d(f fVar, c.a aVar) {
        throw null;
    }
}
