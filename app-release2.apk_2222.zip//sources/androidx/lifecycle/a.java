package androidx.lifecycle;

interface a extends e {
    void a(f fVar);

    void b(f fVar);

    void c(f fVar);

    void e(f fVar);

    void f(f fVar);

    void g(f fVar);
}
