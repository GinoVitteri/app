package androidx.lifecycle;

import androidx.lifecycle.c;

public interface b {
    void a(f fVar, c.a aVar, boolean z2, i iVar);
}
