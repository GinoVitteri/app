package androidx.lifecycle;

import androidx.lifecycle.c;

public interface d extends e {
    void d(f fVar, c.a aVar);
}
