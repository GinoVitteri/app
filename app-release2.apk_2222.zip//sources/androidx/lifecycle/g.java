package androidx.lifecycle;

import androidx.lifecycle.c;
import androidx.window.R;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class g extends c {

    /* renamed from: b  reason: collision with root package name */
    private a.a<e, b> f56b = new a.a<>();

    /* renamed from: c  reason: collision with root package name */
    private c.b f57c;

    /* renamed from: d  reason: collision with root package name */
    private final WeakReference<f> f58d;

    /* renamed from: e  reason: collision with root package name */
    private int f59e = 0;

    /* renamed from: f  reason: collision with root package name */
    private boolean f60f = false;

    /* renamed from: g  reason: collision with root package name */
    private boolean f61g = false;

    /* renamed from: h  reason: collision with root package name */
    private ArrayList<c.b> f62h = new ArrayList<>();

    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f63a;

        /* renamed from: b  reason: collision with root package name */
        static final /* synthetic */ int[] f64b;

        /* JADX WARNING: Can't wrap try/catch for region: R(26:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|(2:17|18)|19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|36) */
        /* JADX WARNING: Can't wrap try/catch for region: R(27:0|(2:1|2)|3|(2:5|6)|7|9|10|11|(2:13|14)|15|(2:17|18)|19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|36) */
        /* JADX WARNING: Can't wrap try/catch for region: R(29:0|1|2|3|(2:5|6)|7|9|10|11|13|14|15|(2:17|18)|19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|36) */
        /* JADX WARNING: Can't wrap try/catch for region: R(30:0|1|2|3|(2:5|6)|7|9|10|11|13|14|15|17|18|19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|36) */
        /* JADX WARNING: Can't wrap try/catch for region: R(31:0|1|2|3|5|6|7|9|10|11|13|14|15|17|18|19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|36) */
        /* JADX WARNING: Code restructure failed: missing block: B:37:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:23:0x004f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x0059 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:27:0x0063 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:29:0x006d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:31:0x0077 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:33:0x0082 */
        static {
            /*
                androidx.lifecycle.c$b[] r0 = androidx.lifecycle.c.b.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f64b = r0
                r1 = 1
                androidx.lifecycle.c$b r2 = androidx.lifecycle.c.b.INITIALIZED     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r2 = r2.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                r0 = 2
                int[] r2 = f64b     // Catch:{ NoSuchFieldError -> 0x001d }
                androidx.lifecycle.c$b r3 = androidx.lifecycle.c.b.CREATED     // Catch:{ NoSuchFieldError -> 0x001d }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2[r3] = r0     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                r2 = 3
                int[] r3 = f64b     // Catch:{ NoSuchFieldError -> 0x0028 }
                androidx.lifecycle.c$b r4 = androidx.lifecycle.c.b.STARTED     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r3[r4] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                r3 = 4
                int[] r4 = f64b     // Catch:{ NoSuchFieldError -> 0x0033 }
                androidx.lifecycle.c$b r5 = androidx.lifecycle.c.b.RESUMED     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r5 = r5.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r4[r5] = r3     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                r4 = 5
                int[] r5 = f64b     // Catch:{ NoSuchFieldError -> 0x003e }
                androidx.lifecycle.c$b r6 = androidx.lifecycle.c.b.DESTROYED     // Catch:{ NoSuchFieldError -> 0x003e }
                int r6 = r6.ordinal()     // Catch:{ NoSuchFieldError -> 0x003e }
                r5[r6] = r4     // Catch:{ NoSuchFieldError -> 0x003e }
            L_0x003e:
                androidx.lifecycle.c$a[] r5 = androidx.lifecycle.c.a.values()
                int r5 = r5.length
                int[] r5 = new int[r5]
                f63a = r5
                androidx.lifecycle.c$a r6 = androidx.lifecycle.c.a.ON_CREATE     // Catch:{ NoSuchFieldError -> 0x004f }
                int r6 = r6.ordinal()     // Catch:{ NoSuchFieldError -> 0x004f }
                r5[r6] = r1     // Catch:{ NoSuchFieldError -> 0x004f }
            L_0x004f:
                int[] r1 = f63a     // Catch:{ NoSuchFieldError -> 0x0059 }
                androidx.lifecycle.c$a r5 = androidx.lifecycle.c.a.ON_STOP     // Catch:{ NoSuchFieldError -> 0x0059 }
                int r5 = r5.ordinal()     // Catch:{ NoSuchFieldError -> 0x0059 }
                r1[r5] = r0     // Catch:{ NoSuchFieldError -> 0x0059 }
            L_0x0059:
                int[] r0 = f63a     // Catch:{ NoSuchFieldError -> 0x0063 }
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_START     // Catch:{ NoSuchFieldError -> 0x0063 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0063 }
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0063 }
            L_0x0063:
                int[] r0 = f63a     // Catch:{ NoSuchFieldError -> 0x006d }
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_PAUSE     // Catch:{ NoSuchFieldError -> 0x006d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x006d }
                r0[r1] = r3     // Catch:{ NoSuchFieldError -> 0x006d }
            L_0x006d:
                int[] r0 = f63a     // Catch:{ NoSuchFieldError -> 0x0077 }
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_RESUME     // Catch:{ NoSuchFieldError -> 0x0077 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0077 }
                r0[r1] = r4     // Catch:{ NoSuchFieldError -> 0x0077 }
            L_0x0077:
                int[] r0 = f63a     // Catch:{ NoSuchFieldError -> 0x0082 }
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_DESTROY     // Catch:{ NoSuchFieldError -> 0x0082 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0082 }
                r2 = 6
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0082 }
            L_0x0082:
                int[] r0 = f63a     // Catch:{ NoSuchFieldError -> 0x008d }
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_ANY     // Catch:{ NoSuchFieldError -> 0x008d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x008d }
                r2 = 7
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x008d }
            L_0x008d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.lifecycle.g.a.<clinit>():void");
        }
    }

    static class b {

        /* renamed from: a  reason: collision with root package name */
        c.b f65a;

        /* renamed from: b  reason: collision with root package name */
        d f66b;

        /* access modifiers changed from: package-private */
        public void a(f fVar, c.a aVar) {
            c.b f2 = g.f(aVar);
            this.f65a = g.i(this.f65a, f2);
            this.f66b.d(fVar, aVar);
            this.f65a = f2;
        }
    }

    public g(f fVar) {
        this.f58d = new WeakReference<>(fVar);
        this.f57c = c.b.INITIALIZED;
    }

    private void c(f fVar) {
        Iterator<Map.Entry<e, b>> descendingIterator = this.f56b.descendingIterator();
        while (descendingIterator.hasNext() && !this.f61g) {
            Map.Entry next = descendingIterator.next();
            b bVar = (b) next.getValue();
            while (bVar.f65a.compareTo(this.f57c) > 0 && !this.f61g && this.f56b.contains(next.getKey())) {
                c.a d2 = d(bVar.f65a);
                l(f(d2));
                bVar.a(fVar, d2);
                k();
            }
        }
    }

    private static c.a d(c.b bVar) {
        int i2 = a.f64b[bVar.ordinal()];
        if (i2 == 1) {
            throw new IllegalArgumentException();
        } else if (i2 == 2) {
            return c.a.ON_DESTROY;
        } else {
            if (i2 == 3) {
                return c.a.ON_STOP;
            }
            if (i2 == 4) {
                return c.a.ON_PAUSE;
            }
            if (i2 != 5) {
                throw new IllegalArgumentException("Unexpected state value " + bVar);
            }
            throw new IllegalArgumentException();
        }
    }

    private void e(f fVar) {
        a.b<K, V>.d c2 = this.f56b.c();
        while (c2.hasNext() && !this.f61g) {
            Map.Entry entry = (Map.Entry) c2.next();
            b bVar = (b) entry.getValue();
            while (bVar.f65a.compareTo(this.f57c) < 0 && !this.f61g && this.f56b.contains(entry.getKey())) {
                l(bVar.f65a);
                bVar.a(fVar, n(bVar.f65a));
                k();
            }
        }
    }

    static c.b f(c.a aVar) {
        switch (a.f63a[aVar.ordinal()]) {
            case 1:
            case 2:
                return c.b.CREATED;
            case 3:
            case 4:
                return c.b.STARTED;
            case R.styleable.SplitPairRule_splitMinWidth /*5*/:
                return c.b.RESUMED;
            case R.styleable.SplitPairRule_splitRatio /*6*/:
                return c.b.DESTROYED;
            default:
                throw new IllegalArgumentException("Unexpected event value " + aVar);
        }
    }

    private boolean h() {
        if (this.f56b.size() == 0) {
            return true;
        }
        c.b bVar = this.f56b.a().getValue().f65a;
        c.b bVar2 = this.f56b.d().getValue().f65a;
        return bVar == bVar2 && this.f57c == bVar2;
    }

    static c.b i(c.b bVar, c.b bVar2) {
        return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
    }

    private void j(c.b bVar) {
        if (this.f57c != bVar) {
            this.f57c = bVar;
            if (this.f60f || this.f59e != 0) {
                this.f61g = true;
                return;
            }
            this.f60f = true;
            m();
            this.f60f = false;
        }
    }

    private void k() {
        ArrayList<c.b> arrayList = this.f62h;
        arrayList.remove(arrayList.size() - 1);
    }

    private void l(c.b bVar) {
        this.f62h.add(bVar);
    }

    private void m() {
        f fVar = this.f58d.get();
        if (fVar != null) {
            while (true) {
                boolean h2 = h();
                this.f61g = false;
                if (!h2) {
                    if (this.f57c.compareTo(this.f56b.a().getValue().f65a) < 0) {
                        c(fVar);
                    }
                    Map.Entry<e, b> d2 = this.f56b.d();
                    if (!this.f61g && d2 != null && this.f57c.compareTo(d2.getValue().f65a) > 0) {
                        e(fVar);
                    }
                } else {
                    return;
                }
            }
        } else {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
        }
    }

    private static c.a n(c.b bVar) {
        int i2 = a.f64b[bVar.ordinal()];
        if (i2 != 1) {
            if (i2 == 2) {
                return c.a.ON_START;
            }
            if (i2 == 3) {
                return c.a.ON_RESUME;
            }
            if (i2 == 4) {
                throw new IllegalArgumentException();
            } else if (i2 != 5) {
                throw new IllegalArgumentException("Unexpected state value " + bVar);
            }
        }
        return c.a.ON_CREATE;
    }

    public c.b a() {
        return this.f57c;
    }

    public void b(e eVar) {
        this.f56b.e(eVar);
    }

    public void g(c.a aVar) {
        j(f(aVar));
    }
}
