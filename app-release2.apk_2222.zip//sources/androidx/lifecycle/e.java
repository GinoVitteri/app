package androidx.lifecycle;

public interface e {
}
