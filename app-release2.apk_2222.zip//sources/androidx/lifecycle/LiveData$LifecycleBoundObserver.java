package androidx.lifecycle;

import androidx.lifecycle.c;

class LiveData$LifecycleBoundObserver extends h implements d {

    /* renamed from: b  reason: collision with root package name */
    final f f47b;

    public void d(f fVar, c.a aVar) {
        if (this.f47b.e().a() != c.b.DESTROYED) {
            h(i());
            return;
        }
        throw null;
    }

    /* access modifiers changed from: package-private */
    public boolean i() {
        return this.f47b.e().a().a(c.b.STARTED);
    }
}
