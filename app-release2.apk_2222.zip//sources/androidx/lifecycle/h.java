package androidx.lifecycle;

abstract class h {

    /* renamed from: a  reason: collision with root package name */
    boolean f67a;

    /* access modifiers changed from: package-private */
    public void h(boolean z2) {
        if (z2 != this.f67a) {
            this.f67a = z2;
            throw null;
        }
    }
}
