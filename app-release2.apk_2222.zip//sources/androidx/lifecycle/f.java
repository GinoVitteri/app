package androidx.lifecycle;

public interface f {
    c e();
}
