package androidx.lifecycle;

import androidx.lifecycle.c;
import androidx.window.R;

class FullLifecycleObserverAdapter implements d {

    /* renamed from: a  reason: collision with root package name */
    private final a f43a;

    /* renamed from: b  reason: collision with root package name */
    private final d f44b;

    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f45a;

        /* JADX WARNING: Can't wrap try/catch for region: R(14:0|1|2|3|4|5|6|7|8|9|10|11|12|(3:13|14|16)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(16:0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|16) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x003e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0049 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0033 */
        static {
            /*
                androidx.lifecycle.c$a[] r0 = androidx.lifecycle.c.a.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f45a = r0
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_CREATE     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f45a     // Catch:{ NoSuchFieldError -> 0x001d }
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_START     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f45a     // Catch:{ NoSuchFieldError -> 0x0028 }
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_RESUME     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = f45a     // Catch:{ NoSuchFieldError -> 0x0033 }
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_PAUSE     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                int[] r0 = f45a     // Catch:{ NoSuchFieldError -> 0x003e }
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_STOP     // Catch:{ NoSuchFieldError -> 0x003e }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x003e }
                r2 = 5
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x003e }
            L_0x003e:
                int[] r0 = f45a     // Catch:{ NoSuchFieldError -> 0x0049 }
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_DESTROY     // Catch:{ NoSuchFieldError -> 0x0049 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0049 }
                r2 = 6
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0049 }
            L_0x0049:
                int[] r0 = f45a     // Catch:{ NoSuchFieldError -> 0x0054 }
                androidx.lifecycle.c$a r1 = androidx.lifecycle.c.a.ON_ANY     // Catch:{ NoSuchFieldError -> 0x0054 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0054 }
                r2 = 7
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0054 }
            L_0x0054:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.lifecycle.FullLifecycleObserverAdapter.a.<clinit>():void");
        }
    }

    public void d(f fVar, c.a aVar) {
        switch (a.f45a[aVar.ordinal()]) {
            case 1:
                this.f43a.c(fVar);
                break;
            case 2:
                this.f43a.g(fVar);
                break;
            case 3:
                this.f43a.a(fVar);
                break;
            case 4:
                this.f43a.e(fVar);
                break;
            case R.styleable.SplitPairRule_splitMinWidth /*5*/:
                this.f43a.f(fVar);
                break;
            case R.styleable.SplitPairRule_splitRatio /*6*/:
                this.f43a.b(fVar);
                break;
            case 7:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        d dVar = this.f44b;
        if (dVar != null) {
            dVar.d(fVar, aVar);
        }
    }
}
