package androidx.core.content;

public final /* synthetic */ class e {
}
