package androidx.core.content;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import java.io.File;
import java.util.concurrent.Executor;

public class d {

    /* renamed from: a  reason: collision with root package name */
    private static final Object f29a = new Object();

    /* renamed from: b  reason: collision with root package name */
    private static final Object f30b = new Object();

    static class a {
        static File a(Context context) {
            return context.getCodeCacheDir();
        }

        static Drawable b(Context context, int i2) {
            return context.getDrawable(i2);
        }

        static File c(Context context) {
            return context.getNoBackupFilesDir();
        }
    }

    static class b {
        static Executor a(Context context) {
            return context.getMainExecutor();
        }
    }

    public static Drawable a(Context context, int i2) {
        return Build.VERSION.SDK_INT >= 21 ? a.b(context, i2) : context.getResources().getDrawable(i2);
    }

    public static Executor b(Context context) {
        return Build.VERSION.SDK_INT >= 28 ? b.a(context) : g.a.a(new Handler(context.getMainLooper()));
    }
}
