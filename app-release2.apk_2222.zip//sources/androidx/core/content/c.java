package androidx.core.content;

public final /* synthetic */ class c {
}
