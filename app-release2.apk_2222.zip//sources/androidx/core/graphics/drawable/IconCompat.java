package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import androidx.window.R;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: k  reason: collision with root package name */
    static final PorterDuff.Mode f31k = PorterDuff.Mode.SRC_IN;

    /* renamed from: a  reason: collision with root package name */
    public int f32a = -1;

    /* renamed from: b  reason: collision with root package name */
    Object f33b;

    /* renamed from: c  reason: collision with root package name */
    public byte[] f34c = null;

    /* renamed from: d  reason: collision with root package name */
    public Parcelable f35d = null;

    /* renamed from: e  reason: collision with root package name */
    public int f36e = 0;

    /* renamed from: f  reason: collision with root package name */
    public int f37f = 0;

    /* renamed from: g  reason: collision with root package name */
    public ColorStateList f38g = null;

    /* renamed from: h  reason: collision with root package name */
    PorterDuff.Mode f39h = f31k;

    /* renamed from: i  reason: collision with root package name */
    public String f40i = null;

    /* renamed from: j  reason: collision with root package name */
    public String f41j;

    private static int b(Icon icon) {
        if (Build.VERSION.SDK_INT >= 28) {
            return icon.getResId();
        }
        try {
            return ((Integer) icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
        } catch (IllegalAccessException e2) {
            Log.e("IconCompat", "Unable to get icon resource", e2);
            return 0;
        } catch (InvocationTargetException e3) {
            Log.e("IconCompat", "Unable to get icon resource", e3);
            return 0;
        } catch (NoSuchMethodException e4) {
            Log.e("IconCompat", "Unable to get icon resource", e4);
            return 0;
        }
    }

    private static String e(int i2) {
        switch (i2) {
            case 1:
                return "BITMAP";
            case 2:
                return "RESOURCE";
            case 3:
                return "DATA";
            case 4:
                return "URI";
            case R.styleable.SplitPairRule_splitMinWidth /*5*/:
                return "BITMAP_MASKABLE";
            case R.styleable.SplitPairRule_splitRatio /*6*/:
                return "URI_MASKABLE";
            default:
                return "UNKNOWN";
        }
    }

    public int a() {
        int i2 = this.f32a;
        if (i2 == -1 && Build.VERSION.SDK_INT >= 23) {
            return b((Icon) this.f33b);
        }
        if (i2 == 2) {
            return this.f36e;
        }
        throw new IllegalStateException("called getResId() on " + this);
    }

    public void c() {
        Parcelable parcelable;
        this.f39h = PorterDuff.Mode.valueOf(this.f40i);
        switch (this.f32a) {
            case -1:
                parcelable = this.f35d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                break;
            case 1:
            case R.styleable.SplitPairRule_splitMinWidth /*5*/:
                parcelable = this.f35d;
                if (parcelable == null) {
                    byte[] bArr = this.f34c;
                    this.f33b = bArr;
                    this.f32a = 3;
                    this.f36e = 0;
                    this.f37f = bArr.length;
                    return;
                }
                break;
            case 2:
            case 4:
            case R.styleable.SplitPairRule_splitRatio /*6*/:
                String str = new String(this.f34c, Charset.forName("UTF-16"));
                this.f33b = str;
                if (this.f32a == 2 && this.f41j == null) {
                    this.f41j = str.split(":", -1)[0];
                    return;
                }
                return;
            case 3:
                this.f33b = this.f34c;
                return;
            default:
                return;
        }
        this.f33b = parcelable;
    }

    public void d(boolean z2) {
        this.f40i = this.f39h.name();
        switch (this.f32a) {
            case -1:
                if (z2) {
                    throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
                }
                break;
            case 1:
            case R.styleable.SplitPairRule_splitMinWidth /*5*/:
                if (z2) {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    ((Bitmap) this.f33b).compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
                    this.f34c = byteArrayOutputStream.toByteArray();
                    return;
                }
                break;
            case 2:
                this.f34c = ((String) this.f33b).getBytes(Charset.forName("UTF-16"));
                return;
            case 3:
                this.f34c = (byte[]) this.f33b;
                return;
            case 4:
            case R.styleable.SplitPairRule_splitRatio /*6*/:
                this.f34c = this.f33b.toString().getBytes(Charset.forName("UTF-16"));
                return;
            default:
                return;
        }
        this.f35d = (Parcelable) this.f33b;
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String toString() {
        /*
            r4 = this;
            int r0 = r4.f32a
            r1 = -1
            if (r0 != r1) goto L_0x000c
            java.lang.Object r0 = r4.f33b
            java.lang.String r0 = java.lang.String.valueOf(r0)
            return r0
        L_0x000c:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Icon(typ="
            r0.<init>(r1)
            int r1 = r4.f32a
            java.lang.String r1 = e(r1)
            r0.append(r1)
            int r1 = r4.f32a
            switch(r1) {
                case 1: goto L_0x006a;
                case 2: goto L_0x0043;
                case 3: goto L_0x002d;
                case 4: goto L_0x0022;
                case 5: goto L_0x006a;
                case 6: goto L_0x0022;
                default: goto L_0x0021;
            }
        L_0x0021:
            goto L_0x008a
        L_0x0022:
            java.lang.String r1 = " uri="
            r0.append(r1)
            java.lang.Object r1 = r4.f33b
            r0.append(r1)
            goto L_0x008a
        L_0x002d:
            java.lang.String r1 = " len="
            r0.append(r1)
            int r1 = r4.f36e
            r0.append(r1)
            int r1 = r4.f37f
            if (r1 == 0) goto L_0x008a
            java.lang.String r1 = " off="
            r0.append(r1)
            int r1 = r4.f37f
            goto L_0x0087
        L_0x0043:
            java.lang.String r1 = " pkg="
            r0.append(r1)
            java.lang.String r1 = r4.f41j
            r0.append(r1)
            java.lang.String r1 = " id="
            r0.append(r1)
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]
            r2 = 0
            int r3 = r4.a()
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r1[r2] = r3
            java.lang.String r2 = "0x%08x"
            java.lang.String r1 = java.lang.String.format(r2, r1)
            r0.append(r1)
            goto L_0x008a
        L_0x006a:
            java.lang.String r1 = " size="
            r0.append(r1)
            java.lang.Object r1 = r4.f33b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getWidth()
            r0.append(r1)
            java.lang.String r1 = "x"
            r0.append(r1)
            java.lang.Object r1 = r4.f33b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getHeight()
        L_0x0087:
            r0.append(r1)
        L_0x008a:
            android.content.res.ColorStateList r1 = r4.f38g
            if (r1 == 0) goto L_0x0098
            java.lang.String r1 = " tint="
            r0.append(r1)
            android.content.res.ColorStateList r1 = r4.f38g
            r0.append(r1)
        L_0x0098:
            android.graphics.PorterDuff$Mode r1 = r4.f39h
            android.graphics.PorterDuff$Mode r2 = f31k
            if (r1 == r2) goto L_0x00a8
            java.lang.String r1 = " mode="
            r0.append(r1)
            android.graphics.PorterDuff$Mode r1 = r4.f39h
            r0.append(r1)
        L_0x00a8:
            java.lang.String r1 = ")"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.toString():java.lang.String");
    }
}
