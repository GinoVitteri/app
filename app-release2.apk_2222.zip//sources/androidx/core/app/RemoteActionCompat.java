package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import l.a;

public final class RemoteActionCompat implements a {

    /* renamed from: a  reason: collision with root package name */
    public IconCompat f23a;

    /* renamed from: b  reason: collision with root package name */
    public CharSequence f24b;

    /* renamed from: c  reason: collision with root package name */
    public CharSequence f25c;

    /* renamed from: d  reason: collision with root package name */
    public PendingIntent f26d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f27e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f28f;
}
