package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import androidx.versionedparcelable.a;

public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        remoteActionCompat.f23a = (IconCompat) aVar.v(remoteActionCompat.f23a, 1);
        remoteActionCompat.f24b = aVar.l(remoteActionCompat.f24b, 2);
        remoteActionCompat.f25c = aVar.l(remoteActionCompat.f25c, 3);
        remoteActionCompat.f26d = (PendingIntent) aVar.r(remoteActionCompat.f26d, 4);
        remoteActionCompat.f27e = aVar.h(remoteActionCompat.f27e, 5);
        remoteActionCompat.f28f = aVar.h(remoteActionCompat.f28f, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, a aVar) {
        aVar.x(false, false);
        aVar.M(remoteActionCompat.f23a, 1);
        aVar.D(remoteActionCompat.f24b, 2);
        aVar.D(remoteActionCompat.f25c, 3);
        aVar.H(remoteActionCompat.f26d, 4);
        aVar.z(remoteActionCompat.f27e, 5);
        aVar.z(remoteActionCompat.f28f, 6);
    }
}
