package com.dansoft.citasoftalmologia;

import io.flutter.embedding.android.e;

public final class MainActivity extends e {
}
