package o0;

public interface c<P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, R> extends f0.c<R> {
}
