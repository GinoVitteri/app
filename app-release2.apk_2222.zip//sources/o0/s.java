package o0;

import f0.c;

public interface s<P1, P2, P3, P4, P5, R> extends c<R> {
}
