package o0;

import f0.c;

public interface a<R> extends c<R> {
    R invoke();
}
