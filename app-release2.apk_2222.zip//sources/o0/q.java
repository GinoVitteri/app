package o0;

import f0.c;

public interface q<P1, P2, P3, R> extends c<R> {
    R h(P1 p1, P2 p2, P3 p3);
}
