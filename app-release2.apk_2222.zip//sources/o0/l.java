package o0;

import f0.c;

public interface l<P1, R> extends c<R> {
    R invoke(P1 p1);
}
