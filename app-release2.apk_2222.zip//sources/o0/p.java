package o0;

import f0.c;

public interface p<P1, P2, R> extends c<R> {
    R invoke(P1 p1, P2 p2);
}
