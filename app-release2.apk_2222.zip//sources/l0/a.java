package l0;

import p0.c;

public class a extends k0.a {

    /* renamed from: l0.a$a  reason: collision with other inner class name */
    private static final class C0017a {

        /* renamed from: a  reason: collision with root package name */
        public static final C0017a f941a = new C0017a();

        /* renamed from: b  reason: collision with root package name */
        public static final Integer f942b;

        /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
        static {
            /*
                l0.a$a r0 = new l0.a$a
                r0.<init>()
                f941a = r0
                r0 = 0
                java.lang.String r1 = "android.os.Build$VERSION"
                java.lang.Class r1 = java.lang.Class.forName(r1)     // Catch:{ all -> 0x001f }
                java.lang.String r2 = "SDK_INT"
                java.lang.reflect.Field r1 = r1.getField(r2)     // Catch:{ all -> 0x001f }
                java.lang.Object r1 = r1.get(r0)     // Catch:{ all -> 0x001f }
                boolean r2 = r1 instanceof java.lang.Integer     // Catch:{ all -> 0x001f }
                if (r2 == 0) goto L_0x0020
                java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ all -> 0x001f }
                goto L_0x0021
            L_0x001f:
            L_0x0020:
                r1 = r0
            L_0x0021:
                if (r1 == 0) goto L_0x002f
                int r2 = r1.intValue()
                if (r2 <= 0) goto L_0x002b
                r2 = 1
                goto L_0x002c
            L_0x002b:
                r2 = 0
            L_0x002c:
                if (r2 == 0) goto L_0x002f
                r0 = r1
            L_0x002f:
                f942b = r0
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: l0.a.C0017a.<clinit>():void");
        }

        private C0017a() {
        }
    }

    private final boolean c(int i2) {
        Integer num = C0017a.f942b;
        return num == null || num.intValue() >= i2;
    }

    public c b() {
        return c(24) ? new q0.a() : super.b();
    }
}
