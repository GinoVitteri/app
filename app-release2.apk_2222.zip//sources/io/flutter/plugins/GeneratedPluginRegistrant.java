package io.flutter.plugins;

import androidx.annotation.Keep;
import io.flutter.embedding.engine.a;
import m.b;

@Keep
public final class GeneratedPluginRegistrant {
    private static final String TAG = "GeneratedPluginRegistrant";

    public static void registerWith(a aVar) {
        try {
            aVar.r().g(new e0.a());
        } catch (Exception e2) {
            b.c(TAG, "Error registering plugin fluttertoast, io.github.ponnamkarthik.toast.fluttertoast.FlutterToastPlugin", e2);
        }
    }
}
