package io.flutter.embedding.engine;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import b0.d;
import d0.j;
import io.flutter.plugin.platform.w;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import n.a;
import y.e;
import y.f;
import y.g;
import y.h;
import y.i;
import y.m;
import y.n;
import y.o;
import y.p;
import y.q;

public class a implements j.a {

    /* renamed from: a  reason: collision with root package name */
    private final FlutterJNI f399a;

    /* renamed from: b  reason: collision with root package name */
    private final x.a f400b;

    /* renamed from: c  reason: collision with root package name */
    private final n.a f401c;

    /* renamed from: d  reason: collision with root package name */
    private final c f402d;

    /* renamed from: e  reason: collision with root package name */
    private final d f403e;

    /* renamed from: f  reason: collision with root package name */
    private final y.a f404f;

    /* renamed from: g  reason: collision with root package name */
    private final y.b f405g;

    /* renamed from: h  reason: collision with root package name */
    private final e f406h;

    /* renamed from: i  reason: collision with root package name */
    private final f f407i;

    /* renamed from: j  reason: collision with root package name */
    private final g f408j;

    /* renamed from: k  reason: collision with root package name */
    private final h f409k;

    /* renamed from: l  reason: collision with root package name */
    private final i f410l;
    /* access modifiers changed from: private */

    /* renamed from: m  reason: collision with root package name */
    public final m f411m;

    /* renamed from: n  reason: collision with root package name */
    private final y.j f412n;

    /* renamed from: o  reason: collision with root package name */
    private final n f413o;

    /* renamed from: p  reason: collision with root package name */
    private final o f414p;

    /* renamed from: q  reason: collision with root package name */
    private final p f415q;

    /* renamed from: r  reason: collision with root package name */
    private final q f416r;
    /* access modifiers changed from: private */

    /* renamed from: s  reason: collision with root package name */
    public final w f417s;
    /* access modifiers changed from: private */

    /* renamed from: t  reason: collision with root package name */
    public final Set<b> f418t;

    /* renamed from: u  reason: collision with root package name */
    private final b f419u;

    /* renamed from: io.flutter.embedding.engine.a$a  reason: collision with other inner class name */
    class C0009a implements b {
        C0009a() {
        }

        public void a() {
            m.b.f("FlutterEngine", "onPreEngineRestart()");
            for (b a2 : a.this.f418t) {
                a2.a();
            }
            a.this.f417s.b0();
            a.this.f411m.g();
        }

        public void b() {
        }
    }

    public interface b {
        void a();

        void b();
    }

    public a(Context context, p.d dVar, FlutterJNI flutterJNI, w wVar, String[] strArr, boolean z2, boolean z3) {
        this(context, dVar, flutterJNI, wVar, strArr, z2, z3, (d) null);
    }

    public a(Context context, p.d dVar, FlutterJNI flutterJNI, w wVar, String[] strArr, boolean z2, boolean z3, d dVar2) {
        AssetManager assetManager;
        this.f418t = new HashSet();
        this.f419u = new C0009a();
        try {
            assetManager = context.createPackageContext(context.getPackageName(), 0).getAssets();
        } catch (PackageManager.NameNotFoundException unused) {
            assetManager = context.getAssets();
        }
        m.a e2 = m.a.e();
        flutterJNI = flutterJNI == null ? e2.d().a() : flutterJNI;
        this.f399a = flutterJNI;
        n.a aVar = new n.a(flutterJNI, assetManager);
        this.f401c = aVar;
        aVar.k();
        o.a a2 = m.a.e().a();
        this.f404f = new y.a(aVar, flutterJNI);
        y.b bVar = new y.b(aVar);
        this.f405g = bVar;
        this.f406h = new e(aVar);
        this.f407i = new f(aVar);
        g gVar = new g(aVar);
        this.f408j = gVar;
        this.f409k = new h(aVar);
        this.f410l = new i(aVar);
        this.f412n = new y.j(aVar);
        this.f411m = new m(aVar, z3);
        this.f413o = new n(aVar);
        this.f414p = new o(aVar);
        this.f415q = new p(aVar);
        this.f416r = new q(aVar);
        if (a2 != null) {
            a2.e(bVar);
        }
        d dVar3 = new d(context, gVar);
        this.f403e = dVar3;
        dVar = dVar == null ? e2.c() : dVar;
        if (!flutterJNI.isAttached()) {
            dVar.j(context.getApplicationContext());
            dVar.e(context, strArr);
        }
        flutterJNI.addEngineLifecycleListener(this.f419u);
        flutterJNI.setPlatformViewsController(wVar);
        flutterJNI.setLocalizationPlugin(dVar3);
        flutterJNI.setDeferredComponentManager(e2.a());
        if (!flutterJNI.isAttached()) {
            f();
        }
        this.f400b = new x.a(flutterJNI);
        this.f417s = wVar;
        wVar.V();
        this.f402d = new c(context.getApplicationContext(), this, dVar, dVar2);
        dVar3.d(context.getResources().getConfiguration());
        if (z2 && dVar.d()) {
            w.a.a(this);
        }
        j.c(context, this);
    }

    private void f() {
        m.b.f("FlutterEngine", "Attaching to JNI.");
        this.f399a.attachToNative();
        if (!y()) {
            throw new RuntimeException("FlutterEngine failed to attach to its native Object reference.");
        }
    }

    private boolean y() {
        return this.f399a.isAttached();
    }

    public void a(float f2, float f3, float f4) {
        this.f399a.updateDisplayMetrics(0, f2, f3, f4);
    }

    public void e(b bVar) {
        this.f418t.add(bVar);
    }

    public void g() {
        m.b.f("FlutterEngine", "Destroying.");
        for (b b2 : this.f418t) {
            b2.b();
        }
        this.f402d.l();
        this.f417s.X();
        this.f401c.l();
        this.f399a.removeEngineLifecycleListener(this.f419u);
        this.f399a.setDeferredComponentManager((o.a) null);
        this.f399a.detachFromNativeAndReleaseResources();
        if (m.a.e().a() != null) {
            m.a.e().a().destroy();
            this.f405g.c((o.a) null);
        }
    }

    public y.a h() {
        return this.f404f;
    }

    public s.b i() {
        return this.f402d;
    }

    public n.a j() {
        return this.f401c;
    }

    public e k() {
        return this.f406h;
    }

    public f l() {
        return this.f407i;
    }

    public d m() {
        return this.f403e;
    }

    public h n() {
        return this.f409k;
    }

    public i o() {
        return this.f410l;
    }

    public y.j p() {
        return this.f412n;
    }

    public w q() {
        return this.f417s;
    }

    public r.b r() {
        return this.f402d;
    }

    public x.a s() {
        return this.f400b;
    }

    public m t() {
        return this.f411m;
    }

    public n u() {
        return this.f413o;
    }

    public o v() {
        return this.f414p;
    }

    public p w() {
        return this.f415q;
    }

    public q x() {
        return this.f416r;
    }

    /* access modifiers changed from: package-private */
    public a z(Context context, a.b bVar, String str, List<String> list, w wVar, boolean z2, boolean z3) {
        a.b bVar2 = bVar;
        if (y()) {
            String str2 = str;
            return new a(context, (p.d) null, this.f399a.spawn(bVar2.f966c, bVar2.f965b, str, list), wVar, (String[]) null, z2, z3);
        }
        throw new IllegalStateException("Spawn can only be called on a fully constructed FlutterEngine");
    }
}
