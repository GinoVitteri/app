package io.flutter.embedding.engine;

import java.util.HashMap;
import java.util.Map;

public class b {

    /* renamed from: b  reason: collision with root package name */
    private static b f421b;

    /* renamed from: a  reason: collision with root package name */
    private final Map<String, a> f422a = new HashMap();

    b() {
    }

    public static b b() {
        if (f421b == null) {
            f421b = new b();
        }
        return f421b;
    }

    public a a(String str) {
        return this.f422a.get(str);
    }

    public void c(String str, a aVar) {
        if (aVar != null) {
            this.f422a.put(str, aVar);
        } else {
            this.f422a.remove(str);
        }
    }

    public void d(String str) {
        c(str, (a) null);
    }
}
