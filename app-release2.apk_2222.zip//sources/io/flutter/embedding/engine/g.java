package io.flutter.embedding.engine;

import android.graphics.ImageDecoder;

public final /* synthetic */ class g implements ImageDecoder.OnHeaderDecodedListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ long f457a;

    public /* synthetic */ g(long j2) {
        this.f457a = j2;
    }

    public final void onHeaderDecoded(ImageDecoder imageDecoder, ImageDecoder.ImageInfo imageInfo, ImageDecoder.Source source) {
        FlutterJNI.lambda$decodeImage$0(this.f457a, imageDecoder, imageInfo, source);
    }
}
