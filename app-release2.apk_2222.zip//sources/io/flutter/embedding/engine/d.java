package io.flutter.embedding.engine;

import android.content.Context;
import io.flutter.embedding.engine.a;
import io.flutter.plugin.platform.w;
import java.util.ArrayList;
import java.util.List;
import n.a;

public class d {

    /* renamed from: a  reason: collision with root package name */
    final List<a> f445a = new ArrayList();

    class a implements a.b {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ a f446a;

        a(a aVar) {
            this.f446a = aVar;
        }

        public void a() {
        }

        public void b() {
            d.this.f445a.remove(this.f446a);
        }
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        private Context f448a;

        /* renamed from: b  reason: collision with root package name */
        private a.b f449b;

        /* renamed from: c  reason: collision with root package name */
        private String f450c;

        /* renamed from: d  reason: collision with root package name */
        private List<String> f451d;

        /* renamed from: e  reason: collision with root package name */
        private w f452e;

        /* renamed from: f  reason: collision with root package name */
        private boolean f453f = true;

        /* renamed from: g  reason: collision with root package name */
        private boolean f454g = false;

        public b(Context context) {
            this.f448a = context;
        }

        public boolean a() {
            return this.f453f;
        }

        public Context b() {
            return this.f448a;
        }

        public a.b c() {
            return this.f449b;
        }

        public List<String> d() {
            return this.f451d;
        }

        public String e() {
            return this.f450c;
        }

        public w f() {
            return this.f452e;
        }

        public boolean g() {
            return this.f454g;
        }

        public b h(boolean z2) {
            this.f453f = z2;
            return this;
        }

        public b i(a.b bVar) {
            this.f449b = bVar;
            return this;
        }

        public b j(List<String> list) {
            this.f451d = list;
            return this;
        }

        public b k(String str) {
            this.f450c = str;
            return this;
        }

        public b l(boolean z2) {
            this.f454g = z2;
            return this;
        }
    }

    public d(Context context, String[] strArr) {
        p.d c2 = m.a.e().c();
        if (!c2.h()) {
            c2.j(context.getApplicationContext());
            c2.e(context.getApplicationContext(), strArr);
        }
    }

    public a a(b bVar) {
        a aVar;
        Context b2 = bVar.b();
        a.b c2 = bVar.c();
        String e2 = bVar.e();
        List<String> d2 = bVar.d();
        w f2 = bVar.f();
        if (f2 == null) {
            f2 = new w();
        }
        w wVar = f2;
        boolean a2 = bVar.a();
        boolean g2 = bVar.g();
        a.b a3 = c2 == null ? a.b.a() : c2;
        if (this.f445a.size() == 0) {
            aVar = b(b2, wVar, a2, g2);
            if (e2 != null) {
                aVar.o().c(e2);
            }
            aVar.j().g(a3, d2);
        } else {
            aVar = this.f445a.get(0).z(b2, a3, e2, d2, wVar, a2, g2);
        }
        this.f445a.add(aVar);
        aVar.e(new a(aVar));
        return aVar;
    }

    /* access modifiers changed from: package-private */
    public a b(Context context, w wVar, boolean z2, boolean z3) {
        return new a(context, (p.d) null, (FlutterJNI) null, wVar, (String[]) null, z2, z3, this);
    }
}
