package io.flutter.embedding.engine;

import android.app.Activity;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import d0.g;
import io.flutter.embedding.engine.plugins.lifecycle.HiddenLifecycleReference;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import p.d;
import r.a;
import s.c;
import z.k;
import z.l;
import z.m;
import z.n;

class c implements r.b, s.b {

    /* renamed from: a  reason: collision with root package name */
    private final Map<Class<? extends r.a>, r.a> f423a = new HashMap();

    /* renamed from: b  reason: collision with root package name */
    private final a f424b;

    /* renamed from: c  reason: collision with root package name */
    private final a.b f425c;

    /* renamed from: d  reason: collision with root package name */
    private final Map<Class<? extends r.a>, s.a> f426d = new HashMap();

    /* renamed from: e  reason: collision with root package name */
    private io.flutter.embedding.android.c<Activity> f427e;

    /* renamed from: f  reason: collision with root package name */
    private C0010c f428f;

    /* renamed from: g  reason: collision with root package name */
    private boolean f429g = false;

    /* renamed from: h  reason: collision with root package name */
    private final Map<Class<? extends r.a>, v.a> f430h = new HashMap();

    /* renamed from: i  reason: collision with root package name */
    private Service f431i;

    /* renamed from: j  reason: collision with root package name */
    private final Map<Class<? extends r.a>, t.a> f432j = new HashMap();

    /* renamed from: k  reason: collision with root package name */
    private BroadcastReceiver f433k;

    /* renamed from: l  reason: collision with root package name */
    private final Map<Class<? extends r.a>, u.a> f434l = new HashMap();

    /* renamed from: m  reason: collision with root package name */
    private ContentProvider f435m;

    private static class b implements a.C0023a {

        /* renamed from: a  reason: collision with root package name */
        final d f436a;

        private b(d dVar) {
            this.f436a = dVar;
        }
    }

    /* renamed from: io.flutter.embedding.engine.c$c  reason: collision with other inner class name */
    private static class C0010c implements s.c {

        /* renamed from: a  reason: collision with root package name */
        private final Activity f437a;

        /* renamed from: b  reason: collision with root package name */
        private final HiddenLifecycleReference f438b;

        /* renamed from: c  reason: collision with root package name */
        private final Set<m> f439c = new HashSet();

        /* renamed from: d  reason: collision with root package name */
        private final Set<k> f440d = new HashSet();

        /* renamed from: e  reason: collision with root package name */
        private final Set<l> f441e = new HashSet();

        /* renamed from: f  reason: collision with root package name */
        private final Set<n> f442f = new HashSet();

        /* renamed from: g  reason: collision with root package name */
        private final Set<Object> f443g = new HashSet();

        /* renamed from: h  reason: collision with root package name */
        private final Set<c.a> f444h = new HashSet();

        public C0010c(Activity activity, androidx.lifecycle.c cVar) {
            this.f437a = activity;
            this.f438b = new HiddenLifecycleReference(cVar);
        }

        /* access modifiers changed from: package-private */
        public boolean a(int i2, int i3, Intent intent) {
            Iterator it = new HashSet(this.f440d).iterator();
            while (true) {
                boolean z2 = false;
                while (true) {
                    if (!it.hasNext()) {
                        return z2;
                    }
                    if (((k) it.next()).a(i2, i3, intent) || z2) {
                        z2 = true;
                    }
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void b(Intent intent) {
            for (l b2 : this.f441e) {
                b2.b(intent);
            }
        }

        /* access modifiers changed from: package-private */
        public boolean c(int i2, String[] strArr, int[] iArr) {
            Iterator<m> it = this.f439c.iterator();
            while (true) {
                boolean z2 = false;
                while (true) {
                    if (!it.hasNext()) {
                        return z2;
                    }
                    if (it.next().d(i2, strArr, iArr) || z2) {
                        z2 = true;
                    }
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void d(Bundle bundle) {
            for (c.a c2 : this.f444h) {
                c2.c(bundle);
            }
        }

        /* access modifiers changed from: package-private */
        public void e(Bundle bundle) {
            for (c.a e2 : this.f444h) {
                e2.e(bundle);
            }
        }

        /* access modifiers changed from: package-private */
        public void f() {
            for (n f2 : this.f442f) {
                f2.f();
            }
        }
    }

    c(Context context, a aVar, d dVar, d dVar2) {
        this.f424b = aVar;
        this.f425c = new a.b(context, aVar, aVar.j(), aVar.s(), aVar.q().P(), new b(dVar), dVar2);
    }

    private void k(Activity activity, androidx.lifecycle.c cVar) {
        this.f428f = new C0010c(activity, cVar);
        this.f424b.q().h0(activity.getIntent() != null ? activity.getIntent().getBooleanExtra("enable-software-rendering", false) : false);
        this.f424b.q().B(activity, this.f424b.s(), this.f424b.j());
        for (s.a next : this.f426d.values()) {
            if (this.f429g) {
                next.c(this.f428f);
            } else {
                next.b(this.f428f);
            }
        }
        this.f429g = false;
    }

    private void m() {
        this.f424b.q().J();
        this.f427e = null;
        this.f428f = null;
    }

    private void n() {
        if (s()) {
            i();
        } else if (v()) {
            q();
        } else if (t()) {
            o();
        } else if (u()) {
            p();
        }
    }

    private boolean s() {
        return this.f427e != null;
    }

    private boolean t() {
        return this.f433k != null;
    }

    private boolean u() {
        return this.f435m != null;
    }

    private boolean v() {
        return this.f431i != null;
    }

    public boolean a(int i2, int i3, Intent intent) {
        if (s()) {
            g.a("FlutterEngineConnectionRegistry#onActivityResult");
            try {
                return this.f428f.a(i2, i3, intent);
            } finally {
                g.d();
            }
        } else {
            m.b.b("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onActivityResult, but no Activity was attached.");
            return false;
        }
    }

    public void b(Intent intent) {
        if (s()) {
            g.a("FlutterEngineConnectionRegistry#onNewIntent");
            try {
                this.f428f.b(intent);
            } finally {
                g.d();
            }
        } else {
            m.b.b("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onNewIntent, but no Activity was attached.");
        }
    }

    public void c(Bundle bundle) {
        if (s()) {
            g.a("FlutterEngineConnectionRegistry#onRestoreInstanceState");
            try {
                this.f428f.d(bundle);
            } finally {
                g.d();
            }
        } else {
            m.b.b("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRestoreInstanceState, but no Activity was attached.");
        }
    }

    public boolean d(int i2, String[] strArr, int[] iArr) {
        if (s()) {
            g.a("FlutterEngineConnectionRegistry#onRequestPermissionsResult");
            try {
                return this.f428f.c(i2, strArr, iArr);
            } finally {
                g.d();
            }
        } else {
            m.b.b("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onRequestPermissionsResult, but no Activity was attached.");
            return false;
        }
    }

    public void e(Bundle bundle) {
        if (s()) {
            g.a("FlutterEngineConnectionRegistry#onSaveInstanceState");
            try {
                this.f428f.e(bundle);
            } finally {
                g.d();
            }
        } else {
            m.b.b("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onSaveInstanceState, but no Activity was attached.");
        }
    }

    public void f() {
        if (s()) {
            g.a("FlutterEngineConnectionRegistry#onUserLeaveHint");
            try {
                this.f428f.f();
            } finally {
                g.d();
            }
        } else {
            m.b.b("FlutterEngineCxnRegstry", "Attempted to notify ActivityAware plugins of onUserLeaveHint, but no Activity was attached.");
        }
    }

    public void g(r.a aVar) {
        g.a("FlutterEngineConnectionRegistry#add " + aVar.getClass().getSimpleName());
        try {
            if (r(aVar.getClass())) {
                m.b.g("FlutterEngineCxnRegstry", "Attempted to register plugin (" + aVar + ") but it was already registered with this FlutterEngine (" + this.f424b + ").");
                return;
            }
            m.b.f("FlutterEngineCxnRegstry", "Adding plugin: " + aVar);
            this.f423a.put(aVar.getClass(), aVar);
            aVar.b(this.f425c);
            if (aVar instanceof s.a) {
                s.a aVar2 = (s.a) aVar;
                this.f426d.put(aVar.getClass(), aVar2);
                if (s()) {
                    aVar2.b(this.f428f);
                }
            }
            if (aVar instanceof v.a) {
                v.a aVar3 = (v.a) aVar;
                this.f430h.put(aVar.getClass(), aVar3);
                if (v()) {
                    aVar3.a((v.b) null);
                }
            }
            if (aVar instanceof t.a) {
                t.a aVar4 = (t.a) aVar;
                this.f432j.put(aVar.getClass(), aVar4);
                if (t()) {
                    aVar4.b((t.b) null);
                }
            }
            if (aVar instanceof u.a) {
                u.a aVar5 = (u.a) aVar;
                this.f434l.put(aVar.getClass(), aVar5);
                if (u()) {
                    aVar5.b((u.b) null);
                }
            }
            g.d();
        } finally {
            g.d();
        }
    }

    public void h(io.flutter.embedding.android.c<Activity> cVar, androidx.lifecycle.c cVar2) {
        g.a("FlutterEngineConnectionRegistry#attachToActivity");
        try {
            io.flutter.embedding.android.c<Activity> cVar3 = this.f427e;
            if (cVar3 != null) {
                cVar3.c();
            }
            n();
            this.f427e = cVar;
            k(cVar.d(), cVar2);
        } finally {
            g.d();
        }
    }

    public void i() {
        if (s()) {
            g.a("FlutterEngineConnectionRegistry#detachFromActivity");
            try {
                for (s.a a2 : this.f426d.values()) {
                    a2.a();
                }
                m();
            } finally {
                g.d();
            }
        } else {
            m.b.b("FlutterEngineCxnRegstry", "Attempted to detach plugins from an Activity when no Activity was attached.");
        }
    }

    public void j() {
        if (s()) {
            g.a("FlutterEngineConnectionRegistry#detachFromActivityForConfigChanges");
            try {
                this.f429g = true;
                for (s.a d2 : this.f426d.values()) {
                    d2.d();
                }
                m();
            } finally {
                g.d();
            }
        } else {
            m.b.b("FlutterEngineCxnRegstry", "Attempted to detach plugins from an Activity when no Activity was attached.");
        }
    }

    public void l() {
        m.b.f("FlutterEngineCxnRegstry", "Destroying.");
        n();
        y();
    }

    public void o() {
        if (t()) {
            g.a("FlutterEngineConnectionRegistry#detachFromBroadcastReceiver");
            try {
                for (t.a a2 : this.f432j.values()) {
                    a2.a();
                }
            } finally {
                g.d();
            }
        } else {
            m.b.b("FlutterEngineCxnRegstry", "Attempted to detach plugins from a BroadcastReceiver when no BroadcastReceiver was attached.");
        }
    }

    public void p() {
        if (u()) {
            g.a("FlutterEngineConnectionRegistry#detachFromContentProvider");
            try {
                for (u.a a2 : this.f434l.values()) {
                    a2.a();
                }
            } finally {
                g.d();
            }
        } else {
            m.b.b("FlutterEngineCxnRegstry", "Attempted to detach plugins from a ContentProvider when no ContentProvider was attached.");
        }
    }

    public void q() {
        if (v()) {
            g.a("FlutterEngineConnectionRegistry#detachFromService");
            try {
                for (v.a b2 : this.f430h.values()) {
                    b2.b();
                }
                this.f431i = null;
            } finally {
                g.d();
            }
        } else {
            m.b.b("FlutterEngineCxnRegstry", "Attempted to detach plugins from a Service when no Service was attached.");
        }
    }

    public boolean r(Class<? extends r.a> cls) {
        return this.f423a.containsKey(cls);
    }

    public void w(Class<? extends r.a> cls) {
        r.a aVar = this.f423a.get(cls);
        if (aVar != null) {
            g.a("FlutterEngineConnectionRegistry#remove " + cls.getSimpleName());
            try {
                if (aVar instanceof s.a) {
                    if (s()) {
                        ((s.a) aVar).a();
                    }
                    this.f426d.remove(cls);
                }
                if (aVar instanceof v.a) {
                    if (v()) {
                        ((v.a) aVar).b();
                    }
                    this.f430h.remove(cls);
                }
                if (aVar instanceof t.a) {
                    if (t()) {
                        ((t.a) aVar).a();
                    }
                    this.f432j.remove(cls);
                }
                if (aVar instanceof u.a) {
                    if (u()) {
                        ((u.a) aVar).a();
                    }
                    this.f434l.remove(cls);
                }
                aVar.a(this.f425c);
                this.f423a.remove(cls);
            } finally {
                g.d();
            }
        }
    }

    public void x(Set<Class<? extends r.a>> set) {
        for (Class<? extends r.a> w2 : set) {
            w(w2);
        }
    }

    public void y() {
        x(new HashSet(this.f423a.keySet()));
        this.f423a.clear();
    }
}
