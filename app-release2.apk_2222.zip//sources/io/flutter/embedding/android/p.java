package io.flutter.embedding.android;

public final /* synthetic */ class p {
}
