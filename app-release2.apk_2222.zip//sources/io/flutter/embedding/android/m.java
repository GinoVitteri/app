package io.flutter.embedding.android;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.util.AttributeSet;
import android.view.Surface;
import android.view.TextureView;
import m.b;
import x.d;

public class m extends TextureView implements d {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public boolean f329a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public boolean f330b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f331c;

    /* renamed from: d  reason: collision with root package name */
    private x.a f332d;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public Surface f333e;

    /* renamed from: f  reason: collision with root package name */
    private final TextureView.SurfaceTextureListener f334f;

    class a implements TextureView.SurfaceTextureListener {
        a() {
        }

        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i2, int i3) {
            b.f("FlutterTextureView", "SurfaceTextureListener.onSurfaceTextureAvailable()");
            boolean unused = m.this.f329a = true;
            if (m.this.f330b) {
                m.this.l();
            }
        }

        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            b.f("FlutterTextureView", "SurfaceTextureListener.onSurfaceTextureDestroyed()");
            boolean unused = m.this.f329a = false;
            if (m.this.f330b) {
                m.this.m();
            }
            if (m.this.f333e == null) {
                return true;
            }
            m.this.f333e.release();
            Surface unused2 = m.this.f333e = null;
            return true;
        }

        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i2, int i3) {
            b.f("FlutterTextureView", "SurfaceTextureListener.onSurfaceTextureSizeChanged()");
            if (m.this.f330b) {
                m.this.k(i2, i3);
            }
        }

        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        }
    }

    public m(Context context) {
        this(context, (AttributeSet) null);
    }

    public m(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f329a = false;
        this.f330b = false;
        this.f331c = false;
        this.f334f = new a();
        n();
    }

    /* access modifiers changed from: private */
    public void k(int i2, int i3) {
        if (this.f332d != null) {
            b.f("FlutterTextureView", "Notifying FlutterRenderer that Android surface size has changed to " + i2 + " x " + i3);
            this.f332d.u(i2, i3);
            return;
        }
        throw new IllegalStateException("changeSurfaceSize() should only be called when flutterRenderer is non-null.");
    }

    /* access modifiers changed from: private */
    public void l() {
        if (this.f332d == null || getSurfaceTexture() == null) {
            throw new IllegalStateException("connectSurfaceToRenderer() should only be called when flutterRenderer and getSurfaceTexture() are non-null.");
        }
        Surface surface = this.f333e;
        if (surface != null) {
            surface.release();
            this.f333e = null;
        }
        Surface surface2 = new Surface(getSurfaceTexture());
        this.f333e = surface2;
        this.f332d.s(surface2, this.f331c);
        this.f331c = false;
    }

    /* access modifiers changed from: private */
    public void m() {
        x.a aVar = this.f332d;
        if (aVar != null) {
            aVar.t();
            Surface surface = this.f333e;
            if (surface != null) {
                surface.release();
                this.f333e = null;
                return;
            }
            return;
        }
        throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
    }

    private void n() {
        setSurfaceTextureListener(this.f334f);
    }

    public void a() {
        if (this.f332d != null) {
            this.f332d = null;
            this.f331c = true;
            this.f330b = false;
            return;
        }
        b.g("FlutterTextureView", "pause() invoked when no FlutterRenderer was attached.");
    }

    public void b() {
        if (this.f332d != null) {
            if (getWindowToken() != null) {
                b.f("FlutterTextureView", "Disconnecting FlutterRenderer from Android surface.");
                m();
            }
            this.f332d = null;
            this.f330b = false;
            return;
        }
        b.g("FlutterTextureView", "detachFromRenderer() invoked when no FlutterRenderer was attached.");
    }

    public void c(x.a aVar) {
        b.f("FlutterTextureView", "Attaching to FlutterRenderer.");
        if (this.f332d != null) {
            b.f("FlutterTextureView", "Already connected to a FlutterRenderer. Detaching from old one and attaching to new one.");
            this.f332d.t();
        }
        this.f332d = aVar;
        this.f330b = true;
        if (this.f329a) {
            b.f("FlutterTextureView", "Surface is available for rendering. Connecting FlutterRenderer to Android surface.");
            l();
        }
    }

    public x.a getAttachedRenderer() {
        return this.f332d;
    }

    public void setRenderSurface(Surface surface) {
        this.f333e = surface;
    }
}
