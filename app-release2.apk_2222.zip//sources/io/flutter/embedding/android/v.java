package io.flutter.embedding.android;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class v {

    /* renamed from: a  reason: collision with root package name */
    long f375a;

    /* renamed from: b  reason: collision with root package name */
    a f376b;

    /* renamed from: c  reason: collision with root package name */
    long f377c;

    /* renamed from: d  reason: collision with root package name */
    long f378d;

    /* renamed from: e  reason: collision with root package name */
    boolean f379e;

    /* renamed from: f  reason: collision with root package name */
    String f380f;

    public enum a {
        kDown(0),
        kUp(1),
        kRepeat(2);
        

        /* renamed from: d  reason: collision with root package name */
        private long f385d;

        private a(long j2) {
            this.f385d = j2;
        }

        public long a() {
            return this.f385d;
        }
    }

    /* access modifiers changed from: package-private */
    public ByteBuffer a() {
        try {
            String str = this.f380f;
            byte[] bytes = str == null ? null : str.getBytes("UTF-8");
            int length = bytes == null ? 0 : bytes.length;
            ByteBuffer allocateDirect = ByteBuffer.allocateDirect(length + 48);
            allocateDirect.order(ByteOrder.LITTLE_ENDIAN);
            allocateDirect.putLong((long) length);
            allocateDirect.putLong(this.f375a);
            allocateDirect.putLong(this.f376b.a());
            allocateDirect.putLong(this.f377c);
            allocateDirect.putLong(this.f378d);
            allocateDirect.putLong(this.f379e ? 1 : 0);
            if (bytes != null) {
                allocateDirect.put(bytes);
            }
            return allocateDirect;
        } catch (UnsupportedEncodingException unused) {
            throw new AssertionError("UTF-8 not supported");
        }
    }
}
