package io.flutter.embedding.android;

import android.annotation.SuppressLint;
import android.os.Bundle;

public final /* synthetic */ class e0 {
    @SuppressLint({"NewApi"})
    public static boolean a(f0 f0Var) {
        return false;
    }

    @SuppressLint({"NewApi"})
    public static Bundle b(f0 f0Var) {
        return null;
    }
}
