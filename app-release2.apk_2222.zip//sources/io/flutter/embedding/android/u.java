package io.flutter.embedding.android;

import android.view.KeyEvent;
import io.flutter.embedding.android.a0;
import y.d;

public class u implements a0.d {

    /* renamed from: a  reason: collision with root package name */
    private final d f373a;

    /* renamed from: b  reason: collision with root package name */
    private final a0.b f374b = new a0.b();

    public u(d dVar) {
        this.f373a = dVar;
    }

    public void a(KeyEvent keyEvent, a0.d.a aVar) {
        int action = keyEvent.getAction();
        boolean z2 = false;
        if (action == 0 || action == 1) {
            d.b bVar = new d.b(keyEvent, this.f374b.a(keyEvent.getUnicodeChar()));
            if (action != 0) {
                z2 = true;
            }
            this.f373a.e(bVar, z2, new t(aVar));
            return;
        }
        aVar.a(false);
    }
}
