package io.flutter.embedding.android;

import io.flutter.embedding.android.a0;
import java.nio.ByteBuffer;
import z.b;

public final /* synthetic */ class w implements b.C0035b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a0.d.a f386a;

    public /* synthetic */ w(a0.d.a aVar) {
        this.f386a = aVar;
    }

    public final void a(ByteBuffer byteBuffer) {
        z.k(this.f386a, byteBuffer);
    }
}
