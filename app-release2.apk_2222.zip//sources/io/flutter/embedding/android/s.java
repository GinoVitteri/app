package io.flutter.embedding.android;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.database.ContentObserver;
import android.graphics.Insets;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.DisplayCutout;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewStructure;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeProvider;
import android.view.autofill.AutofillValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textservice.TextServicesManager;
import android.widget.FrameLayout;
import androidx.window.java.layout.WindowInfoTrackerCallbackAdapter;
import androidx.window.layout.DisplayFeature;
import androidx.window.layout.FoldingFeature;
import androidx.window.layout.WindowInfoTracker;
import androidx.window.layout.WindowLayoutInfo;
import c0.b;
import io.flutter.embedding.android.a0;
import io.flutter.embedding.android.k;
import io.flutter.plugin.editing.j;
import io.flutter.plugin.editing.r;
import io.flutter.view.j;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import x.a;

public class s extends FrameLayout implements b.c, a0.e {

    /* renamed from: a  reason: collision with root package name */
    private l f336a;

    /* renamed from: b  reason: collision with root package name */
    private m f337b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public k f338c;

    /* renamed from: d  reason: collision with root package name */
    x.d f339d;

    /* renamed from: e  reason: collision with root package name */
    private x.d f340e;
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public final Set<x.c> f341f;
    /* access modifiers changed from: private */

    /* renamed from: g  reason: collision with root package name */
    public boolean f342g;
    /* access modifiers changed from: private */

    /* renamed from: h  reason: collision with root package name */
    public io.flutter.embedding.engine.a f343h;

    /* renamed from: i  reason: collision with root package name */
    private final Set<f> f344i;

    /* renamed from: j  reason: collision with root package name */
    private c0.b f345j;

    /* renamed from: k  reason: collision with root package name */
    private r f346k;

    /* renamed from: l  reason: collision with root package name */
    private j f347l;

    /* renamed from: m  reason: collision with root package name */
    private a0.a f348m;

    /* renamed from: n  reason: collision with root package name */
    private b0.d f349n;

    /* renamed from: o  reason: collision with root package name */
    private a0 f350o;

    /* renamed from: p  reason: collision with root package name */
    private a f351p;

    /* renamed from: q  reason: collision with root package name */
    private io.flutter.view.j f352q;

    /* renamed from: r  reason: collision with root package name */
    private TextServicesManager f353r;

    /* renamed from: s  reason: collision with root package name */
    private h0 f354s;

    /* renamed from: t  reason: collision with root package name */
    private final a.g f355t;

    /* renamed from: u  reason: collision with root package name */
    private final j.k f356u;

    /* renamed from: v  reason: collision with root package name */
    private final ContentObserver f357v;

    /* renamed from: w  reason: collision with root package name */
    private final x.c f358w;

    /* renamed from: x  reason: collision with root package name */
    private final h.a<WindowLayoutInfo> f359x;

    class a implements j.k {
        a() {
        }

        public void a(boolean z2, boolean z3) {
            s.this.C(z2, z3);
        }
    }

    class b extends ContentObserver {
        b(Handler handler) {
            super(handler);
        }

        public boolean deliverSelfNotifications() {
            return true;
        }

        public void onChange(boolean z2) {
            super.onChange(z2);
            if (s.this.f343h != null) {
                m.b.f("FlutterView", "System settings changed. Sending user settings to Flutter.");
                s.this.E();
            }
        }
    }

    class c implements x.c {
        c() {
        }

        public void b() {
            boolean unused = s.this.f342g = false;
            for (x.c b2 : s.this.f341f) {
                b2.b();
            }
        }

        public void d() {
            boolean unused = s.this.f342g = true;
            for (x.c d2 : s.this.f341f) {
                d2.d();
            }
        }
    }

    class d implements h.a<WindowLayoutInfo> {
        d() {
        }

        /* renamed from: a */
        public void accept(WindowLayoutInfo windowLayoutInfo) {
            s.this.setWindowInfoListenerDisplayFeatures(windowLayoutInfo);
        }
    }

    class e implements x.c {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ x.a f364a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ Runnable f365b;

        e(x.a aVar, Runnable runnable) {
            this.f364a = aVar;
            this.f365b = runnable;
        }

        public void b() {
        }

        public void d() {
            this.f364a.p(this);
            this.f365b.run();
            s sVar = s.this;
            if (!(sVar.f339d instanceof k) && sVar.f338c != null) {
                s.this.f338c.b();
                s.this.z();
            }
        }
    }

    public interface f {
        void a(io.flutter.embedding.engine.a aVar);

        void b();
    }

    private enum g {
        NONE,
        LEFT,
        RIGHT,
        BOTH
    }

    private s(Context context, AttributeSet attributeSet, l lVar) {
        super(context, attributeSet);
        this.f341f = new HashSet();
        this.f344i = new HashSet();
        this.f355t = new a.g();
        this.f356u = new a();
        this.f357v = new b(new Handler(Looper.getMainLooper()));
        this.f358w = new c();
        this.f359x = new d();
        this.f336a = lVar;
        this.f339d = lVar;
        w();
    }

    private s(Context context, AttributeSet attributeSet, m mVar) {
        super(context, attributeSet);
        this.f341f = new HashSet();
        this.f344i = new HashSet();
        this.f355t = new a.g();
        this.f356u = new a();
        this.f357v = new b(new Handler(Looper.getMainLooper()));
        this.f358w = new c();
        this.f359x = new d();
        this.f337b = mVar;
        this.f339d = mVar;
        w();
    }

    public s(Context context, l lVar) {
        this(context, (AttributeSet) null, lVar);
    }

    public s(Context context, m mVar) {
        this(context, (AttributeSet) null, mVar);
    }

    /* access modifiers changed from: private */
    public void C(boolean z2, boolean z3) {
        boolean z4 = false;
        if (!this.f343h.s().k() && !z2 && !z3) {
            z4 = true;
        }
        setWillNotDraw(z4);
    }

    private void F() {
        if (!x()) {
            m.b.g("FlutterView", "Tried to send viewport metrics from Android to Flutter but this FlutterView was not attached to a FlutterEngine.");
            return;
        }
        this.f355t.f1211a = getResources().getDisplayMetrics().density;
        this.f355t.f1226p = ViewConfiguration.get(getContext()).getScaledTouchSlop();
        this.f343h.s().r(this.f355t);
    }

    private g p() {
        Context context = getContext();
        int i2 = context.getResources().getConfiguration().orientation;
        int rotation = ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getRotation();
        if (i2 == 2) {
            if (rotation == 1) {
                return g.RIGHT;
            }
            if (rotation == 3) {
                return Build.VERSION.SDK_INT >= 23 ? g.LEFT : g.RIGHT;
            }
            if (rotation == 0 || rotation == 2) {
                return g.BOTH;
            }
        }
        return g.NONE;
    }

    @TargetApi(20)
    private int u(WindowInsets windowInsets) {
        double height = (double) getRootView().getHeight();
        Double.isNaN(height);
        if (((double) windowInsets.getSystemWindowInsetBottom()) < height * 0.18d) {
            return 0;
        }
        return windowInsets.getSystemWindowInsetBottom();
    }

    private void w() {
        View view;
        m.b.f("FlutterView", "Initializing FlutterView");
        if (this.f336a != null) {
            m.b.f("FlutterView", "Internally using a FlutterSurfaceView.");
            view = this.f336a;
        } else if (this.f337b != null) {
            m.b.f("FlutterView", "Internally using a FlutterTextureView.");
            view = this.f337b;
        } else {
            m.b.f("FlutterView", "Internally using a FlutterImageView.");
            view = this.f338c;
        }
        addView(view);
        setFocusable(true);
        setFocusableInTouchMode(true);
        if (Build.VERSION.SDK_INT >= 26) {
            setImportantForAutofill(1);
        }
    }

    /* access modifiers changed from: private */
    public void z() {
        k kVar = this.f338c;
        if (kVar != null) {
            kVar.f();
            removeView(this.f338c);
            this.f338c = null;
        }
    }

    public void A(f fVar) {
        this.f344i.remove(fVar);
    }

    public void B(x.c cVar) {
        this.f341f.remove(cVar);
    }

    public void D(Runnable runnable) {
        if (this.f338c == null) {
            m.b.f("FlutterView", "Tried to revert the image view, but no image view is used.");
            return;
        }
        x.d dVar = this.f340e;
        if (dVar == null) {
            m.b.f("FlutterView", "Tried to revert the image view, but no previous surface was used.");
            return;
        }
        this.f339d = dVar;
        this.f340e = null;
        x.a s2 = this.f343h.s();
        if (this.f343h == null || s2 == null) {
            this.f338c.b();
            z();
            runnable.run();
            return;
        }
        this.f339d.c(s2);
        s2.f(new e(s2, runnable));
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x003f, code lost:
        if (r3 != false) goto L_0x0041;
     */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0070  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void E() {
        /*
            r6 = this;
            android.content.res.Resources r0 = r6.getResources()
            android.content.res.Configuration r0 = r0.getConfiguration()
            int r0 = r0.uiMode
            r0 = r0 & 48
            r1 = 0
            r2 = 1
            r3 = 32
            if (r0 != r3) goto L_0x0014
            r0 = 1
            goto L_0x0015
        L_0x0014:
            r0 = 0
        L_0x0015:
            if (r0 == 0) goto L_0x001a
            y.n$b r0 = y.n.b.dark
            goto L_0x001c
        L_0x001a:
            y.n$b r0 = y.n.b.light
        L_0x001c:
            android.view.textservice.TextServicesManager r3 = r6.f353r
            if (r3 == 0) goto L_0x0043
            int r4 = android.os.Build.VERSION.SDK_INT
            r5 = 31
            if (r4 < r5) goto L_0x0041
            java.util.List r3 = r3.getEnabledSpellCheckerInfos()
            java.util.stream.Stream r3 = r3.stream()
            io.flutter.embedding.android.r r4 = new io.flutter.embedding.android.r
            r4.<init>()
            boolean r3 = r3.anyMatch(r4)
            android.view.textservice.TextServicesManager r4 = r6.f353r
            boolean r4 = r4.isSpellCheckerEnabled()
            if (r4 == 0) goto L_0x0043
            if (r3 == 0) goto L_0x0043
        L_0x0041:
            r3 = 1
            goto L_0x0044
        L_0x0043:
            r3 = 0
        L_0x0044:
            io.flutter.embedding.engine.a r4 = r6.f343h
            y.n r4 = r4.u()
            y.n$a r4 = r4.a()
            android.content.res.Resources r5 = r6.getResources()
            android.content.res.Configuration r5 = r5.getConfiguration()
            float r5 = r5.fontScale
            y.n$a r4 = r4.e(r5)
            y.n$a r3 = r4.c(r3)
            android.content.Context r4 = r6.getContext()
            android.content.ContentResolver r4 = r4.getContentResolver()
            java.lang.String r5 = "show_password"
            int r4 = android.provider.Settings.System.getInt(r4, r5, r2)
            if (r4 != r2) goto L_0x0071
            r1 = 1
        L_0x0071:
            y.n$a r1 = r3.b(r1)
            android.content.Context r2 = r6.getContext()
            boolean r2 = android.text.format.DateFormat.is24HourFormat(r2)
            y.n$a r1 = r1.f(r2)
            y.n$a r0 = r1.d(r0)
            r0.a()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.flutter.embedding.android.s.E():void");
    }

    public void a(KeyEvent keyEvent) {
        getRootView().dispatchKeyEvent(keyEvent);
    }

    public void autofill(SparseArray<AutofillValue> sparseArray) {
        this.f346k.j(sparseArray);
    }

    public boolean b(KeyEvent keyEvent) {
        return this.f346k.r(keyEvent);
    }

    @TargetApi(24)
    public PointerIcon c(int i2) {
        return PointerIcon.getSystemIcon(getContext(), i2);
    }

    public boolean checkInputConnectionProxy(View view) {
        io.flutter.embedding.engine.a aVar = this.f343h;
        return aVar != null ? aVar.q().F(view) : super.checkInputConnectionProxy(view);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
            getKeyDispatcherState().startTracking(keyEvent, this);
        } else if (keyEvent.getAction() == 1) {
            getKeyDispatcherState().handleUpEvent(keyEvent);
        }
        return (x() && this.f350o.a(keyEvent)) || super.dispatchKeyEvent(keyEvent);
    }

    /* access modifiers changed from: protected */
    public boolean fitSystemWindows(Rect rect) {
        if (Build.VERSION.SDK_INT > 19) {
            return super.fitSystemWindows(rect);
        }
        a.g gVar = this.f355t;
        gVar.f1214d = rect.top;
        gVar.f1215e = rect.right;
        gVar.f1216f = 0;
        gVar.f1217g = rect.left;
        gVar.f1218h = 0;
        gVar.f1219i = 0;
        gVar.f1220j = rect.bottom;
        gVar.f1221k = 0;
        m.b.f("FlutterView", "Updating window insets (fitSystemWindows()):\nStatus bar insets: Top: " + this.f355t.f1214d + ", Left: " + this.f355t.f1217g + ", Right: " + this.f355t.f1215e + "\nKeyboard insets: Bottom: " + this.f355t.f1220j + ", Left: " + this.f355t.f1221k + ", Right: " + this.f355t.f1219i);
        F();
        return true;
    }

    public AccessibilityNodeProvider getAccessibilityNodeProvider() {
        io.flutter.view.j jVar = this.f352q;
        if (jVar == null || !jVar.D()) {
            return null;
        }
        return this.f352q;
    }

    public io.flutter.embedding.engine.a getAttachedFlutterEngine() {
        return this.f343h;
    }

    public z.b getBinaryMessenger() {
        return this.f343h.j();
    }

    public k getCurrentImageSurface() {
        return this.f338c;
    }

    public boolean k() {
        k kVar = this.f338c;
        if (kVar != null) {
            return kVar.d();
        }
        return false;
    }

    public void l(f fVar) {
        this.f344i.add(fVar);
    }

    public void m(x.c cVar) {
        this.f341f.add(cVar);
    }

    public void n(k kVar) {
        io.flutter.embedding.engine.a aVar = this.f343h;
        if (aVar != null) {
            kVar.c(aVar.s());
        }
    }

    public void o(io.flutter.embedding.engine.a aVar) {
        m.b.f("FlutterView", "Attaching to a FlutterEngine: " + aVar);
        if (x()) {
            if (aVar == this.f343h) {
                m.b.f("FlutterView", "Already attached to this engine. Doing nothing.");
                return;
            } else {
                m.b.f("FlutterView", "Currently attached to a different engine. Detaching and then attaching to new engine.");
                t();
            }
        }
        this.f343h = aVar;
        x.a s2 = aVar.s();
        this.f342g = s2.j();
        this.f339d.c(s2);
        s2.f(this.f358w);
        if (Build.VERSION.SDK_INT >= 24) {
            this.f345j = new c0.b(this, this.f343h.n());
        }
        this.f346k = new r(this, this.f343h.x(), this.f343h.q());
        try {
            TextServicesManager textServicesManager = (TextServicesManager) getContext().getSystemService("textservices");
            this.f353r = textServicesManager;
            this.f347l = new io.flutter.plugin.editing.j(textServicesManager, this.f343h.v());
        } catch (Exception unused) {
            m.b.b("FlutterView", "TextServicesManager not supported by device, spell check disabled.");
        }
        this.f349n = this.f343h.m();
        a0 a0Var = new a0(this);
        this.f350o = a0Var;
        this.f348m = new a0.a(a0Var, this.f343h.k());
        this.f351p = new a(this.f343h.s(), false);
        io.flutter.view.j jVar = new io.flutter.view.j(this, aVar.h(), (AccessibilityManager) getContext().getSystemService("accessibility"), getContext().getContentResolver(), this.f343h.q());
        this.f352q = jVar;
        jVar.Y(this.f356u);
        C(this.f352q.D(), this.f352q.E());
        this.f343h.q().b(this.f352q);
        this.f343h.q().D(this.f343h.s());
        this.f346k.q().restartInput(this);
        E();
        getContext().getContentResolver().registerContentObserver(Settings.System.getUriFor("show_password"), false, this.f357v);
        F();
        aVar.q().E(this);
        for (f a2 : this.f344i) {
            a2.a(aVar);
        }
        if (this.f342g) {
            this.f358w.d();
        }
    }

    @SuppressLint({"InlinedApi", "NewApi"})
    @TargetApi(20)
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        WindowInsets onApplyWindowInsets = super.onApplyWindowInsets(windowInsets);
        int i2 = Build.VERSION.SDK_INT;
        if (i2 == 29) {
            Insets a2 = windowInsets.getSystemGestureInsets();
            a.g gVar = this.f355t;
            gVar.f1222l = a2.top;
            gVar.f1223m = a2.right;
            gVar.f1224n = a2.bottom;
            gVar.f1225o = a2.left;
        }
        boolean z2 = true;
        int i3 = 0;
        boolean z3 = (getWindowSystemUiVisibility() & 4) == 0;
        if ((getWindowSystemUiVisibility() & 2) != 0) {
            z2 = false;
        }
        if (i2 >= 30) {
            if (z2) {
                i3 = 0 | WindowInsets.Type.navigationBars();
            }
            if (z3) {
                i3 |= WindowInsets.Type.statusBars();
            }
            Insets a3 = windowInsets.getInsets(i3);
            a.g gVar2 = this.f355t;
            gVar2.f1214d = a3.top;
            gVar2.f1215e = a3.right;
            gVar2.f1216f = a3.bottom;
            gVar2.f1217g = a3.left;
            Insets a4 = windowInsets.getInsets(WindowInsets.Type.ime());
            a.g gVar3 = this.f355t;
            gVar3.f1218h = a4.top;
            gVar3.f1219i = a4.right;
            gVar3.f1220j = a4.bottom;
            gVar3.f1221k = a4.left;
            Insets a5 = windowInsets.getInsets(WindowInsets.Type.systemGestures());
            a.g gVar4 = this.f355t;
            gVar4.f1222l = a5.top;
            gVar4.f1223m = a5.right;
            gVar4.f1224n = a5.bottom;
            gVar4.f1225o = a5.left;
            DisplayCutout a6 = windowInsets.getDisplayCutout();
            if (a6 != null) {
                Insets a7 = a6.getWaterfallInsets();
                a.g gVar5 = this.f355t;
                gVar5.f1214d = Math.max(Math.max(gVar5.f1214d, a7.top), a6.getSafeInsetTop());
                a.g gVar6 = this.f355t;
                gVar6.f1215e = Math.max(Math.max(gVar6.f1215e, a7.right), a6.getSafeInsetRight());
                a.g gVar7 = this.f355t;
                gVar7.f1216f = Math.max(Math.max(gVar7.f1216f, a7.bottom), a6.getSafeInsetBottom());
                a.g gVar8 = this.f355t;
                gVar8.f1217g = Math.max(Math.max(gVar8.f1217g, a7.left), a6.getSafeInsetLeft());
            }
        } else {
            g gVar9 = g.NONE;
            if (!z2) {
                gVar9 = p();
            }
            this.f355t.f1214d = z3 ? windowInsets.getSystemWindowInsetTop() : 0;
            this.f355t.f1215e = (gVar9 == g.RIGHT || gVar9 == g.BOTH) ? 0 : windowInsets.getSystemWindowInsetRight();
            this.f355t.f1216f = (!z2 || u(windowInsets) != 0) ? 0 : windowInsets.getSystemWindowInsetBottom();
            this.f355t.f1217g = (gVar9 == g.LEFT || gVar9 == g.BOTH) ? 0 : windowInsets.getSystemWindowInsetLeft();
            a.g gVar10 = this.f355t;
            gVar10.f1218h = 0;
            gVar10.f1219i = 0;
            gVar10.f1220j = u(windowInsets);
            this.f355t.f1221k = 0;
        }
        m.b.f("FlutterView", "Updating window insets (onApplyWindowInsets()):\nStatus bar insets: Top: " + this.f355t.f1214d + ", Left: " + this.f355t.f1217g + ", Right: " + this.f355t.f1215e + "\nKeyboard insets: Bottom: " + this.f355t.f1220j + ", Left: " + this.f355t.f1221k + ", Right: " + this.f355t.f1219i + "System Gesture Insets - Left: " + this.f355t.f1225o + ", Top: " + this.f355t.f1222l + ", Right: " + this.f355t.f1223m + ", Bottom: " + this.f355t.f1220j);
        F();
        return onApplyWindowInsets;
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f354s = s();
        Activity f2 = d0.j.f(getContext());
        h0 h0Var = this.f354s;
        if (h0Var != null && f2 != null) {
            h0Var.a(f2, androidx.core.content.d.b(getContext()), this.f359x);
        }
    }

    /* access modifiers changed from: protected */
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.f343h != null) {
            m.b.f("FlutterView", "Configuration changed. Sending locales and user settings to Flutter.");
            this.f349n.d(configuration);
            E();
            d0.j.c(getContext(), this.f343h);
        }
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        return !x() ? super.onCreateInputConnection(editorInfo) : this.f346k.o(this, this.f350o, editorInfo);
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        h0 h0Var = this.f354s;
        if (h0Var != null) {
            h0Var.b(this.f359x);
        }
        this.f354s = null;
        super.onDetachedFromWindow();
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if (x() && this.f351p.e(motionEvent)) {
            return true;
        }
        return super.onGenericMotionEvent(motionEvent);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        return !x() ? super.onHoverEvent(motionEvent) : this.f352q.J(motionEvent);
    }

    public void onProvideAutofillVirtualStructure(ViewStructure viewStructure, int i2) {
        super.onProvideAutofillVirtualStructure(viewStructure, i2);
        this.f346k.A(viewStructure, i2);
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        m.b.f("FlutterView", "Size changed. Sending Flutter new viewport metrics. FlutterView was " + i4 + " x " + i5 + ", it is now " + i2 + " x " + i3);
        a.g gVar = this.f355t;
        gVar.f1212b = i2;
        gVar.f1213c = i3;
        F();
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!x()) {
            return super.onTouchEvent(motionEvent);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            requestUnbufferedDispatch(motionEvent);
        }
        return this.f351p.f(motionEvent);
    }

    public void q() {
        this.f339d.a();
        k kVar = this.f338c;
        if (kVar == null) {
            k r2 = r();
            this.f338c = r2;
            addView(r2);
        } else {
            kVar.j(getWidth(), getHeight());
        }
        this.f340e = this.f339d;
        k kVar2 = this.f338c;
        this.f339d = kVar2;
        io.flutter.embedding.engine.a aVar = this.f343h;
        if (aVar != null) {
            kVar2.c(aVar.s());
        }
    }

    public k r() {
        return new k(getContext(), getWidth(), getHeight(), k.b.background);
    }

    /* access modifiers changed from: protected */
    public h0 s() {
        try {
            return new h0(new WindowInfoTrackerCallbackAdapter(WindowInfoTracker.Companion.getOrCreate(getContext())));
        } catch (NoClassDefFoundError unused) {
            return null;
        }
    }

    public void setVisibility(int i2) {
        super.setVisibility(i2);
        x.d dVar = this.f339d;
        if (dVar instanceof l) {
            ((l) dVar).setVisibility(i2);
        }
    }

    /* access modifiers changed from: protected */
    @TargetApi(28)
    public void setWindowInfoListenerDisplayFeatures(WindowLayoutInfo windowLayoutInfo) {
        WindowInsets rootWindowInsets;
        DisplayCutout a2;
        List<DisplayFeature> displayFeatures = windowLayoutInfo.getDisplayFeatures();
        ArrayList arrayList = new ArrayList();
        for (DisplayFeature next : displayFeatures) {
            m.b.f("FlutterView", "WindowInfoTracker Display Feature reported with bounds = " + next.getBounds().toString() + " and type = " + next.getClass().getSimpleName());
            if (next instanceof FoldingFeature) {
                FoldingFeature foldingFeature = (FoldingFeature) next;
                arrayList.add(new a.b(next.getBounds(), foldingFeature.getOcclusionType() == FoldingFeature.OcclusionType.FULL ? a.d.HINGE : a.d.FOLD, foldingFeature.getState() == FoldingFeature.State.FLAT ? a.c.POSTURE_FLAT : foldingFeature.getState() == FoldingFeature.State.HALF_OPENED ? a.c.POSTURE_HALF_OPENED : a.c.UNKNOWN));
            } else {
                arrayList.add(new a.b(next.getBounds(), a.d.UNKNOWN, a.c.UNKNOWN));
            }
        }
        if (!(Build.VERSION.SDK_INT < 28 || (rootWindowInsets = getRootWindowInsets()) == null || (a2 = rootWindowInsets.getDisplayCutout()) == null)) {
            for (Rect next2 : a2.getBoundingRects()) {
                m.b.f("FlutterView", "DisplayCutout area reported with bounds = " + next2.toString());
                arrayList.add(new a.b(next2, a.d.CUTOUT));
            }
        }
        this.f355t.f1227q = arrayList;
        F();
    }

    public void t() {
        m.b.f("FlutterView", "Detaching from a FlutterEngine: " + this.f343h);
        if (!x()) {
            m.b.f("FlutterView", "FlutterView not attached to an engine. Not detaching.");
            return;
        }
        for (f b2 : this.f344i) {
            b2.b();
        }
        getContext().getContentResolver().unregisterContentObserver(this.f357v);
        this.f343h.q().K();
        this.f343h.q().a();
        this.f352q.Q();
        this.f352q = null;
        this.f346k.q().restartInput(this);
        this.f346k.p();
        this.f350o.c();
        io.flutter.plugin.editing.j jVar = this.f347l;
        if (jVar != null) {
            jVar.b();
        }
        c0.b bVar = this.f345j;
        if (bVar != null) {
            bVar.c();
        }
        a0.a aVar = this.f348m;
        if (aVar != null) {
            aVar.b();
        }
        x.a s2 = this.f343h.s();
        this.f342g = false;
        s2.p(this.f358w);
        s2.t();
        s2.q(false);
        x.d dVar = this.f340e;
        if (dVar != null && this.f339d == this.f338c) {
            this.f339d = dVar;
        }
        this.f339d.b();
        z();
        this.f340e = null;
        this.f343h = null;
    }

    public boolean v() {
        return this.f342g;
    }

    public boolean x() {
        io.flutter.embedding.engine.a aVar = this.f343h;
        return aVar != null && aVar.s() == this.f339d.getAttachedRenderer();
    }
}
