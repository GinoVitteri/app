package io.flutter.embedding.android;

import java.util.HashMap;

public class b0 {

    /* renamed from: a  reason: collision with root package name */
    public static final HashMap<Long, Long> f263a = new a();

    /* renamed from: b  reason: collision with root package name */
    public static final HashMap<Long, Long> f264b = new b();

    /* renamed from: c  reason: collision with root package name */
    public static final d[] f265c = {new d(4096, new c[]{new c(458976, 8589934848L), new c(458980, 8589934849L)}), new d(1, new c[]{new c(458977, 8589934850L), new c(458981, 8589934851L)}), new d(2, new c[]{new c(458978, 8589934852L), new c(458982, 8589934853L)})};

    class a extends HashMap<Long, Long> {
        a() {
            put(464L, 18L);
            put(205L, 20L);
            put(142L, 65666L);
            put(143L, 65667L);
            put(256L, 392961L);
            put(288L, 392961L);
            put(257L, 392962L);
            put(289L, 392962L);
            put(258L, 392963L);
            put(290L, 392963L);
            put(259L, 392964L);
            put(291L, 392964L);
            put(260L, 392965L);
            put(292L, 392965L);
            put(261L, 392966L);
            put(293L, 392966L);
            put(262L, 392967L);
            put(294L, 392967L);
            put(263L, 392968L);
            put(295L, 392968L);
            put(264L, 392969L);
            put(296L, 392969L);
            put(265L, 392970L);
            put(297L, 392970L);
            put(266L, 392971L);
            put(298L, 392971L);
            put(267L, 392972L);
            put(299L, 392972L);
            put(268L, 392973L);
            put(300L, 392973L);
            put(269L, 392974L);
            put(301L, 392974L);
            put(270L, 392975L);
            put(302L, 392975L);
            put(271L, 392976L);
            put(303L, 392976L);
            put(304L, 392977L);
            put(305L, 392978L);
            put(306L, 392979L);
            put(310L, 392980L);
            put(312L, 392981L);
            put(316L, 392982L);
            put(311L, 392983L);
            put(313L, 392984L);
            put(314L, 392985L);
            put(315L, 392986L);
            put(317L, 392987L);
            put(318L, 392988L);
            put(307L, 392989L);
            put(308L, 392990L);
            put(309L, 392991L);
            put(30L, 458756L);
            put(48L, 458757L);
            put(46L, 458758L);
            put(32L, 458759L);
            put(18L, 458760L);
            put(33L, 458761L);
            put(34L, 458762L);
            put(35L, 458763L);
            put(23L, 458764L);
            put(36L, 458765L);
            put(37L, 458766L);
            put(38L, 458767L);
            put(50L, 458768L);
            put(49L, 458769L);
            put(24L, 458770L);
            put(25L, 458771L);
            put(16L, 458772L);
            put(19L, 458773L);
            put(31L, 458774L);
            put(20L, 458775L);
            put(22L, 458776L);
            put(47L, 458777L);
            put(17L, 458778L);
            put(45L, 458779L);
            put(21L, 458780L);
            put(44L, 458781L);
            put(2L, 458782L);
            put(3L, 458783L);
            put(4L, 458784L);
            put(5L, 458785L);
            put(6L, 458786L);
            put(7L, 458787L);
            put(8L, 458788L);
            put(9L, 458789L);
            put(10L, 458790L);
            put(11L, 458791L);
            put(28L, 458792L);
            put(1L, 458793L);
            put(14L, 458794L);
            put(15L, 458795L);
            put(57L, 458796L);
            put(12L, 458797L);
            put(13L, 458798L);
            put(26L, 458799L);
            put(27L, 458800L);
            put(43L, 458801L);
            put(86L, 458801L);
            put(39L, 458803L);
            put(40L, 458804L);
            put(41L, 458805L);
            put(51L, 458806L);
            put(52L, 458807L);
            put(53L, 458808L);
            put(58L, 458809L);
            put(59L, 458810L);
            put(60L, 458811L);
            put(61L, 458812L);
            put(62L, 458813L);
            put(63L, 458814L);
            put(64L, 458815L);
            put(65L, 458816L);
            put(66L, 458817L);
            put(67L, 458818L);
            put(68L, 458819L);
            put(87L, 458820L);
            put(88L, 458821L);
            put(99L, 458822L);
            put(70L, 458823L);
            put(119L, 458824L);
            put(411L, 458824L);
            put(110L, 458825L);
            put(102L, 458826L);
            put(104L, 458827L);
            put(177L, 458827L);
            put(111L, 458828L);
            put(107L, 458829L);
            put(109L, 458830L);
            put(178L, 458830L);
            put(106L, 458831L);
            put(105L, 458832L);
            put(108L, 458833L);
            put(103L, 458834L);
            put(69L, 458835L);
            put(98L, 458836L);
            put(55L, 458837L);
            put(74L, 458838L);
            put(78L, 458839L);
            put(96L, 458840L);
            put(79L, 458841L);
            put(80L, 458842L);
            put(81L, 458843L);
            put(75L, 458844L);
            put(76L, 458845L);
            put(77L, 458846L);
            put(71L, 458847L);
            put(72L, 458848L);
            put(73L, 458849L);
            put(82L, 458850L);
            put(83L, 458851L);
            put(127L, 458853L);
            put(139L, 458853L);
            put(116L, 458854L);
            put(152L, 458854L);
            put(117L, 458855L);
            put(183L, 458856L);
            put(184L, 458857L);
            put(185L, 458858L);
            put(186L, 458859L);
            put(187L, 458860L);
            put(188L, 458861L);
            put(189L, 458862L);
            put(190L, 458863L);
            put(191L, 458864L);
            put(192L, 458865L);
            put(193L, 458866L);
            put(194L, 458867L);
            put(134L, 458868L);
            put(138L, 458869L);
            put(353L, 458871L);
            put(129L, 458873L);
            put(131L, 458874L);
            put(137L, 458875L);
            put(133L, 458876L);
            put(135L, 458877L);
            put(136L, 458878L);
            put(113L, 458879L);
            put(115L, 458880L);
            put(114L, 458881L);
            put(95L, 458885L);
            put(121L, 458885L);
            put(89L, 458887L);
            put(124L, 458889L);
            put(92L, 458890L);
            put(94L, 458891L);
            put(90L, 458898L);
            put(91L, 458899L);
            put(130L, 458915L);
            put(179L, 458934L);
            put(180L, 458935L);
            put(29L, 458976L);
            put(42L, 458977L);
            put(56L, 458978L);
            put(125L, 458979L);
            put(97L, 458980L);
            put(54L, 458981L);
            put(100L, 458982L);
            put(126L, 458983L);
            put(358L, 786528L);
            put(370L, 786529L);
            put(225L, 786543L);
            put(224L, 786544L);
            put(405L, 786563L);
            put(174L, 786580L);
            put(402L, 786588L);
            put(403L, 786589L);
            put(200L, 786608L);
            put(207L, 786608L);
            put(201L, 786609L);
            put(167L, 786610L);
            put(208L, 786611L);
            put(168L, 786612L);
            put(163L, 786613L);
            put(165L, 786614L);
            put(128L, 786615L);
            put(166L, 786615L);
            put(161L, 786616L);
            put(162L, 786616L);
            put(164L, 786637L);
            put(209L, 786661L);
            put(155L, 786826L);
            put(215L, 786826L);
            put(429L, 786829L);
            put(397L, 786830L);
            put(583L, 786891L);
            put(160L, 786947L);
            put(206L, 786947L);
            put(210L, 786952L);
            put(217L, 786977L);
            put(159L, 786981L);
            put(156L, 786986L);
            put(182L, 787065L);
        }
    }

    class b extends HashMap<Long, Long> {
        b() {
            put(62L, 32L);
            put(75L, 34L);
            put(18L, 35L);
            put(17L, 42L);
            put(81L, 43L);
            put(55L, 44L);
            put(69L, 45L);
            put(56L, 46L);
            put(76L, 47L);
            put(7L, 48L);
            put(8L, 49L);
            put(9L, 50L);
            put(10L, 51L);
            put(11L, 52L);
            put(12L, 53L);
            put(13L, 54L);
            put(14L, 55L);
            put(15L, 56L);
            put(16L, 57L);
            put(74L, 59L);
            put(70L, 61L);
            put(77L, 64L);
            put(71L, 91L);
            put(73L, 92L);
            put(72L, 93L);
            put(68L, 96L);
            put(29L, 97L);
            put(30L, 98L);
            put(31L, 99L);
            put(32L, 100L);
            put(33L, 101L);
            put(34L, 102L);
            put(35L, 103L);
            put(36L, 104L);
            put(37L, 105L);
            put(38L, 106L);
            put(39L, 107L);
            put(40L, 108L);
            put(41L, 109L);
            put(42L, 110L);
            put(43L, 111L);
            put(44L, 112L);
            put(45L, 113L);
            put(46L, 114L);
            put(47L, 115L);
            put(48L, 116L);
            put(49L, 117L);
            put(50, 118L);
            put(51, 119L);
            put(52L, 120L);
            put(53L, 121L);
            put(54L, 122L);
            put(67L, 4294967304L);
            put(61L, 4294967305L);
            put(66L, 4294967309L);
            put(111L, 4294967323L);
            put(112L, 4294967423L);
            put(115L, 4294967556L);
            put(119L, 4294967558L);
            put(143L, 4294967562L);
            put(116L, 4294967564L);
            put(63L, 4294967567L);
            put(20L, 4294968065L);
            put(21L, 4294968066L);
            put(22L, 4294968067L);
            put(19L, 4294968068L);
            put(123L, 4294968069L);
            put(122L, 4294968070L);
            put(93L, 4294968071L);
            put(92L, 4294968072L);
            put(28L, 4294968321L);
            put(278L, 4294968322L);
            put(277L, 4294968324L);
            put(124L, 4294968327L);
            put(279L, 4294968328L);
            put(82L, 4294968581L);
            put(259L, 4294968584L);
            put(121L, 4294968585L);
            put(23L, 4294968588L);
            put(168L, 4294968589L);
            put(169L, 4294968590L);
            put(220L, 4294968833L);
            put(221L, 4294968834L);
            put(27L, 4294968835L);
            put(129L, 4294968836L);
            put(26L, 4294968838L);
            put(120L, 4294968840L);
            put(224L, 4294968843L);
            put(214L, 4294969093L);
            put(204L, 4294969097L);
            put(95L, 4294969099L);
            put(213L, 4294969101L);
            put(212L, 4294969108L);
            put(215L, 4294969111L);
            put(218L, 4294969113L);
            put(211L, 4294969117L);
            put(131L, 4294969345L);
            put(132L, 4294969346L);
            put(133L, 4294969347L);
            put(134L, 4294969348L);
            put(135L, 4294969349L);
            put(136L, 4294969350L);
            put(137L, 4294969351L);
            put(138L, 4294969352L);
            put(139L, 4294969353L);
            put(140L, 4294969354L);
            put(141L, 4294969355L);
            put(142L, 4294969356L);
            put(128L, 4294969857L);
            put(85L, 4294969861L);
            put(86L, 4294969863L);
            put(87L, 4294969864L);
            put(88L, 4294969865L);
            put(25L, 4294969871L);
            put(24L, 4294969872L);
            put(164L, 4294969873L);
            put(208L, 4294970114L);
            put(65L, 4294970115L);
            put(209L, 4294970117L);
            put(64L, 4294970121L);
            put(207L, 4294970124L);
            put(219L, 4294970126L);
            put(174L, 4294970370L);
            put(125L, 4294970371L);
            put(84L, 4294970374L);
            put(182L, 4294970632L);
            put(181L, 4294970633L);
            put(167L, 4294970634L);
            put(166L, 4294970635L);
            put(183L, 4294970636L);
            put(184L, 4294970637L);
            put(185L, 4294970638L);
            put(186L, 4294970639L);
            put(175L, 4294970642L);
            put(172L, 4294970658L);
            put(165L, 4294970661L);
            put(90L, 4294970668L);
            put(229L, 4294970669L);
            put(127L, 4294970670L);
            put(126L, 4294970671L);
            put(130L, 4294970672L);
            put(89L, 4294970673L);
            put(176L, 4294970691L);
            put(180L, 4294970693L);
            put(179L, 4294970694L);
            put(233L, 4294970696L);
            put(170L, 4294970697L);
            put(178L, 4294970698L);
            put(177L, 4294970699L);
            put(255L, 4294970702L);
            put(173L, 4294970703L);
            put(222L, 4294970704L);
            put(273L, 4294970705L);
            put(272L, 4294970706L);
            put(275L, 4294970707L);
            put(274L, 4294970708L);
            put(226L, 4294970709L);
            put(262L, 4294970710L);
            put(261L, 4294970711L);
            put(263L, 4294970712L);
            put(260L, 4294970713L);
            put(225L, 4294970714L);
            put(91L, 4294970889L);
            put(187L, 4294971393L);
            put(5L, 4294971394L);
            put(80L, 4294971395L);
            put(6L, 4294971396L);
            put(4L, 4294971397L);
            put(3L, 4294971398L);
            put(79L, 4294971399L);
            put(83L, 4294971401L);
            put(205L, 4294971402L);
            put(206L, 4294971649L);
            put(242L, 4294971650L);
            put(252L, 4294971651L);
            put(254L, 4294971652L);
            put(253L, 4294971653L);
            put(256L, 4294971654L);
            put(230L, 4294971655L);
            put(249L, 4294971656L);
            put(250L, 4294971657L);
            put(247L, 4294971658L);
            put(248L, 4294971659L);
            put(243L, 4294971660L);
            put(244L, 4294971661L);
            put(245L, 4294971662L);
            put(246L, 4294971663L);
            put(251L, 4294971664L);
            put(241L, 4294971666L);
            put(234L, 4294971667L);
            put(232L, 4294971668L);
            put(237L, 4294971669L);
            put(238L, 4294971670L);
            put(239L, 4294971671L);
            put(240L, 4294971672L);
            put(235L, 4294971673L);
            put(236L, 4294971674L);
            put(258L, 4294971675L);
            put(223L, 8589934594L);
            put(217L, 8589934625L);
            put(216L, 8589934626L);
            put(113L, 8589934848L);
            put(114L, 8589934849L);
            put(59L, 8589934850L);
            put(60L, 8589934851L);
            put(57L, 8589934852L);
            put(58L, 8589934853L);
            put(117L, 8589934854L);
            put(118L, 8589934855L);
            put(160L, 8589935117L);
            put(162L, 8589935144L);
            put(163L, 8589935145L);
            put(155L, 8589935146L);
            put(157L, 8589935147L);
            put(159L, 8589935148L);
            put(156L, 8589935149L);
            put(158L, 8589935150L);
            put(154L, 8589935151L);
            put(144L, 8589935152L);
            put(145L, 8589935153L);
            put(146L, 8589935154L);
            put(147L, 8589935155L);
            put(148L, 8589935156L);
            put(149L, 8589935157L);
            put(150L, 8589935158L);
            put(151L, 8589935159L);
            put(152L, 8589935160L);
            put(153L, 8589935161L);
            put(161L, 8589935165L);
            put(188L, 8589935361L);
            put(189L, 8589935362L);
            put(190L, 8589935363L);
            put(191L, 8589935364L);
            put(192L, 8589935365L);
            put(193L, 8589935366L);
            put(194L, 8589935367L);
            put(195L, 8589935368L);
            put(196L, 8589935369L);
            put(197L, 8589935370L);
            put(198L, 8589935371L);
            put(199L, 8589935372L);
            put(200L, 8589935373L);
            put(201L, 8589935374L);
            put(202L, 8589935375L);
            put(203L, 8589935376L);
            put(96L, 8589935377L);
            put(97L, 8589935378L);
            put(98L, 8589935379L);
            put(102L, 8589935380L);
            put(104L, 8589935381L);
            put(110L, 8589935382L);
            put(103L, 8589935383L);
            put(105L, 8589935384L);
            put(109L, 8589935385L);
            put(108L, 8589935386L);
            put(106L, 8589935387L);
            put(107L, 8589935388L);
            put(99L, 8589935389L);
            put(100L, 8589935390L);
            put(101L, 8589935391L);
        }
    }

    public static class c {

        /* renamed from: a  reason: collision with root package name */
        public long f266a;

        /* renamed from: b  reason: collision with root package name */
        public long f267b;

        public c(long j2, long j3) {
            this.f266a = j2;
            this.f267b = j3;
        }
    }

    public static class d {

        /* renamed from: a  reason: collision with root package name */
        public final int f268a;

        /* renamed from: b  reason: collision with root package name */
        public final c[] f269b;

        public d(int i2, c[] cVarArr) {
            this.f268a = i2;
            this.f269b = cVarArr;
        }
    }

    public static class e {

        /* renamed from: a  reason: collision with root package name */
        public final int f270a;

        /* renamed from: b  reason: collision with root package name */
        public final long f271b;

        /* renamed from: c  reason: collision with root package name */
        public final long f272c;

        /* renamed from: d  reason: collision with root package name */
        public boolean f273d = false;

        public e(int i2, long j2, long j3) {
            this.f270a = i2;
            this.f271b = j2;
            this.f272c = j3;
        }
    }

    public static e[] a() {
        return new e[]{new e(1048576, 458809, 4294967556L)};
    }
}
