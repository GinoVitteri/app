package io.flutter.embedding.android;

public enum g {
    opaque,
    transparent
}
