package io.flutter.embedding.android;

public enum g0 {
    opaque,
    transparent
}
