package io.flutter.embedding.android;

import android.content.Context;
import android.graphics.Region;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import x.c;
import x.d;

public class l extends SurfaceView implements d {

    /* renamed from: a  reason: collision with root package name */
    private final boolean f320a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public boolean f321b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f322c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public boolean f323d;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public x.a f324e;

    /* renamed from: f  reason: collision with root package name */
    private final SurfaceHolder.Callback f325f;

    /* renamed from: g  reason: collision with root package name */
    private final c f326g;

    class a implements SurfaceHolder.Callback {
        a() {
        }

        public void surfaceChanged(SurfaceHolder surfaceHolder, int i2, int i3, int i4) {
            m.b.f("FlutterSurfaceView", "SurfaceHolder.Callback.surfaceChanged()");
            if (l.this.f323d) {
                l.this.j(i3, i4);
            }
        }

        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            m.b.f("FlutterSurfaceView", "SurfaceHolder.Callback.startRenderingToSurface()");
            boolean unused = l.this.f321b = true;
            if (l.this.f323d) {
                l.this.k();
            }
        }

        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            m.b.f("FlutterSurfaceView", "SurfaceHolder.Callback.stopRenderingToSurface()");
            boolean unused = l.this.f321b = false;
            if (l.this.f323d) {
                l.this.l();
            }
        }
    }

    class b implements c {
        b() {
        }

        public void b() {
        }

        public void d() {
            m.b.f("FlutterSurfaceView", "onFlutterUiDisplayed()");
            l.this.setAlpha(1.0f);
            if (l.this.f324e != null) {
                l.this.f324e.p(this);
            }
        }
    }

    private l(Context context, AttributeSet attributeSet, boolean z2) {
        super(context, attributeSet);
        this.f321b = false;
        this.f322c = false;
        this.f323d = false;
        this.f325f = new a();
        this.f326g = new b();
        this.f320a = z2;
        m();
    }

    public l(Context context, boolean z2) {
        this(context, (AttributeSet) null, z2);
    }

    /* access modifiers changed from: private */
    public void j(int i2, int i3) {
        if (this.f324e != null) {
            m.b.f("FlutterSurfaceView", "Notifying FlutterRenderer that Android surface size has changed to " + i2 + " x " + i3);
            this.f324e.u(i2, i3);
            return;
        }
        throw new IllegalStateException("changeSurfaceSize() should only be called when flutterRenderer is non-null.");
    }

    /* access modifiers changed from: private */
    public void k() {
        if (this.f324e == null || getHolder() == null) {
            throw new IllegalStateException("connectSurfaceToRenderer() should only be called when flutterRenderer and getHolder() are non-null.");
        }
        this.f324e.s(getHolder().getSurface(), this.f322c);
    }

    /* access modifiers changed from: private */
    public void l() {
        x.a aVar = this.f324e;
        if (aVar != null) {
            aVar.t();
            return;
        }
        throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
    }

    private void m() {
        if (this.f320a) {
            getHolder().setFormat(-2);
            setZOrderOnTop(true);
        }
        getHolder().addCallback(this.f325f);
        setAlpha(0.0f);
    }

    public void a() {
        if (this.f324e != null) {
            this.f324e = null;
            this.f322c = true;
            this.f323d = false;
            return;
        }
        m.b.g("FlutterSurfaceView", "pause() invoked when no FlutterRenderer was attached.");
    }

    public void b() {
        if (this.f324e != null) {
            if (getWindowToken() != null) {
                m.b.f("FlutterSurfaceView", "Disconnecting FlutterRenderer from Android surface.");
                l();
            }
            setAlpha(0.0f);
            this.f324e.p(this.f326g);
            this.f324e = null;
            this.f323d = false;
            return;
        }
        m.b.g("FlutterSurfaceView", "detachFromRenderer() invoked when no FlutterRenderer was attached.");
    }

    public void c(x.a aVar) {
        m.b.f("FlutterSurfaceView", "Attaching to FlutterRenderer.");
        if (this.f324e != null) {
            m.b.f("FlutterSurfaceView", "Already connected to a FlutterRenderer. Detaching from old one and attaching to new one.");
            this.f324e.t();
            this.f324e.p(this.f326g);
        }
        this.f324e = aVar;
        this.f323d = true;
        aVar.f(this.f326g);
        if (this.f321b) {
            m.b.f("FlutterSurfaceView", "Surface is available for rendering. Connecting FlutterRenderer to Android surface.");
            k();
        }
        this.f322c = false;
    }

    public boolean gatherTransparentRegion(Region region) {
        if (getAlpha() < 1.0f) {
            return false;
        }
        int[] iArr = new int[2];
        getLocationInWindow(iArr);
        int i2 = iArr[0];
        region.op(i2, iArr[1], (getRight() + i2) - getLeft(), (iArr[1] + getBottom()) - getTop(), Region.Op.DIFFERENCE);
        return true;
    }

    public x.a getAttachedRenderer() {
        return this.f324e;
    }
}
