package io.flutter.embedding.android;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import d0.j;
import io.flutter.embedding.engine.d;
import io.flutter.embedding.engine.e;
import io.flutter.plugin.platform.h;
import java.util.Arrays;
import java.util.List;
import n.a;

class f implements c<Activity> {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public c f288a;

    /* renamed from: b  reason: collision with root package name */
    private io.flutter.embedding.engine.a f289b;

    /* renamed from: c  reason: collision with root package name */
    s f290c;

    /* renamed from: d  reason: collision with root package name */
    private h f291d;

    /* renamed from: e  reason: collision with root package name */
    ViewTreeObserver.OnPreDrawListener f292e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f293f;
    /* access modifiers changed from: private */

    /* renamed from: g  reason: collision with root package name */
    public boolean f294g;
    /* access modifiers changed from: private */

    /* renamed from: h  reason: collision with root package name */
    public boolean f295h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f296i;

    /* renamed from: j  reason: collision with root package name */
    private Integer f297j;

    /* renamed from: k  reason: collision with root package name */
    private d f298k;

    /* renamed from: l  reason: collision with root package name */
    private final x.c f299l;

    class a implements x.c {
        a() {
        }

        public void b() {
            f.this.f288a.b();
            boolean unused = f.this.f294g = false;
        }

        public void d() {
            f.this.f288a.d();
            boolean unused = f.this.f294g = true;
            boolean unused2 = f.this.f295h = true;
        }
    }

    class b implements ViewTreeObserver.OnPreDrawListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ s f301a;

        b(s sVar) {
            this.f301a = sVar;
        }

        public boolean onPreDraw() {
            if (f.this.f294g && f.this.f292e != null) {
                this.f301a.getViewTreeObserver().removeOnPreDrawListener(this);
                f.this.f292e = null;
            }
            return f.this.f294g;
        }
    }

    interface c extends h.d {
        boolean A();

        g0 B();

        void C(m mVar);

        void D(io.flutter.embedding.engine.a aVar);

        void b();

        void c();

        void d();

        androidx.lifecycle.c e();

        String f();

        String g();

        Context getContext();

        io.flutter.embedding.engine.h h();

        List<String> k();

        boolean l();

        d0 m();

        boolean n();

        boolean o();

        String p();

        boolean q();

        String r();

        void s(io.flutter.embedding.engine.a aVar);

        f0 t();

        String u();

        h v(Activity activity, io.flutter.embedding.engine.a aVar);

        void w(l lVar);

        Activity x();

        String y();

        io.flutter.embedding.engine.a z(Context context);
    }

    f(c cVar) {
        this(cVar, (d) null);
    }

    f(c cVar, d dVar) {
        this.f299l = new a();
        this.f288a = cVar;
        this.f295h = false;
        this.f298k = dVar;
    }

    private d.b g(d.b bVar) {
        String y2 = this.f288a.y();
        if (y2 == null || y2.isEmpty()) {
            y2 = m.a.e().c().f();
        }
        a.b bVar2 = new a.b(y2, this.f288a.r());
        String g2 = this.f288a.g();
        if (g2 == null && (g2 = o(this.f288a.x().getIntent())) == null) {
            g2 = "/";
        }
        return bVar.i(bVar2).k(g2).j(this.f288a.k());
    }

    private void h(s sVar) {
        if (this.f288a.m() == d0.surface) {
            if (this.f292e != null) {
                sVar.getViewTreeObserver().removeOnPreDrawListener(this.f292e);
            }
            this.f292e = new b(sVar);
            sVar.getViewTreeObserver().addOnPreDrawListener(this.f292e);
            return;
        }
        throw new IllegalArgumentException("Cannot delay the first Android view draw when the render mode is not set to `RenderMode.surface`.");
    }

    private void i() {
        String str;
        if (this.f288a.p() == null && !this.f289b.j().i()) {
            String g2 = this.f288a.g();
            if (g2 == null && (g2 = o(this.f288a.x().getIntent())) == null) {
                g2 = "/";
            }
            String u2 = this.f288a.u();
            if (("Executing Dart entrypoint: " + this.f288a.r() + ", library uri: " + u2) == null) {
                str = "\"\"";
            } else {
                str = u2 + ", and sending initial route: " + g2;
            }
            m.b.f("FlutterActivityAndFragmentDelegate", str);
            this.f289b.o().c(g2);
            String y2 = this.f288a.y();
            if (y2 == null || y2.isEmpty()) {
                y2 = m.a.e().c().f();
            }
            this.f289b.j().g(u2 == null ? new a.b(y2, this.f288a.r()) : new a.b(y2, u2, this.f288a.r()), this.f288a.k());
        }
    }

    private void j() {
        if (this.f288a == null) {
            throw new IllegalStateException("Cannot execute method on a destroyed FlutterActivityAndFragmentDelegate.");
        }
    }

    private String o(Intent intent) {
        Uri data;
        if (!this.f288a.A() || (data = intent.getData()) == null) {
            return null;
        }
        return data.toString();
    }

    /* access modifiers changed from: package-private */
    public void A() {
        io.flutter.embedding.engine.a aVar;
        m.b.f("FlutterActivityAndFragmentDelegate", "onResume()");
        j();
        if (this.f288a.o() && (aVar = this.f289b) != null) {
            aVar.l().e();
        }
    }

    /* access modifiers changed from: package-private */
    public void B(Bundle bundle) {
        m.b.f("FlutterActivityAndFragmentDelegate", "onSaveInstanceState. Giving framework and plugins an opportunity to save state.");
        j();
        if (this.f288a.q()) {
            bundle.putByteArray("framework", this.f289b.t().h());
        }
        if (this.f288a.l()) {
            Bundle bundle2 = new Bundle();
            this.f289b.i().e(bundle2);
            bundle.putBundle("plugins", bundle2);
        }
    }

    /* access modifiers changed from: package-private */
    public void C() {
        m.b.f("FlutterActivityAndFragmentDelegate", "onStart()");
        j();
        i();
        Integer num = this.f297j;
        if (num != null) {
            this.f290c.setVisibility(num.intValue());
        }
    }

    /* access modifiers changed from: package-private */
    public void D() {
        io.flutter.embedding.engine.a aVar;
        m.b.f("FlutterActivityAndFragmentDelegate", "onStop()");
        j();
        if (this.f288a.o() && (aVar = this.f289b) != null) {
            aVar.l().d();
        }
        this.f297j = Integer.valueOf(this.f290c.getVisibility());
        this.f290c.setVisibility(8);
    }

    /* access modifiers changed from: package-private */
    public void E(int i2) {
        j();
        io.flutter.embedding.engine.a aVar = this.f289b;
        if (aVar != null) {
            if (this.f295h && i2 >= 10) {
                aVar.j().j();
                this.f289b.w().a();
            }
            this.f289b.s().m(i2);
        }
    }

    /* access modifiers changed from: package-private */
    public void F() {
        j();
        if (this.f289b != null) {
            m.b.f("FlutterActivityAndFragmentDelegate", "Forwarding onUserLeaveHint() to FlutterEngine.");
            this.f289b.i().f();
            return;
        }
        m.b.g("FlutterActivityAndFragmentDelegate", "onUserLeaveHint() invoked before FlutterFragment was attached to an Activity.");
    }

    /* access modifiers changed from: package-private */
    public void G(boolean z2) {
        io.flutter.embedding.engine.a aVar;
        j();
        StringBuilder sb = new StringBuilder();
        sb.append("Received onWindowFocusChanged: ");
        sb.append(z2 ? "true" : "false");
        m.b.f("FlutterActivityAndFragmentDelegate", sb.toString());
        if (this.f288a.o() && (aVar = this.f289b) != null) {
            if (z2) {
                aVar.l().a();
            } else {
                aVar.l().f();
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void H() {
        this.f288a = null;
        this.f289b = null;
        this.f290c = null;
        this.f291d = null;
    }

    /* access modifiers changed from: package-private */
    public void I() {
        d dVar;
        d.b l2;
        m.b.f("FlutterActivityAndFragmentDelegate", "Setting up FlutterEngine.");
        String p2 = this.f288a.p();
        if (p2 != null) {
            io.flutter.embedding.engine.a a2 = io.flutter.embedding.engine.b.b().a(p2);
            this.f289b = a2;
            this.f293f = true;
            if (a2 == null) {
                throw new IllegalStateException("The requested cached FlutterEngine did not exist in the FlutterEngineCache: '" + p2 + "'");
            }
            return;
        }
        c cVar = this.f288a;
        io.flutter.embedding.engine.a z2 = cVar.z(cVar.getContext());
        this.f289b = z2;
        if (z2 != null) {
            this.f293f = true;
            return;
        }
        String f2 = this.f288a.f();
        if (f2 != null) {
            dVar = e.b().a(f2);
            if (dVar != null) {
                l2 = new d.b(this.f288a.getContext());
            } else {
                throw new IllegalStateException("The requested cached FlutterEngineGroup did not exist in the FlutterEngineGroupCache: '" + f2 + "'");
            }
        } else {
            m.b.f("FlutterActivityAndFragmentDelegate", "No preferred FlutterEngine was provided. Creating a new FlutterEngine for this FlutterFragment.");
            dVar = this.f298k;
            if (dVar == null) {
                dVar = new d(this.f288a.getContext(), this.f288a.h().b());
            }
            l2 = new d.b(this.f288a.getContext()).h(false).l(this.f288a.q());
        }
        this.f289b = dVar.a(g(l2));
        this.f293f = false;
    }

    /* access modifiers changed from: package-private */
    public void J() {
        h hVar = this.f291d;
        if (hVar != null) {
            hVar.A();
        }
    }

    public void c() {
        if (!this.f288a.n()) {
            this.f288a.c();
            return;
        }
        throw new AssertionError("The internal FlutterEngine created by " + this.f288a + " has been attached to by another activity. To persist a FlutterEngine beyond the ownership of this activity, explicitly create a FlutterEngine");
    }

    /* renamed from: k */
    public Activity d() {
        Activity x2 = this.f288a.x();
        if (x2 != null) {
            return x2;
        }
        throw new AssertionError("FlutterActivityAndFragmentDelegate's getAppComponent should only be queried after onAttach, when the host's activity should always be non-null");
    }

    /* access modifiers changed from: package-private */
    public io.flutter.embedding.engine.a l() {
        return this.f289b;
    }

    /* access modifiers changed from: package-private */
    public boolean m() {
        return this.f296i;
    }

    /* access modifiers changed from: package-private */
    public boolean n() {
        return this.f293f;
    }

    /* access modifiers changed from: package-private */
    public void p(int i2, int i3, Intent intent) {
        j();
        if (this.f289b != null) {
            m.b.f("FlutterActivityAndFragmentDelegate", "Forwarding onActivityResult() to FlutterEngine:\nrequestCode: " + i2 + "\nresultCode: " + i3 + "\ndata: " + intent);
            this.f289b.i().a(i2, i3, intent);
            return;
        }
        m.b.g("FlutterActivityAndFragmentDelegate", "onActivityResult() invoked before FlutterFragment was attached to an Activity.");
    }

    /* access modifiers changed from: package-private */
    public void q(Context context) {
        j();
        if (this.f289b == null) {
            I();
        }
        if (this.f288a.l()) {
            m.b.f("FlutterActivityAndFragmentDelegate", "Attaching FlutterEngine to the Activity that owns this delegate.");
            this.f289b.i().h(this, this.f288a.e());
        }
        c cVar = this.f288a;
        this.f291d = cVar.v(cVar.x(), this.f289b);
        this.f288a.D(this.f289b);
        this.f296i = true;
    }

    /* access modifiers changed from: package-private */
    public void r() {
        j();
        if (this.f289b != null) {
            m.b.f("FlutterActivityAndFragmentDelegate", "Forwarding onBackPressed() to FlutterEngine.");
            this.f289b.o().a();
            return;
        }
        m.b.g("FlutterActivityAndFragmentDelegate", "Invoked onBackPressed() before FlutterFragment was attached to an Activity.");
    }

    /* access modifiers changed from: package-private */
    public View s(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle, int i2, boolean z2) {
        s sVar;
        m.b.f("FlutterActivityAndFragmentDelegate", "Creating FlutterView.");
        j();
        boolean z3 = true;
        if (this.f288a.m() == d0.surface) {
            Context context = this.f288a.getContext();
            if (this.f288a.B() != g0.transparent) {
                z3 = false;
            }
            l lVar = new l(context, z3);
            this.f288a.w(lVar);
            sVar = new s(this.f288a.getContext(), lVar);
        } else {
            m mVar = new m(this.f288a.getContext());
            if (this.f288a.B() != g0.opaque) {
                z3 = false;
            }
            mVar.setOpaque(z3);
            this.f288a.C(mVar);
            sVar = new s(this.f288a.getContext(), mVar);
        }
        this.f290c = sVar;
        this.f290c.m(this.f299l);
        m.b.f("FlutterActivityAndFragmentDelegate", "Attaching FlutterEngine to FlutterView.");
        this.f290c.o(this.f289b);
        this.f290c.setId(i2);
        f0 t2 = this.f288a.t();
        if (t2 != null) {
            m.b.g("FlutterActivityAndFragmentDelegate", "A splash screen was provided to Flutter, but this is deprecated. See flutter.dev/go/android-splash-migration for migration steps.");
            FlutterSplashView flutterSplashView = new FlutterSplashView(this.f288a.getContext());
            flutterSplashView.setId(j.e(486947586));
            flutterSplashView.g(this.f290c, t2);
            return flutterSplashView;
        }
        if (z2) {
            h(this.f290c);
        }
        return this.f290c;
    }

    /* access modifiers changed from: package-private */
    public void t() {
        m.b.f("FlutterActivityAndFragmentDelegate", "onDestroyView()");
        j();
        if (this.f292e != null) {
            this.f290c.getViewTreeObserver().removeOnPreDrawListener(this.f292e);
            this.f292e = null;
        }
        s sVar = this.f290c;
        if (sVar != null) {
            sVar.t();
            this.f290c.B(this.f299l);
        }
    }

    /* access modifiers changed from: package-private */
    public void u() {
        io.flutter.embedding.engine.a aVar;
        m.b.f("FlutterActivityAndFragmentDelegate", "onDetach()");
        j();
        this.f288a.s(this.f289b);
        if (this.f288a.l()) {
            m.b.f("FlutterActivityAndFragmentDelegate", "Detaching FlutterEngine from the Activity that owns this Fragment.");
            if (this.f288a.x().isChangingConfigurations()) {
                this.f289b.i().j();
            } else {
                this.f289b.i().i();
            }
        }
        h hVar = this.f291d;
        if (hVar != null) {
            hVar.o();
            this.f291d = null;
        }
        if (this.f288a.o() && (aVar = this.f289b) != null) {
            aVar.l().b();
        }
        if (this.f288a.n()) {
            this.f289b.g();
            if (this.f288a.p() != null) {
                io.flutter.embedding.engine.b.b().d(this.f288a.p());
            }
            this.f289b = null;
        }
        this.f296i = false;
    }

    /* access modifiers changed from: package-private */
    public void v(Intent intent) {
        j();
        if (this.f289b != null) {
            m.b.f("FlutterActivityAndFragmentDelegate", "Forwarding onNewIntent() to FlutterEngine and sending pushRouteInformation message.");
            this.f289b.i().b(intent);
            String o2 = o(intent);
            if (o2 != null && !o2.isEmpty()) {
                this.f289b.o().b(o2);
                return;
            }
            return;
        }
        m.b.g("FlutterActivityAndFragmentDelegate", "onNewIntent() invoked before FlutterFragment was attached to an Activity.");
    }

    /* access modifiers changed from: package-private */
    public void w() {
        io.flutter.embedding.engine.a aVar;
        m.b.f("FlutterActivityAndFragmentDelegate", "onPause()");
        j();
        if (this.f288a.o() && (aVar = this.f289b) != null) {
            aVar.l().c();
        }
    }

    /* access modifiers changed from: package-private */
    public void x() {
        m.b.f("FlutterActivityAndFragmentDelegate", "onPostResume()");
        j();
        if (this.f289b != null) {
            J();
        } else {
            m.b.g("FlutterActivityAndFragmentDelegate", "onPostResume() invoked before FlutterFragment was attached to an Activity.");
        }
    }

    /* access modifiers changed from: package-private */
    public void y(int i2, String[] strArr, int[] iArr) {
        j();
        if (this.f289b != null) {
            m.b.f("FlutterActivityAndFragmentDelegate", "Forwarding onRequestPermissionsResult() to FlutterEngine:\nrequestCode: " + i2 + "\npermissions: " + Arrays.toString(strArr) + "\ngrantResults: " + Arrays.toString(iArr));
            this.f289b.i().d(i2, strArr, iArr);
            return;
        }
        m.b.g("FlutterActivityAndFragmentDelegate", "onRequestPermissionResult() invoked before FlutterFragment was attached to an Activity.");
    }

    /* access modifiers changed from: package-private */
    public void z(Bundle bundle) {
        Bundle bundle2;
        m.b.f("FlutterActivityAndFragmentDelegate", "onRestoreInstanceState. Giving framework and plugins an opportunity to restore state.");
        j();
        byte[] bArr = null;
        if (bundle != null) {
            Bundle bundle3 = bundle.getBundle("plugins");
            bArr = bundle.getByteArray("framework");
            bundle2 = bundle3;
        } else {
            bundle2 = null;
        }
        if (this.f288a.q()) {
            this.f289b.t().j(bArr);
        }
        if (this.f288a.l()) {
            this.f289b.i().c(bundle2);
        }
    }
}
