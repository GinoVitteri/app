package io.flutter.embedding.android;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorSpace;
import android.graphics.Paint;
import android.hardware.HardwareBuffer;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Surface;
import android.view.View;
import java.nio.ByteBuffer;
import java.util.Locale;
import x.d;

@TargetApi(19)
public class k extends View implements d {

    /* renamed from: a  reason: collision with root package name */
    private ImageReader f310a;

    /* renamed from: b  reason: collision with root package name */
    private Image f311b;

    /* renamed from: c  reason: collision with root package name */
    private Bitmap f312c;

    /* renamed from: d  reason: collision with root package name */
    private x.a f313d;

    /* renamed from: e  reason: collision with root package name */
    private b f314e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f315f;

    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f316a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        static {
            /*
                io.flutter.embedding.android.k$b[] r0 = io.flutter.embedding.android.k.b.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f316a = r0
                io.flutter.embedding.android.k$b r1 = io.flutter.embedding.android.k.b.background     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f316a     // Catch:{ NoSuchFieldError -> 0x001d }
                io.flutter.embedding.android.k$b r1 = io.flutter.embedding.android.k.b.overlay     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: io.flutter.embedding.android.k.a.<clinit>():void");
        }
    }

    public enum b {
        background,
        overlay
    }

    public k(Context context, int i2, int i3, b bVar) {
        this(context, g(i2, i3), bVar);
    }

    k(Context context, ImageReader imageReader, b bVar) {
        super(context, (AttributeSet) null);
        this.f315f = false;
        this.f310a = imageReader;
        this.f314e = bVar;
        h();
    }

    private void e() {
        Image image = this.f311b;
        if (image != null) {
            image.close();
            this.f311b = null;
        }
    }

    @SuppressLint({"WrongConstant"})
    @TargetApi(19)
    private static ImageReader g(int i2, int i3) {
        int i4;
        int i5;
        if (i2 <= 0) {
            i("ImageReader width must be greater than 0, but given width=%d, set width=1", Integer.valueOf(i2));
            i4 = 1;
        } else {
            i4 = i2;
        }
        if (i3 <= 0) {
            i("ImageReader height must be greater than 0, but given height=%d, set height=1", Integer.valueOf(i3));
            i5 = 1;
        } else {
            i5 = i3;
        }
        return Build.VERSION.SDK_INT >= 29 ? ImageReader.newInstance(i4, i5, 1, 3, 768) : ImageReader.newInstance(i4, i5, 1, 3);
    }

    private void h() {
        setAlpha(0.0f);
    }

    private static void i(String str, Object... objArr) {
        m.b.g("FlutterImageView", String.format(Locale.US, str, objArr));
    }

    @TargetApi(29)
    private void k() {
        if (Build.VERSION.SDK_INT >= 29) {
            HardwareBuffer a2 = this.f311b.getHardwareBuffer();
            this.f312c = Bitmap.wrapHardwareBuffer(a2, ColorSpace.get(ColorSpace.Named.SRGB));
            a2.close();
            return;
        }
        Image.Plane[] planes = this.f311b.getPlanes();
        if (planes.length == 1) {
            Image.Plane plane = planes[0];
            int rowStride = plane.getRowStride() / plane.getPixelStride();
            int height = this.f311b.getHeight();
            Bitmap bitmap = this.f312c;
            if (!(bitmap != null && bitmap.getWidth() == rowStride && this.f312c.getHeight() == height)) {
                this.f312c = Bitmap.createBitmap(rowStride, height, Bitmap.Config.ARGB_8888);
            }
            ByteBuffer buffer = plane.getBuffer();
            buffer.rewind();
            this.f312c.copyPixelsFromBuffer(buffer);
        }
    }

    public void a() {
    }

    public void b() {
        if (this.f315f) {
            setAlpha(0.0f);
            d();
            this.f312c = null;
            e();
            invalidate();
            this.f315f = false;
        }
    }

    public void c(x.a aVar) {
        if (a.f316a[this.f314e.ordinal()] == 1) {
            aVar.v(this.f310a.getSurface());
        }
        setAlpha(1.0f);
        this.f313d = aVar;
        this.f315f = true;
    }

    @TargetApi(19)
    public boolean d() {
        if (!this.f315f) {
            return false;
        }
        Image acquireLatestImage = this.f310a.acquireLatestImage();
        if (acquireLatestImage != null) {
            e();
            this.f311b = acquireLatestImage;
            invalidate();
        }
        return acquireLatestImage != null;
    }

    public void f() {
        this.f310a.close();
    }

    public x.a getAttachedRenderer() {
        return this.f313d;
    }

    public ImageReader getImageReader() {
        return this.f310a;
    }

    public Surface getSurface() {
        return this.f310a.getSurface();
    }

    public void j(int i2, int i3) {
        if (this.f313d != null) {
            if (i2 != this.f310a.getWidth() || i3 != this.f310a.getHeight()) {
                e();
                f();
                this.f310a = g(i2, i3);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f311b != null) {
            k();
        }
        Bitmap bitmap = this.f312c;
        if (bitmap != null) {
            canvas.drawBitmap(bitmap, 0.0f, 0.0f, (Paint) null);
        }
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        if (!(i2 == this.f310a.getWidth() && i3 == this.f310a.getHeight()) && this.f314e == b.background && this.f315f) {
            j(i2, i3);
            this.f313d.v(this.f310a.getSurface());
        }
    }
}
