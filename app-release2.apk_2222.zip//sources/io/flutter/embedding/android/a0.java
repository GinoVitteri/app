package io.flutter.embedding.android;

import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import io.flutter.plugin.editing.h;
import java.util.HashSet;
import java.util.Map;

public class a0 implements h.a {

    /* renamed from: a  reason: collision with root package name */
    protected final d[] f247a;

    /* renamed from: b  reason: collision with root package name */
    private final HashSet<KeyEvent> f248b = new HashSet<>();

    /* renamed from: c  reason: collision with root package name */
    private final e f249c;

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        private int f250a = 0;

        /* access modifiers changed from: package-private */
        public Character a(int i2) {
            char c2 = (char) i2;
            if ((Integer.MIN_VALUE & i2) != 0) {
                int i3 = i2 & Integer.MAX_VALUE;
                int i4 = this.f250a;
                if (i4 != 0) {
                    i3 = KeyCharacterMap.getDeadChar(i4, i3);
                }
                this.f250a = i3;
            } else {
                int i5 = this.f250a;
                if (i5 != 0) {
                    int deadChar = KeyCharacterMap.getDeadChar(i5, i2);
                    if (deadChar > 0) {
                        c2 = (char) deadChar;
                    }
                    this.f250a = 0;
                }
            }
            return Character.valueOf(c2);
        }
    }

    private class c {

        /* renamed from: a  reason: collision with root package name */
        final KeyEvent f251a;

        /* renamed from: b  reason: collision with root package name */
        int f252b;

        /* renamed from: c  reason: collision with root package name */
        boolean f253c = false;

        private class a implements d.a {

            /* renamed from: a  reason: collision with root package name */
            boolean f255a;

            private a() {
                this.f255a = false;
            }

            public void a(boolean z2) {
                if (!this.f255a) {
                    this.f255a = true;
                    c cVar = c.this;
                    int i2 = cVar.f252b - 1;
                    cVar.f252b = i2;
                    boolean z3 = z2 | cVar.f253c;
                    cVar.f253c = z3;
                    if (i2 == 0 && !z3) {
                        a0.this.e(cVar.f251a);
                        return;
                    }
                    return;
                }
                throw new IllegalStateException("The onKeyEventHandledCallback should be called exactly once.");
            }
        }

        c(KeyEvent keyEvent) {
            this.f252b = a0.this.f247a.length;
            this.f251a = keyEvent;
        }

        public d.a a() {
            return new a();
        }
    }

    public interface d {

        public interface a {
            void a(boolean z2);
        }

        void a(KeyEvent keyEvent, a aVar);
    }

    public interface e {
        void a(KeyEvent keyEvent);

        boolean b(KeyEvent keyEvent);

        z.b getBinaryMessenger();
    }

    public a0(e eVar) {
        this.f249c = eVar;
        this.f247a = new d[]{new z(eVar.getBinaryMessenger()), new u(new y.d(eVar.getBinaryMessenger()))};
    }

    /* access modifiers changed from: private */
    public void e(KeyEvent keyEvent) {
        e eVar = this.f249c;
        if (eVar != null && !eVar.b(keyEvent)) {
            this.f248b.add(keyEvent);
            this.f249c.a(keyEvent);
            if (this.f248b.remove(keyEvent)) {
                m.b.g("KeyboardManager", "A redispatched key event was consumed before reaching KeyboardManager");
            }
        }
    }

    public boolean a(KeyEvent keyEvent) {
        if (this.f248b.remove(keyEvent)) {
            return false;
        }
        if (this.f247a.length > 0) {
            c cVar = new c(keyEvent);
            for (d a2 : this.f247a) {
                a2.a(keyEvent, cVar.a());
            }
            return true;
        }
        e(keyEvent);
        return true;
    }

    public void c() {
        int size = this.f248b.size();
        if (size > 0) {
            m.b.g("KeyboardManager", "A KeyboardManager was destroyed with " + String.valueOf(size) + " unhandled redispatch event(s).");
        }
    }

    public Map<Long, Long> d() {
        return ((z) this.f247a[0]).h();
    }
}
