package io.flutter.embedding.android;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.window.OnBackInvokedCallback;
import androidx.lifecycle.c;
import androidx.lifecycle.g;
import d.b;
import d0.j;
import io.flutter.embedding.android.f;
import io.flutter.embedding.engine.h;
import java.util.List;

public class e extends Activity implements f.c, androidx.lifecycle.f {

    /* renamed from: d  reason: collision with root package name */
    public static final int f283d = j.e(61938);

    /* renamed from: a  reason: collision with root package name */
    protected f f284a;

    /* renamed from: b  reason: collision with root package name */
    private g f285b;

    /* renamed from: c  reason: collision with root package name */
    private final OnBackInvokedCallback f286c;

    class a implements OnBackInvokedCallback {
        a() {
        }

        public void onBackInvoked() {
            e.this.onBackPressed();
        }
    }

    public e() {
        this.f286c = Build.VERSION.SDK_INT >= 33 ? new a() : null;
        this.f285b = new g(this);
    }

    private void E() {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(1073741824);
            window.getDecorView().setSystemUiVisibility(1280);
        }
    }

    private void F() {
        if (H() == g.transparent) {
            getWindow().setBackgroundDrawable(new ColorDrawable(0));
        }
    }

    private View G() {
        return this.f284a.s((LayoutInflater) null, (ViewGroup) null, (Bundle) null, f283d, m() == d0.surface);
    }

    private Drawable K() {
        try {
            Bundle J = J();
            int i2 = J != null ? J.getInt("io.flutter.embedding.android.SplashScreenDrawable") : 0;
            if (i2 != 0) {
                return b.a(getResources(), i2, getTheme());
            }
            return null;
        } catch (Resources.NotFoundException e2) {
            m.b.b("FlutterActivity", "Splash screen not found. Ensure the drawable exists and that it's valid.");
            throw e2;
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    private boolean L() {
        return (getApplicationInfo().flags & 2) != 0;
    }

    private boolean O(String str) {
        StringBuilder sb;
        String str2;
        f fVar = this.f284a;
        if (fVar == null) {
            sb = new StringBuilder();
            sb.append("FlutterActivity ");
            sb.append(hashCode());
            sb.append(" ");
            sb.append(str);
            str2 = " called after release.";
        } else if (fVar.m()) {
            return true;
        } else {
            sb = new StringBuilder();
            sb.append("FlutterActivity ");
            sb.append(hashCode());
            sb.append(" ");
            sb.append(str);
            str2 = " called after detach.";
        }
        sb.append(str2);
        m.b.g("FlutterActivity", sb.toString());
        return false;
    }

    private void P() {
        try {
            Bundle J = J();
            if (J != null) {
                int i2 = J.getInt("io.flutter.embedding.android.NormalTheme", -1);
                if (i2 != -1) {
                    setTheme(i2);
                    return;
                }
                return;
            }
            m.b.f("FlutterActivity", "Using the launch theme as normal theme.");
        } catch (PackageManager.NameNotFoundException unused) {
            m.b.b("FlutterActivity", "Could not read meta-data for FlutterActivity. Using the launch theme as normal theme.");
        }
    }

    public boolean A() {
        try {
            Bundle J = J();
            if (J != null) {
                return J.getBoolean("flutter_deeplinking_enabled");
            }
            return false;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    public g0 B() {
        return H() == g.opaque ? g0.opaque : g0.transparent;
    }

    public void C(m mVar) {
    }

    public void D(io.flutter.embedding.engine.a aVar) {
        if (!this.f284a.n()) {
            w.a.a(aVar);
        }
    }

    /* access modifiers changed from: protected */
    public g H() {
        return getIntent().hasExtra("background_mode") ? g.valueOf(getIntent().getStringExtra("background_mode")) : g.opaque;
    }

    /* access modifiers changed from: protected */
    public io.flutter.embedding.engine.a I() {
        return this.f284a.l();
    }

    /* access modifiers changed from: protected */
    public Bundle J() {
        return getPackageManager().getActivityInfo(getComponentName(), 128).metaData;
    }

    public void M() {
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, this.f286c);
        }
    }

    public void N() {
        Q();
        f fVar = this.f284a;
        if (fVar != null) {
            fVar.H();
            this.f284a = null;
        }
    }

    public void Q() {
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.f286c);
        }
    }

    public boolean a() {
        return false;
    }

    public void b() {
    }

    public void c() {
        m.b.g("FlutterActivity", "FlutterActivity " + this + " connection to the engine " + I() + " evicted by another attaching activity");
        f fVar = this.f284a;
        if (fVar != null) {
            fVar.t();
            this.f284a.u();
        }
    }

    public void d() {
        if (Build.VERSION.SDK_INT >= 29) {
            reportFullyDrawn();
        }
    }

    public c e() {
        return this.f285b;
    }

    public String f() {
        return getIntent().getStringExtra("cached_engine_group_id");
    }

    public String g() {
        if (getIntent().hasExtra("route")) {
            return getIntent().getStringExtra("route");
        }
        try {
            Bundle J = J();
            if (J != null) {
                return J.getString("io.flutter.InitialRoute");
            }
            return null;
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public Context getContext() {
        return this;
    }

    public h h() {
        return h.a(getIntent());
    }

    public List<String> k() {
        return (List) getIntent().getSerializableExtra("dart_entrypoint_args");
    }

    public boolean l() {
        return true;
    }

    public d0 m() {
        return H() == g.opaque ? d0.surface : d0.texture;
    }

    public boolean n() {
        boolean booleanExtra = getIntent().getBooleanExtra("destroy_engine_with_activity", false);
        return (p() != null || this.f284a.n()) ? booleanExtra : getIntent().getBooleanExtra("destroy_engine_with_activity", true);
    }

    public boolean o() {
        return true;
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i2, int i3, Intent intent) {
        if (O("onActivityResult")) {
            this.f284a.p(i2, i3, intent);
        }
    }

    public void onBackPressed() {
        if (O("onBackPressed")) {
            this.f284a.r();
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        P();
        super.onCreate(bundle);
        f fVar = new f(this);
        this.f284a = fVar;
        fVar.q(this);
        this.f284a.z(bundle);
        this.f285b.g(c.a.ON_CREATE);
        M();
        F();
        setContentView(G());
        E();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        if (O("onDestroy")) {
            this.f284a.t();
            this.f284a.u();
        }
        N();
        this.f285b.g(c.a.ON_DESTROY);
    }

    /* access modifiers changed from: protected */
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (O("onNewIntent")) {
            this.f284a.v(intent);
        }
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        if (O("onPause")) {
            this.f284a.w();
        }
        this.f285b.g(c.a.ON_PAUSE);
    }

    public void onPostResume() {
        super.onPostResume();
        if (O("onPostResume")) {
            this.f284a.x();
        }
    }

    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        if (O("onRequestPermissionsResult")) {
            this.f284a.y(i2, strArr, iArr);
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        this.f285b.g(c.a.ON_RESUME);
        if (O("onResume")) {
            this.f284a.A();
        }
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (O("onSaveInstanceState")) {
            this.f284a.B(bundle);
        }
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        this.f285b.g(c.a.ON_START);
        if (O("onStart")) {
            this.f284a.C();
        }
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        if (O("onStop")) {
            this.f284a.D();
        }
        this.f285b.g(c.a.ON_STOP);
    }

    public void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        if (O("onTrimMemory")) {
            this.f284a.E(i2);
        }
    }

    public void onUserLeaveHint() {
        if (O("onUserLeaveHint")) {
            this.f284a.F();
        }
    }

    public void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        if (O("onWindowFocusChanged")) {
            this.f284a.G(z2);
        }
    }

    public String p() {
        return getIntent().getStringExtra("cached_engine_id");
    }

    public boolean q() {
        return getIntent().hasExtra("enable_state_restoration") ? getIntent().getBooleanExtra("enable_state_restoration", false) : p() == null;
    }

    public String r() {
        if (getIntent().hasExtra("dart_entrypoint")) {
            return getIntent().getStringExtra("dart_entrypoint");
        }
        try {
            Bundle J = J();
            String string = J != null ? J.getString("io.flutter.Entrypoint") : null;
            return string != null ? string : "main";
        } catch (PackageManager.NameNotFoundException unused) {
            return "main";
        }
    }

    public void s(io.flutter.embedding.engine.a aVar) {
    }

    public f0 t() {
        Drawable K = K();
        if (K != null) {
            return new b(K);
        }
        return null;
    }

    public String u() {
        try {
            Bundle J = J();
            if (J != null) {
                return J.getString("io.flutter.EntrypointUri");
            }
            return null;
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public io.flutter.plugin.platform.h v(Activity activity, io.flutter.embedding.engine.a aVar) {
        return new io.flutter.plugin.platform.h(x(), aVar.p(), this);
    }

    public void w(l lVar) {
    }

    public Activity x() {
        return this;
    }

    public String y() {
        String dataString;
        if (!L() || !"android.intent.action.RUN".equals(getIntent().getAction()) || (dataString = getIntent().getDataString()) == null) {
            return null;
        }
        return dataString;
    }

    public io.flutter.embedding.engine.a z(Context context) {
        return null;
    }
}
