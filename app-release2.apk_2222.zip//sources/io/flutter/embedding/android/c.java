package io.flutter.embedding.android;

public interface c<T> {
    void c();

    T d();
}
