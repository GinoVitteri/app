package io.flutter.embedding.android;

import android.util.LongSparseArray;
import android.view.MotionEvent;
import java.util.PriorityQueue;
import java.util.concurrent.atomic.AtomicLong;

public final class c0 {

    /* renamed from: c  reason: collision with root package name */
    private static c0 f274c;

    /* renamed from: a  reason: collision with root package name */
    private final LongSparseArray<MotionEvent> f275a = new LongSparseArray<>();

    /* renamed from: b  reason: collision with root package name */
    private final PriorityQueue<Long> f276b = new PriorityQueue<>();

    public static class a {

        /* renamed from: b  reason: collision with root package name */
        private static final AtomicLong f277b = new AtomicLong(0);
        /* access modifiers changed from: private */

        /* renamed from: a  reason: collision with root package name */
        public final long f278a;

        private a(long j2) {
            this.f278a = j2;
        }

        public static a b() {
            return c(f277b.incrementAndGet());
        }

        public static a c(long j2) {
            return new a(j2);
        }

        public long d() {
            return this.f278a;
        }
    }

    private c0() {
    }

    public static c0 a() {
        if (f274c == null) {
            f274c = new c0();
        }
        return f274c;
    }

    public MotionEvent b(a aVar) {
        while (!this.f276b.isEmpty() && this.f276b.peek().longValue() < aVar.f278a) {
            this.f275a.remove(this.f276b.poll().longValue());
        }
        if (!this.f276b.isEmpty() && this.f276b.peek().longValue() == aVar.f278a) {
            this.f276b.poll();
        }
        MotionEvent motionEvent = this.f275a.get(aVar.f278a);
        this.f275a.remove(aVar.f278a);
        return motionEvent;
    }

    public a c(MotionEvent motionEvent) {
        a b2 = a.b();
        this.f275a.put(b2.f278a, MotionEvent.obtain(motionEvent));
        this.f276b.add(Long.valueOf(b2.f278a));
        return b2;
    }
}
