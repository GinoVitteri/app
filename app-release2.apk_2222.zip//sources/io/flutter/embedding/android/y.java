package io.flutter.embedding.android;

import android.view.KeyEvent;
import io.flutter.embedding.android.b0;

public final /* synthetic */ class y implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ z f391d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ b0.c f392e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ KeyEvent f393f;

    public /* synthetic */ y(z zVar, b0.c cVar, KeyEvent keyEvent) {
        this.f391d = zVar;
        this.f392e = cVar;
        this.f393f = keyEvent;
    }

    public final void run() {
        this.f391d.m(this.f392e, this.f393f);
    }
}
