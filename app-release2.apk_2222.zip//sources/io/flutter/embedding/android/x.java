package io.flutter.embedding.android;

import android.view.KeyEvent;
import io.flutter.embedding.android.b0;

public final /* synthetic */ class x implements Runnable {

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ z f387d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ b0.c f388e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ long f389f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ KeyEvent f390g;

    public /* synthetic */ x(z zVar, b0.c cVar, long j2, KeyEvent keyEvent) {
        this.f387d = zVar;
        this.f388e = cVar;
        this.f389f = j2;
        this.f390g = keyEvent;
    }

    public final void run() {
        this.f387d.l(this.f388e, this.f389f, this.f390g);
    }
}
