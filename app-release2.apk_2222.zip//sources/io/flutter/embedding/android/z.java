package io.flutter.embedding.android;

import android.view.KeyEvent;
import io.flutter.embedding.android.a0;
import io.flutter.embedding.android.b0;
import io.flutter.embedding.android.v;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import z.b;

public class z implements a0.d {

    /* renamed from: a  reason: collision with root package name */
    private final b f394a;

    /* renamed from: b  reason: collision with root package name */
    private final HashMap<Long, Long> f395b = new HashMap<>();

    /* renamed from: c  reason: collision with root package name */
    private final HashMap<Long, b0.e> f396c = new HashMap<>();

    /* renamed from: d  reason: collision with root package name */
    private final a0.b f397d = new a0.b();

    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f398a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|(3:5|6|8)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        static {
            /*
                io.flutter.embedding.android.v$a[] r0 = io.flutter.embedding.android.v.a.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f398a = r0
                io.flutter.embedding.android.v$a r1 = io.flutter.embedding.android.v.a.kDown     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f398a     // Catch:{ NoSuchFieldError -> 0x001d }
                io.flutter.embedding.android.v$a r1 = io.flutter.embedding.android.v.a.kUp     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f398a     // Catch:{ NoSuchFieldError -> 0x0028 }
                io.flutter.embedding.android.v$a r1 = io.flutter.embedding.android.v.a.kRepeat     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: io.flutter.embedding.android.z.a.<clinit>():void");
        }
    }

    public z(b bVar) {
        this.f394a = bVar;
        for (b0.e eVar : b0.a()) {
            this.f396c.put(Long.valueOf(eVar.f272c), eVar);
        }
    }

    private static v.a e(KeyEvent keyEvent) {
        boolean z2 = keyEvent.getRepeatCount() > 0;
        int action = keyEvent.getAction();
        if (action == 0) {
            return z2 ? v.a.kRepeat : v.a.kDown;
        }
        if (action == 1) {
            return v.a.kUp;
        }
        throw new AssertionError("Unexpected event type");
    }

    private Long f(KeyEvent keyEvent) {
        Long l2 = b0.f264b.get(Long.valueOf((long) keyEvent.getKeyCode()));
        return l2 != null ? l2 : Long.valueOf(j((long) keyEvent.getKeyCode(), 73014444032L));
    }

    private Long g(KeyEvent keyEvent) {
        int scanCode;
        long scanCode2 = (long) keyEvent.getScanCode();
        if (scanCode2 == 0) {
            scanCode = keyEvent.getKeyCode();
        } else {
            Long l2 = b0.f263a.get(Long.valueOf(scanCode2));
            if (l2 != null) {
                return l2;
            }
            scanCode = keyEvent.getScanCode();
        }
        return Long.valueOf(j((long) scanCode, 73014444032L));
    }

    /* JADX WARNING: Removed duplicated region for block: B:37:0x00b8  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00d4  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0119 A[LOOP:2: B:53:0x0113->B:55:0x0119, LOOP_END] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean i(android.view.KeyEvent r18, io.flutter.embedding.android.a0.d.a r19) {
        /*
            r17 = this;
            r9 = r17
            int r0 = r18.getScanCode()
            r10 = 0
            if (r0 != 0) goto L_0x0010
            int r0 = r18.getKeyCode()
            if (r0 != 0) goto L_0x0010
            return r10
        L_0x0010:
            java.lang.Long r11 = r17.g(r18)
            java.lang.Long r12 = r17.f(r18)
            java.util.ArrayList r13 = new java.util.ArrayList
            r13.<init>()
            io.flutter.embedding.android.b0$d[] r14 = io.flutter.embedding.android.b0.f265c
            int r15 = r14.length
            r8 = 0
        L_0x0021:
            r6 = 1
            if (r8 >= r15) goto L_0x0047
            r1 = r14[r8]
            int r0 = r18.getMetaState()
            int r2 = r1.f268a
            r0 = r0 & r2
            if (r0 == 0) goto L_0x0031
            r2 = 1
            goto L_0x0032
        L_0x0031:
            r2 = 0
        L_0x0032:
            long r3 = r12.longValue()
            long r5 = r11.longValue()
            r0 = r17
            r7 = r18
            r16 = r8
            r8 = r13
            r0.o(r1, r2, r3, r5, r7, r8)
            int r8 = r16 + 1
            goto L_0x0021
        L_0x0047:
            java.util.HashMap<java.lang.Long, io.flutter.embedding.android.b0$e> r0 = r9.f396c
            java.util.Collection r0 = r0.values()
            java.util.Iterator r7 = r0.iterator()
        L_0x0051:
            boolean r0 = r7.hasNext()
            if (r0 == 0) goto L_0x0076
            java.lang.Object r0 = r7.next()
            r1 = r0
            io.flutter.embedding.android.b0$e r1 = (io.flutter.embedding.android.b0.e) r1
            int r0 = r18.getMetaState()
            int r2 = r1.f270a
            r0 = r0 & r2
            if (r0 == 0) goto L_0x0069
            r2 = 1
            goto L_0x006a
        L_0x0069:
            r2 = 0
        L_0x006a:
            long r3 = r12.longValue()
            r0 = r17
            r5 = r18
            r0.p(r1, r2, r3, r5)
            goto L_0x0051
        L_0x0076:
            int r0 = r18.getAction()
            if (r0 == 0) goto L_0x0081
            if (r0 == r6) goto L_0x007f
            return r10
        L_0x007f:
            r7 = 0
            goto L_0x0082
        L_0x0081:
            r7 = 1
        L_0x0082:
            java.util.HashMap<java.lang.Long, java.lang.Long> r0 = r9.f395b
            java.lang.Object r0 = r0.get(r11)
            r2 = r0
            java.lang.Long r2 = (java.lang.Long) r2
            r8 = 0
            if (r7 == 0) goto L_0x00ca
            if (r2 != 0) goto L_0x0093
        L_0x0090:
            io.flutter.embedding.android.v$a r0 = io.flutter.embedding.android.v.a.kDown
            goto L_0x00a8
        L_0x0093:
            int r0 = r18.getRepeatCount()
            if (r0 <= 0) goto L_0x009c
            io.flutter.embedding.android.v$a r0 = io.flutter.embedding.android.v.a.kRepeat
            goto L_0x00a8
        L_0x009c:
            r1 = 0
            long r4 = r18.getEventTime()
            r0 = r17
            r3 = r11
            r0.q(r1, r2, r3, r4)
            goto L_0x0090
        L_0x00a8:
            io.flutter.embedding.android.a0$b r1 = r9.f397d
            int r2 = r18.getUnicodeChar()
            java.lang.Character r1 = r1.a(r2)
            char r1 = r1.charValue()
            if (r1 == 0) goto L_0x00cf
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = ""
            r2.append(r3)
            r2.append(r1)
            java.lang.String r1 = r2.toString()
            goto L_0x00d0
        L_0x00ca:
            if (r2 != 0) goto L_0x00cd
            return r10
        L_0x00cd:
            io.flutter.embedding.android.v$a r0 = io.flutter.embedding.android.v.a.kUp
        L_0x00cf:
            r1 = r8
        L_0x00d0:
            io.flutter.embedding.android.v$a r2 = io.flutter.embedding.android.v.a.kRepeat
            if (r0 == r2) goto L_0x00da
            if (r7 == 0) goto L_0x00d7
            r8 = r12
        L_0x00d7:
            r9.r(r11, r8)
        L_0x00da:
            io.flutter.embedding.android.v$a r2 = io.flutter.embedding.android.v.a.kDown
            if (r0 != r2) goto L_0x00ed
            java.util.HashMap<java.lang.Long, io.flutter.embedding.android.b0$e> r2 = r9.f396c
            java.lang.Object r2 = r2.get(r12)
            io.flutter.embedding.android.b0$e r2 = (io.flutter.embedding.android.b0.e) r2
            if (r2 == 0) goto L_0x00ed
            boolean r3 = r2.f273d
            r3 = r3 ^ r6
            r2.f273d = r3
        L_0x00ed:
            io.flutter.embedding.android.v r2 = new io.flutter.embedding.android.v
            r2.<init>()
            long r3 = r18.getEventTime()
            r2.f375a = r3
            r2.f376b = r0
            long r3 = r12.longValue()
            r2.f378d = r3
            long r3 = r11.longValue()
            r2.f377c = r3
            r2.f380f = r1
            r2.f379e = r10
            r0 = r19
            r9.n(r2, r0)
            java.util.Iterator r0 = r13.iterator()
        L_0x0113:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0123
            java.lang.Object r1 = r0.next()
            java.lang.Runnable r1 = (java.lang.Runnable) r1
            r1.run()
            goto L_0x0113
        L_0x0123:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: io.flutter.embedding.android.z.i(android.view.KeyEvent, io.flutter.embedding.android.a0$d$a):boolean");
    }

    private static long j(long j2, long j3) {
        return (j2 & 4294967295L) | j3;
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void k(a0.d.a aVar, ByteBuffer byteBuffer) {
        Boolean bool = Boolean.FALSE;
        byteBuffer.rewind();
        if (byteBuffer.capacity() != 0) {
            bool = Boolean.valueOf(byteBuffer.get() != 0);
        }
        aVar.a(bool.booleanValue());
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void l(b0.c cVar, long j2, KeyEvent keyEvent) {
        q(false, Long.valueOf(cVar.f267b), Long.valueOf(j2), keyEvent.getEventTime());
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void m(b0.c cVar, KeyEvent keyEvent) {
        q(false, Long.valueOf(cVar.f267b), Long.valueOf(cVar.f266a), keyEvent.getEventTime());
    }

    private void n(v vVar, a0.d.a aVar) {
        this.f394a.b("flutter/keydata", vVar.a(), aVar == null ? null : new w(aVar));
    }

    private void q(boolean z2, Long l2, Long l3, long j2) {
        v vVar = new v();
        vVar.f375a = j2;
        vVar.f376b = z2 ? v.a.kDown : v.a.kUp;
        vVar.f378d = l2.longValue();
        vVar.f377c = l3.longValue();
        vVar.f380f = null;
        vVar.f379e = true;
        if (!(l3.longValue() == 0 || l2.longValue() == 0)) {
            if (!z2) {
                l2 = null;
            }
            r(l3, l2);
        }
        n(vVar, (a0.d.a) null);
    }

    public void a(KeyEvent keyEvent, a0.d.a aVar) {
        if (!i(keyEvent, aVar)) {
            q(true, (Long) null, 0L, 0);
            aVar.a(true);
        }
    }

    public Map<Long, Long> h() {
        return Collections.unmodifiableMap(this.f395b);
    }

    /* access modifiers changed from: package-private */
    public void o(b0.d dVar, boolean z2, long j2, long j3, KeyEvent keyEvent, ArrayList<Runnable> arrayList) {
        b0.d dVar2 = dVar;
        ArrayList<Runnable> arrayList2 = arrayList;
        b0.c[] cVarArr = dVar2.f269b;
        boolean[] zArr = new boolean[cVarArr.length];
        Boolean[] boolArr = new Boolean[cVarArr.length];
        boolean z3 = false;
        int i2 = 0;
        while (true) {
            b0.c[] cVarArr2 = dVar2.f269b;
            boolean z4 = true;
            if (i2 >= cVarArr2.length) {
                break;
            }
            b0.c cVar = cVarArr2[i2];
            boolean containsKey = this.f395b.containsKey(Long.valueOf(cVar.f266a));
            zArr[i2] = containsKey;
            if (cVar.f267b == j2) {
                int i3 = a.f398a[e(keyEvent).ordinal()];
                if (i3 == 1) {
                    KeyEvent keyEvent2 = keyEvent;
                    boolArr[i2] = Boolean.FALSE;
                    if (!z2) {
                        arrayList2.add(new x(this, cVar, j3, keyEvent));
                    }
                } else if (i3 == 2) {
                    KeyEvent keyEvent3 = keyEvent;
                    boolArr[i2] = Boolean.valueOf(zArr[i2]);
                } else if (i3 != 3) {
                    KeyEvent keyEvent4 = keyEvent;
                } else {
                    if (!z2) {
                        arrayList2.add(new y(this, cVar, keyEvent));
                    } else {
                        KeyEvent keyEvent5 = keyEvent;
                    }
                    boolArr[i2] = Boolean.valueOf(zArr[i2]);
                }
                z3 = true;
            } else {
                KeyEvent keyEvent6 = keyEvent;
                if (!z3 && !containsKey) {
                    z4 = false;
                }
                z3 = z4;
            }
            i2++;
        }
        KeyEvent keyEvent7 = keyEvent;
        if (z2) {
            for (int i4 = 0; i4 < dVar2.f269b.length; i4++) {
                if (boolArr[i4] == null) {
                    if (z3) {
                        boolArr[i4] = Boolean.valueOf(zArr[i4]);
                    } else {
                        boolArr[i4] = Boolean.TRUE;
                        z3 = true;
                    }
                }
            }
            if (!z3) {
                boolArr[0] = Boolean.TRUE;
            }
        } else {
            for (int i5 = 0; i5 < dVar2.f269b.length; i5++) {
                if (boolArr[i5] == null) {
                    boolArr[i5] = Boolean.FALSE;
                }
            }
        }
        for (int i6 = 0; i6 < dVar2.f269b.length; i6++) {
            if (zArr[i6] != boolArr[i6].booleanValue()) {
                b0.c cVar2 = dVar2.f269b[i6];
                q(boolArr[i6].booleanValue(), Long.valueOf(cVar2.f267b), Long.valueOf(cVar2.f266a), keyEvent.getEventTime());
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void p(b0.e eVar, boolean z2, long j2, KeyEvent keyEvent) {
        if (eVar.f272c != j2 && eVar.f273d != z2) {
            boolean z3 = !this.f395b.containsKey(Long.valueOf(eVar.f271b));
            if (z3) {
                eVar.f273d = !eVar.f273d;
            }
            q(z3, Long.valueOf(eVar.f272c), Long.valueOf(eVar.f271b), keyEvent.getEventTime());
            if (!z3) {
                eVar.f273d = !eVar.f273d;
            }
            q(!z3, Long.valueOf(eVar.f272c), Long.valueOf(eVar.f271b), keyEvent.getEventTime());
        }
    }

    /* access modifiers changed from: package-private */
    public void r(Long l2, Long l3) {
        if (l3 != null) {
            if (this.f395b.put(l2, l3) != null) {
                throw new AssertionError("The key was not empty");
            }
        } else if (this.f395b.remove(l2) == null) {
            throw new AssertionError("The key was empty");
        }
    }
}
