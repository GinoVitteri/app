package io.flutter.embedding.android;

import io.flutter.embedding.android.a0;
import y.d;

public final /* synthetic */ class t implements d.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a0.d.a f372a;

    public /* synthetic */ t(a0.d.a aVar) {
        this.f372a = aVar;
    }

    public final void a(boolean z2) {
        this.f372a.a(z2);
    }
}
