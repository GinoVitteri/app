package io.flutter.embedding.android;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import androidx.annotation.Keep;
import io.flutter.embedding.android.s;

final class FlutterSplashView extends FrameLayout {

    /* renamed from: j  reason: collision with root package name */
    private static String f229j = "FlutterSplashView";
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public f0 f230a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public s f231b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public View f232c;

    /* renamed from: d  reason: collision with root package name */
    Bundle f233d;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public String f234e;
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public String f235f;

    /* renamed from: g  reason: collision with root package name */
    private final s.f f236g;

    /* renamed from: h  reason: collision with root package name */
    private final x.c f237h;

    /* renamed from: i  reason: collision with root package name */
    private final Runnable f238i;

    @Keep
    public static class SavedState extends View.BaseSavedState {
        public static Parcelable.Creator<SavedState> CREATOR = new a();
        /* access modifiers changed from: private */
        public String previousCompletedSplashIsolate;
        /* access modifiers changed from: private */
        public Bundle splashScreenState;

        class a implements Parcelable.Creator<SavedState> {
            a() {
            }

            /* renamed from: a */
            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            /* renamed from: b */
            public SavedState[] newArray(int i2) {
                return new SavedState[i2];
            }
        }

        SavedState(Parcel parcel) {
            super(parcel);
            this.previousCompletedSplashIsolate = parcel.readString();
            this.splashScreenState = parcel.readBundle(getClass().getClassLoader());
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeString(this.previousCompletedSplashIsolate);
            parcel.writeBundle(this.splashScreenState);
        }
    }

    class a implements s.f {
        a() {
        }

        public void a(io.flutter.embedding.engine.a aVar) {
            FlutterSplashView.this.f231b.A(this);
            FlutterSplashView flutterSplashView = FlutterSplashView.this;
            flutterSplashView.g(flutterSplashView.f231b, FlutterSplashView.this.f230a);
        }

        public void b() {
        }
    }

    class b implements x.c {
        b() {
        }

        public void b() {
        }

        public void d() {
            if (FlutterSplashView.this.f230a != null) {
                FlutterSplashView.this.k();
            }
        }
    }

    class c implements Runnable {
        c() {
        }

        public void run() {
            FlutterSplashView flutterSplashView = FlutterSplashView.this;
            flutterSplashView.removeView(flutterSplashView.f232c);
            FlutterSplashView flutterSplashView2 = FlutterSplashView.this;
            String unused = flutterSplashView2.f235f = flutterSplashView2.f234e;
        }
    }

    public FlutterSplashView(Context context) {
        this(context, (AttributeSet) null, 0);
    }

    public FlutterSplashView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f236g = new a();
        this.f237h = new b();
        this.f238i = new c();
        setSaveEnabled(true);
    }

    private boolean h() {
        s sVar = this.f231b;
        if (sVar == null) {
            throw new IllegalStateException("Cannot determine if splash has completed when no FlutterView is set.");
        } else if (sVar.x()) {
            return this.f231b.getAttachedFlutterEngine().j().h() != null && this.f231b.getAttachedFlutterEngine().j().h().equals(this.f235f);
        } else {
            throw new IllegalStateException("Cannot determine if splash has completed when no FlutterEngine is attached to our FlutterView. This question depends on an isolate ID to differentiate Flutter experiences.");
        }
    }

    private boolean i() {
        s sVar = this.f231b;
        return sVar != null && sVar.x() && !this.f231b.v() && !h();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:4:0x000a, code lost:
        r0 = r1.f230a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean j() {
        /*
            r1 = this;
            io.flutter.embedding.android.s r0 = r1.f231b
            if (r0 == 0) goto L_0x001c
            boolean r0 = r0.x()
            if (r0 == 0) goto L_0x001c
            io.flutter.embedding.android.f0 r0 = r1.f230a
            if (r0 == 0) goto L_0x001c
            boolean r0 = r0.b()
            if (r0 == 0) goto L_0x001c
            boolean r0 = r1.l()
            if (r0 == 0) goto L_0x001c
            r0 = 1
            goto L_0x001d
        L_0x001c:
            r0 = 0
        L_0x001d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: io.flutter.embedding.android.FlutterSplashView.j():boolean");
    }

    /* access modifiers changed from: private */
    public void k() {
        this.f234e = this.f231b.getAttachedFlutterEngine().j().h();
        String str = f229j;
        m.b.f(str, "Transitioning splash screen to a Flutter UI. Isolate: " + this.f234e);
        this.f230a.a(this.f238i);
    }

    private boolean l() {
        s sVar = this.f231b;
        if (sVar == null) {
            throw new IllegalStateException("Cannot determine if previous splash transition was interrupted when no FlutterView is set.");
        } else if (sVar.x()) {
            return this.f231b.v() && !h();
        } else {
            throw new IllegalStateException("Cannot determine if previous splash transition was interrupted when no FlutterEngine is attached to our FlutterView. This question depends on an isolate ID to differentiate Flutter experiences.");
        }
    }

    public void g(s sVar, f0 f0Var) {
        s sVar2 = this.f231b;
        if (sVar2 != null) {
            sVar2.B(this.f237h);
            removeView(this.f231b);
        }
        View view = this.f232c;
        if (view != null) {
            removeView(view);
        }
        this.f231b = sVar;
        addView(sVar);
        this.f230a = f0Var;
        if (f0Var == null) {
            return;
        }
        if (i()) {
            m.b.f(f229j, "Showing splash screen UI.");
            View c2 = f0Var.c(getContext(), this.f233d);
            this.f232c = c2;
            addView(c2);
            sVar.m(this.f237h);
        } else if (j()) {
            m.b.f(f229j, "Showing an immediate splash transition to Flutter due to previously interrupted transition.");
            View c3 = f0Var.c(getContext(), this.f233d);
            this.f232c = c3;
            addView(c3);
            k();
        } else if (!sVar.x()) {
            m.b.f(f229j, "FlutterView is not yet attached to a FlutterEngine. Showing nothing until a FlutterEngine is attached.");
            sVar.l(this.f236g);
        }
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.f235f = savedState.previousCompletedSplashIsolate;
        this.f233d = savedState.splashScreenState;
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        String unused = savedState.previousCompletedSplashIsolate = this.f235f;
        f0 f0Var = this.f230a;
        Bundle unused2 = savedState.splashScreenState = f0Var != null ? f0Var.d() : null;
        return savedState;
    }
}
