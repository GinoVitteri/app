package io.flutter.embedding.android;

import android.app.Activity;
import androidx.window.java.layout.WindowInfoTrackerCallbackAdapter;
import androidx.window.layout.WindowLayoutInfo;
import h.a;
import java.util.concurrent.Executor;

public class h0 {

    /* renamed from: a  reason: collision with root package name */
    final WindowInfoTrackerCallbackAdapter f309a;

    public h0(WindowInfoTrackerCallbackAdapter windowInfoTrackerCallbackAdapter) {
        this.f309a = windowInfoTrackerCallbackAdapter;
    }

    public void a(Activity activity, Executor executor, a<WindowLayoutInfo> aVar) {
        this.f309a.addWindowLayoutInfoListener(activity, executor, aVar);
    }

    public void b(a<WindowLayoutInfo> aVar) {
        this.f309a.removeWindowLayoutInfoListener(aVar);
    }
}
