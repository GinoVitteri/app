package io.flutter.view;

import d0.f;
import io.flutter.view.j;

public final /* synthetic */ class i implements f {
    public final boolean test(Object obj) {
        return ((j.l) obj).v0(j.i.HAS_IMPLICIT_SCROLLING);
    }
}
