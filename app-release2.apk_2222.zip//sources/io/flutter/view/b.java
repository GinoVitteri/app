package io.flutter.view;

public final /* synthetic */ class b {
}
