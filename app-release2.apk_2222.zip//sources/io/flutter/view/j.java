package io.flutter.view;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ContentResolver;
import android.database.ContentObserver;
import android.graphics.Rect;
import android.net.Uri;
import android.opengl.Matrix;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.LocaleSpan;
import android.text.style.TtsSpan$Builder;
import android.view.MotionEvent;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import io.flutter.plugin.platform.q;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import y.a;

public class j extends AccessibilityNodeProvider {
    /* access modifiers changed from: private */
    public static final int A = (((((((((((i.HAS_CHECKED_STATE.f752d | i.IS_CHECKED.f752d) | i.IS_SELECTED.f752d) | i.IS_TEXT_FIELD.f752d) | i.IS_FOCUSED.f752d) | i.HAS_ENABLED_STATE.f752d) | i.IS_ENABLED.f752d) | i.IS_IN_MUTUALLY_EXCLUSIVE_GROUP.f752d) | i.HAS_TOGGLED_STATE.f752d) | i.IS_TOGGLED.f752d) | i.IS_FOCUSABLE.f752d) | i.IS_SLIDER.f752d);
    private static int B = 267386881;
    /* access modifiers changed from: private */

    /* renamed from: z  reason: collision with root package name */
    public static final int f661z = (((g.SCROLL_RIGHT.f724d | g.SCROLL_LEFT.f724d) | g.SCROLL_UP.f724d) | g.SCROLL_DOWN.f724d);
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final View f662a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final y.a f663b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public final AccessibilityManager f664c;

    /* renamed from: d  reason: collision with root package name */
    private final AccessibilityViewEmbedder f665d;

    /* renamed from: e  reason: collision with root package name */
    private final q f666e;
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public final ContentResolver f667f;

    /* renamed from: g  reason: collision with root package name */
    private final Map<Integer, l> f668g;

    /* renamed from: h  reason: collision with root package name */
    private final Map<Integer, h> f669h;

    /* renamed from: i  reason: collision with root package name */
    private l f670i;

    /* renamed from: j  reason: collision with root package name */
    private Integer f671j;

    /* renamed from: k  reason: collision with root package name */
    private Integer f672k;

    /* renamed from: l  reason: collision with root package name */
    private int f673l;

    /* renamed from: m  reason: collision with root package name */
    private l f674m;

    /* renamed from: n  reason: collision with root package name */
    private l f675n;

    /* renamed from: o  reason: collision with root package name */
    private l f676o;

    /* renamed from: p  reason: collision with root package name */
    private final List<Integer> f677p;

    /* renamed from: q  reason: collision with root package name */
    private int f678q;

    /* renamed from: r  reason: collision with root package name */
    private Integer f679r;
    /* access modifiers changed from: private */

    /* renamed from: s  reason: collision with root package name */
    public k f680s;

    /* renamed from: t  reason: collision with root package name */
    private boolean f681t;
    /* access modifiers changed from: private */

    /* renamed from: u  reason: collision with root package name */
    public boolean f682u;
    /* access modifiers changed from: private */

    /* renamed from: v  reason: collision with root package name */
    public final a.b f683v;

    /* renamed from: w  reason: collision with root package name */
    private final AccessibilityManager.AccessibilityStateChangeListener f684w;
    @TargetApi(19)

    /* renamed from: x  reason: collision with root package name */
    private final AccessibilityManager.TouchExplorationStateChangeListener f685x;

    /* renamed from: y  reason: collision with root package name */
    private final ContentObserver f686y;

    class a implements a.b {
        a() {
        }

        public void a(ByteBuffer byteBuffer, String[] strArr, ByteBuffer[] byteBufferArr) {
            byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
            for (ByteBuffer order : byteBufferArr) {
                order.order(ByteOrder.LITTLE_ENDIAN);
            }
            j.this.b0(byteBuffer, strArr, byteBufferArr);
        }

        public void b(ByteBuffer byteBuffer, String[] strArr) {
            byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
            j.this.a0(byteBuffer, strArr);
        }

        public void c(String str) {
            if (Build.VERSION.SDK_INT < 28) {
                AccessibilityEvent k2 = j.this.H(0, 32);
                k2.getText().add(str);
                j.this.S(k2);
            }
        }

        public void d(int i2) {
            j.this.R(i2, 2);
        }

        public void e(String str) {
            j.this.f662a.announceForAccessibility(str);
        }

        public void f(int i2) {
            j.this.R(i2, 1);
        }
    }

    class b implements AccessibilityManager.AccessibilityStateChangeListener {
        b() {
        }

        public void onAccessibilityStateChanged(boolean z2) {
            if (!j.this.f682u) {
                j jVar = j.this;
                if (z2) {
                    jVar.f663b.g(j.this.f683v);
                    j.this.f663b.e();
                } else {
                    jVar.W(false);
                    j.this.f663b.g((a.b) null);
                    j.this.f663b.d();
                }
                if (j.this.f680s != null) {
                    j.this.f680s.a(z2, j.this.f664c.isTouchExplorationEnabled());
                }
            }
        }
    }

    class c extends ContentObserver {
        c(Handler handler) {
            super(handler);
        }

        public void onChange(boolean z2) {
            onChange(z2, (Uri) null);
        }

        public void onChange(boolean z2, Uri uri) {
            if (!j.this.f682u) {
                String string = Settings.Global.getString(j.this.f667f, "transition_animation_scale");
                if (string != null && string.equals("0")) {
                    j.g(j.this, f.DISABLE_ANIMATIONS.f701d);
                } else {
                    j.f(j.this, f.DISABLE_ANIMATIONS.f701d ^ -1);
                }
                j.this.T();
            }
        }
    }

    class d implements AccessibilityManager.TouchExplorationStateChangeListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ AccessibilityManager f690a;

        d(AccessibilityManager accessibilityManager) {
            this.f690a = accessibilityManager;
        }

        public void onTouchExplorationStateChanged(boolean z2) {
            if (!j.this.f682u) {
                if (!z2) {
                    j.this.W(false);
                    j.this.L();
                }
                if (j.this.f680s != null) {
                    j.this.f680s.a(this.f690a.isEnabled(), z2);
                }
            }
        }
    }

    static /* synthetic */ class e {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f692a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        static {
            /*
                io.flutter.view.j$o[] r0 = io.flutter.view.j.o.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f692a = r0
                io.flutter.view.j$o r1 = io.flutter.view.j.o.SPELLOUT     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f692a     // Catch:{ NoSuchFieldError -> 0x001d }
                io.flutter.view.j$o r1 = io.flutter.view.j.o.LOCALE     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: io.flutter.view.j.e.<clinit>():void");
        }
    }

    private enum f {
        ACCESSIBLE_NAVIGATION(1),
        INVERT_COLORS(2),
        DISABLE_ANIMATIONS(4),
        BOLD_TEXT(8),
        REDUCE_MOTION(16),
        HIGH_CONTRAST(32),
        ON_OFF_SWITCH_LABELS(64);
        

        /* renamed from: d  reason: collision with root package name */
        final int f701d;

        private f(int i2) {
            this.f701d = i2;
        }
    }

    public enum g {
        TAP(1),
        LONG_PRESS(2),
        SCROLL_LEFT(4),
        SCROLL_RIGHT(8),
        SCROLL_UP(16),
        SCROLL_DOWN(32),
        INCREASE(64),
        DECREASE(128),
        SHOW_ON_SCREEN(256),
        MOVE_CURSOR_FORWARD_BY_CHARACTER(512),
        MOVE_CURSOR_BACKWARD_BY_CHARACTER(1024),
        SET_SELECTION(2048),
        COPY(4096),
        CUT(8192),
        PASTE(16384),
        DID_GAIN_ACCESSIBILITY_FOCUS(32768),
        DID_LOSE_ACCESSIBILITY_FOCUS(65536),
        CUSTOM_ACTION(131072),
        DISMISS(262144),
        MOVE_CURSOR_FORWARD_BY_WORD(524288),
        MOVE_CURSOR_BACKWARD_BY_WORD(1048576),
        SET_TEXT(2097152);
        

        /* renamed from: d  reason: collision with root package name */
        public final int f724d;

        private g(int i2) {
            this.f724d = i2;
        }
    }

    private static class h {
        /* access modifiers changed from: private */

        /* renamed from: a  reason: collision with root package name */
        public int f725a = -1;
        /* access modifiers changed from: private */

        /* renamed from: b  reason: collision with root package name */
        public int f726b = -1;
        /* access modifiers changed from: private */

        /* renamed from: c  reason: collision with root package name */
        public int f727c = -1;
        /* access modifiers changed from: private */

        /* renamed from: d  reason: collision with root package name */
        public String f728d;
        /* access modifiers changed from: private */

        /* renamed from: e  reason: collision with root package name */
        public String f729e;

        h() {
        }
    }

    enum i {
        HAS_CHECKED_STATE(1),
        IS_CHECKED(2),
        IS_SELECTED(4),
        IS_BUTTON(8),
        IS_TEXT_FIELD(16),
        IS_FOCUSED(32),
        HAS_ENABLED_STATE(64),
        IS_ENABLED(128),
        IS_IN_MUTUALLY_EXCLUSIVE_GROUP(256),
        IS_HEADER(512),
        IS_OBSCURED(1024),
        SCOPES_ROUTE(2048),
        NAMES_ROUTE(4096),
        IS_HIDDEN(8192),
        IS_IMAGE(16384),
        IS_LIVE_REGION(32768),
        HAS_TOGGLED_STATE(65536),
        IS_TOGGLED(131072),
        HAS_IMPLICIT_SCROLLING(262144),
        IS_MULTILINE(524288),
        IS_READ_ONLY(1048576),
        IS_FOCUSABLE(2097152),
        IS_LINK(4194304),
        IS_SLIDER(8388608),
        IS_KEYBOARD_KEY(16777216),
        IS_CHECK_STATE_MIXED(33554432);
        

        /* renamed from: d  reason: collision with root package name */
        final int f752d;

        private i(int i2) {
            this.f752d = i2;
        }
    }

    /* renamed from: io.flutter.view.j$j  reason: collision with other inner class name */
    private static class C0012j extends n {

        /* renamed from: d  reason: collision with root package name */
        String f753d;

        private C0012j() {
            super((a) null);
        }

        /* synthetic */ C0012j(a aVar) {
            this();
        }
    }

    public interface k {
        void a(boolean z2, boolean z3);
    }

    private static class l {
        private p A;
        /* access modifiers changed from: private */
        public boolean B = false;
        private int C;
        private int D;
        /* access modifiers changed from: private */
        public int E;
        /* access modifiers changed from: private */
        public int F;
        private float G;
        private float H;
        private float I;
        /* access modifiers changed from: private */
        public String J;
        private String K;
        private float L;
        private float M;
        private float N;
        private float O;
        private float[] P;
        /* access modifiers changed from: private */
        public l Q;
        /* access modifiers changed from: private */
        public List<l> R = new ArrayList();
        /* access modifiers changed from: private */
        public List<l> S = new ArrayList();
        /* access modifiers changed from: private */
        public List<h> T;
        /* access modifiers changed from: private */
        public h U;
        /* access modifiers changed from: private */
        public h V;
        /* access modifiers changed from: private */
        public boolean W = true;
        private float[] X;
        /* access modifiers changed from: private */
        public boolean Y = true;
        private float[] Z;

        /* renamed from: a  reason: collision with root package name */
        final j f754a;

        /* renamed from: a0  reason: collision with root package name */
        private Rect f755a0;
        /* access modifiers changed from: private */

        /* renamed from: b  reason: collision with root package name */
        public int f756b = -1;

        /* renamed from: c  reason: collision with root package name */
        private int f757c;

        /* renamed from: d  reason: collision with root package name */
        private int f758d;
        /* access modifiers changed from: private */

        /* renamed from: e  reason: collision with root package name */
        public int f759e;
        /* access modifiers changed from: private */

        /* renamed from: f  reason: collision with root package name */
        public int f760f;
        /* access modifiers changed from: private */

        /* renamed from: g  reason: collision with root package name */
        public int f761g;
        /* access modifiers changed from: private */

        /* renamed from: h  reason: collision with root package name */
        public int f762h;
        /* access modifiers changed from: private */

        /* renamed from: i  reason: collision with root package name */
        public int f763i;
        /* access modifiers changed from: private */

        /* renamed from: j  reason: collision with root package name */
        public int f764j;
        /* access modifiers changed from: private */

        /* renamed from: k  reason: collision with root package name */
        public int f765k;
        /* access modifiers changed from: private */

        /* renamed from: l  reason: collision with root package name */
        public float f766l;
        /* access modifiers changed from: private */

        /* renamed from: m  reason: collision with root package name */
        public float f767m;
        /* access modifiers changed from: private */

        /* renamed from: n  reason: collision with root package name */
        public float f768n;
        /* access modifiers changed from: private */

        /* renamed from: o  reason: collision with root package name */
        public String f769o;

        /* renamed from: p  reason: collision with root package name */
        private List<n> f770p;
        /* access modifiers changed from: private */

        /* renamed from: q  reason: collision with root package name */
        public String f771q;
        /* access modifiers changed from: private */

        /* renamed from: r  reason: collision with root package name */
        public List<n> f772r;
        /* access modifiers changed from: private */

        /* renamed from: s  reason: collision with root package name */
        public String f773s;
        /* access modifiers changed from: private */

        /* renamed from: t  reason: collision with root package name */
        public List<n> f774t;
        /* access modifiers changed from: private */

        /* renamed from: u  reason: collision with root package name */
        public String f775u;
        /* access modifiers changed from: private */

        /* renamed from: v  reason: collision with root package name */
        public List<n> f776v;

        /* renamed from: w  reason: collision with root package name */
        private String f777w;

        /* renamed from: x  reason: collision with root package name */
        private List<n> f778x;
        /* access modifiers changed from: private */

        /* renamed from: y  reason: collision with root package name */
        public String f779y;
        /* access modifiers changed from: private */

        /* renamed from: z  reason: collision with root package name */
        public int f780z = -1;

        l(j jVar) {
            this.f754a = jVar;
        }

        /* access modifiers changed from: private */
        public static boolean A0(l lVar, d0.f<l> fVar) {
            return (lVar == null || lVar.j0(fVar) == null) ? false : true;
        }

        private void B0(float[] fArr, float[] fArr2, float[] fArr3) {
            Matrix.multiplyMV(fArr, 0, fArr2, 0, fArr3, 0);
            float f2 = fArr[3];
            fArr[0] = fArr[0] / f2;
            fArr[1] = fArr[1] / f2;
            fArr[2] = fArr[2] / f2;
            fArr[3] = 0.0f;
        }

        /* access modifiers changed from: private */
        public void C0(float[] fArr, Set<l> set, boolean z2) {
            set.add(this);
            if (this.Y) {
                z2 = true;
            }
            if (z2) {
                if (this.Z == null) {
                    this.Z = new float[16];
                }
                if (this.P == null) {
                    this.P = new float[16];
                }
                Matrix.multiplyMM(this.Z, 0, fArr, 0, this.P, 0);
                float[] fArr2 = new float[4];
                fArr2[2] = 0.0f;
                fArr2[3] = 1.0f;
                float[] fArr3 = new float[4];
                float[] fArr4 = new float[4];
                float[] fArr5 = new float[4];
                float[] fArr6 = new float[4];
                fArr2[0] = this.L;
                fArr2[1] = this.M;
                B0(fArr3, this.Z, fArr2);
                fArr2[0] = this.N;
                fArr2[1] = this.M;
                B0(fArr4, this.Z, fArr2);
                fArr2[0] = this.N;
                fArr2[1] = this.O;
                B0(fArr5, this.Z, fArr2);
                fArr2[0] = this.L;
                fArr2[1] = this.O;
                B0(fArr6, this.Z, fArr2);
                if (this.f755a0 == null) {
                    this.f755a0 = new Rect();
                }
                this.f755a0.set(Math.round(z0(fArr3[0], fArr4[0], fArr5[0], fArr6[0])), Math.round(z0(fArr3[1], fArr4[1], fArr5[1], fArr6[1])), Math.round(y0(fArr3[0], fArr4[0], fArr5[0], fArr6[0])), Math.round(y0(fArr3[1], fArr4[1], fArr5[1], fArr6[1])));
                this.Y = false;
            }
            int i2 = -1;
            for (l next : this.R) {
                next.f780z = i2;
                i2 = next.f756b;
                next.C0(this.Z, set, z2);
            }
        }

        /* access modifiers changed from: private */
        public void D0(ByteBuffer byteBuffer, String[] strArr, ByteBuffer[] byteBufferArr) {
            this.B = true;
            this.J = this.f771q;
            this.K = this.f769o;
            this.C = this.f757c;
            this.D = this.f758d;
            this.E = this.f761g;
            this.F = this.f762h;
            this.G = this.f766l;
            this.H = this.f767m;
            this.I = this.f768n;
            this.f757c = byteBuffer.getInt();
            this.f758d = byteBuffer.getInt();
            this.f759e = byteBuffer.getInt();
            this.f760f = byteBuffer.getInt();
            this.f761g = byteBuffer.getInt();
            this.f762h = byteBuffer.getInt();
            this.f763i = byteBuffer.getInt();
            this.f764j = byteBuffer.getInt();
            this.f765k = byteBuffer.getInt();
            this.f766l = byteBuffer.getFloat();
            this.f767m = byteBuffer.getFloat();
            this.f768n = byteBuffer.getFloat();
            int i2 = byteBuffer.getInt();
            this.f769o = i2 == -1 ? null : strArr[i2];
            this.f770p = o0(byteBuffer, byteBufferArr);
            int i3 = byteBuffer.getInt();
            this.f771q = i3 == -1 ? null : strArr[i3];
            this.f772r = o0(byteBuffer, byteBufferArr);
            int i4 = byteBuffer.getInt();
            this.f773s = i4 == -1 ? null : strArr[i4];
            this.f774t = o0(byteBuffer, byteBufferArr);
            int i5 = byteBuffer.getInt();
            this.f775u = i5 == -1 ? null : strArr[i5];
            this.f776v = o0(byteBuffer, byteBufferArr);
            int i6 = byteBuffer.getInt();
            this.f777w = i6 == -1 ? null : strArr[i6];
            this.f778x = o0(byteBuffer, byteBufferArr);
            int i7 = byteBuffer.getInt();
            this.f779y = i7 == -1 ? null : strArr[i7];
            this.A = p.a(byteBuffer.getInt());
            this.L = byteBuffer.getFloat();
            this.M = byteBuffer.getFloat();
            this.N = byteBuffer.getFloat();
            this.O = byteBuffer.getFloat();
            if (this.P == null) {
                this.P = new float[16];
            }
            for (int i8 = 0; i8 < 16; i8++) {
                this.P[i8] = byteBuffer.getFloat();
            }
            this.W = true;
            this.Y = true;
            int i9 = byteBuffer.getInt();
            this.R.clear();
            this.S.clear();
            for (int i10 = 0; i10 < i9; i10++) {
                l o2 = this.f754a.A(byteBuffer.getInt());
                o2.Q = this;
                this.R.add(o2);
            }
            for (int i11 = 0; i11 < i9; i11++) {
                l o3 = this.f754a.A(byteBuffer.getInt());
                o3.Q = this;
                this.S.add(o3);
            }
            int i12 = byteBuffer.getInt();
            if (i12 == 0) {
                this.T = null;
                return;
            }
            List<h> list = this.T;
            if (list == null) {
                this.T = new ArrayList(i12);
            } else {
                list.clear();
            }
            for (int i13 = 0; i13 < i12; i13++) {
                h q2 = this.f754a.z(byteBuffer.getInt());
                if (q2.f727c == g.TAP.f724d) {
                    this.U = q2;
                } else if (q2.f727c == g.LONG_PRESS.f724d) {
                    this.V = q2;
                } else {
                    this.T.add(q2);
                }
                this.T.add(q2);
            }
        }

        /* access modifiers changed from: private */
        public void e0(List<l> list) {
            if (v0(i.SCOPES_ROUTE)) {
                list.add(this);
            }
            for (l e02 : this.R) {
                e02.e0(list);
            }
        }

        @TargetApi(21)
        private SpannableString f0(String str, List<n> list) {
            if (str == null) {
                return null;
            }
            SpannableString spannableString = new SpannableString(str);
            if (list != null) {
                for (n next : list) {
                    int i2 = e.f692a[next.f783c.ordinal()];
                    if (i2 == 1) {
                        spannableString.setSpan(new TtsSpan$Builder("android.type.verbatim").build(), next.f781a, next.f782b, 0);
                    } else if (i2 == 2) {
                        spannableString.setSpan(new LocaleSpan(Locale.forLanguageTag(((C0012j) next).f753d)), next.f781a, next.f782b, 0);
                    }
                }
            }
            return spannableString;
        }

        /* access modifiers changed from: private */
        /* JADX WARNING: Code restructure failed: missing block: B:6:0x000c, code lost:
            r2 = r3.K;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean g0() {
            /*
                r3 = this;
                java.lang.String r0 = r3.f769o
                r1 = 0
                if (r0 != 0) goto L_0x000a
                java.lang.String r2 = r3.K
                if (r2 != 0) goto L_0x000a
                return r1
            L_0x000a:
                if (r0 == 0) goto L_0x0016
                java.lang.String r2 = r3.K
                if (r2 == 0) goto L_0x0016
                boolean r0 = r0.equals(r2)
                if (r0 != 0) goto L_0x0017
            L_0x0016:
                r1 = 1
            L_0x0017:
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: io.flutter.view.j.l.g0():boolean");
        }

        /* access modifiers changed from: private */
        public boolean h0() {
            return !Float.isNaN(this.f766l) && !Float.isNaN(this.G) && this.G != this.f766l;
        }

        private void i0() {
            if (this.W) {
                this.W = false;
                if (this.X == null) {
                    this.X = new float[16];
                }
                if (!Matrix.invertM(this.X, 0, this.P, 0)) {
                    Arrays.fill(this.X, 0.0f);
                }
            }
        }

        private l j0(d0.f<l> fVar) {
            for (l lVar = this.Q; lVar != null; lVar = lVar.Q) {
                if (fVar.test(lVar)) {
                    return lVar;
                }
            }
            return null;
        }

        /* access modifiers changed from: private */
        public Rect k0() {
            return this.f755a0;
        }

        private CharSequence l0() {
            return Build.VERSION.SDK_INT < 21 ? this.f777w : f0(this.f777w, this.f778x);
        }

        static /* synthetic */ int m(l lVar, int i2) {
            int i3 = lVar.f762h + i2;
            lVar.f762h = i3;
            return i3;
        }

        private CharSequence m0() {
            return Build.VERSION.SDK_INT < 21 ? this.f769o : f0(this.f769o, this.f770p);
        }

        static /* synthetic */ int n(l lVar, int i2) {
            int i3 = lVar.f762h - i2;
            lVar.f762h = i3;
            return i3;
        }

        /* access modifiers changed from: private */
        public String n0() {
            String str;
            if (v0(i.NAMES_ROUTE) && (str = this.f769o) != null && !str.isEmpty()) {
                return this.f769o;
            }
            for (l n02 : this.R) {
                String n03 = n02.n0();
                if (n03 != null && !n03.isEmpty()) {
                    return n03;
                }
            }
            return null;
        }

        private List<n> o0(ByteBuffer byteBuffer, ByteBuffer[] byteBufferArr) {
            int i2 = byteBuffer.getInt();
            if (i2 == -1) {
                return null;
            }
            ArrayList arrayList = new ArrayList(i2);
            for (int i3 = 0; i3 < i2; i3++) {
                int i4 = byteBuffer.getInt();
                int i5 = byteBuffer.getInt();
                o oVar = o.values()[byteBuffer.getInt()];
                int i6 = e.f692a[oVar.ordinal()];
                if (i6 == 1) {
                    byteBuffer.getInt();
                    m mVar = new m((a) null);
                    mVar.f781a = i4;
                    mVar.f782b = i5;
                    mVar.f783c = oVar;
                    arrayList.add(mVar);
                } else if (i6 == 2) {
                    ByteBuffer byteBuffer2 = byteBufferArr[byteBuffer.getInt()];
                    C0012j jVar = new C0012j((a) null);
                    jVar.f781a = i4;
                    jVar.f782b = i5;
                    jVar.f783c = oVar;
                    jVar.f753d = Charset.forName("UTF-8").decode(byteBuffer2).toString();
                    arrayList.add(jVar);
                }
            }
            return arrayList;
        }

        /* access modifiers changed from: private */
        public CharSequence p0() {
            CharSequence[] charSequenceArr = {m0(), l0()};
            CharSequence charSequence = null;
            for (int i2 = 0; i2 < 2; i2++) {
                CharSequence charSequence2 = charSequenceArr[i2];
                if (charSequence2 != null && charSequence2.length() > 0) {
                    if (charSequence == null || charSequence.length() == 0) {
                        charSequence = charSequence2;
                    } else {
                        charSequence = TextUtils.concat(new CharSequence[]{charSequence, ", ", charSequence2});
                    }
                }
            }
            return charSequence;
        }

        /* access modifiers changed from: private */
        public CharSequence q0() {
            return Build.VERSION.SDK_INT < 21 ? this.f771q : f0(this.f771q, this.f772r);
        }

        /* access modifiers changed from: private */
        public CharSequence r0() {
            CharSequence[] charSequenceArr = {q0(), m0(), l0()};
            CharSequence charSequence = null;
            for (int i2 = 0; i2 < 3; i2++) {
                CharSequence charSequence2 = charSequenceArr[i2];
                if (charSequence2 != null && charSequence2.length() > 0) {
                    if (charSequence == null || charSequence.length() == 0) {
                        charSequence = charSequence2;
                    } else {
                        charSequence = TextUtils.concat(new CharSequence[]{charSequence, ", ", charSequence2});
                    }
                }
            }
            return charSequence;
        }

        /* access modifiers changed from: private */
        public boolean s0(g gVar) {
            return (gVar.f724d & this.D) != 0;
        }

        /* access modifiers changed from: private */
        public boolean t0(i iVar) {
            return (iVar.f752d & this.C) != 0;
        }

        /* access modifiers changed from: private */
        public boolean u0(g gVar) {
            return (gVar.f724d & this.f758d) != 0;
        }

        /* access modifiers changed from: private */
        public boolean v0(i iVar) {
            return (iVar.f752d & this.f757c) != 0;
        }

        /* access modifiers changed from: private */
        public l w0(float[] fArr, boolean z2) {
            float f2 = fArr[3];
            boolean z3 = false;
            float f3 = fArr[0] / f2;
            float f4 = fArr[1] / f2;
            if (f3 < this.L || f3 >= this.N || f4 < this.M || f4 >= this.O) {
                return null;
            }
            float[] fArr2 = new float[4];
            for (l next : this.S) {
                if (!next.v0(i.IS_HIDDEN)) {
                    next.i0();
                    Matrix.multiplyMV(fArr2, 0, next.X, 0, fArr, 0);
                    l w02 = next.w0(fArr2, z2);
                    if (w02 != null) {
                        return w02;
                    }
                }
            }
            if (z2 && this.f763i != -1) {
                z3 = true;
            }
            if (x0() || z3) {
                return this;
            }
            return null;
        }

        /* access modifiers changed from: private */
        /* JADX WARNING: Code restructure failed: missing block: B:10:0x0028, code lost:
            r0 = r4.f769o;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:14:0x0032, code lost:
            r0 = r4.f771q;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:0x003c, code lost:
            r0 = r4.f777w;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean x0() {
            /*
                r4 = this;
                io.flutter.view.j$i r0 = io.flutter.view.j.i.SCOPES_ROUTE
                boolean r0 = r4.v0(r0)
                r1 = 0
                if (r0 == 0) goto L_0x000a
                return r1
            L_0x000a:
                io.flutter.view.j$i r0 = io.flutter.view.j.i.IS_FOCUSABLE
                boolean r0 = r4.v0(r0)
                r2 = 1
                if (r0 == 0) goto L_0x0014
                return r2
            L_0x0014:
                int r0 = r4.f758d
                int r3 = io.flutter.view.j.f661z
                r3 = r3 ^ -1
                r0 = r0 & r3
                if (r0 != 0) goto L_0x0046
                int r0 = r4.f757c
                int r3 = io.flutter.view.j.A
                r0 = r0 & r3
                if (r0 != 0) goto L_0x0046
                java.lang.String r0 = r4.f769o
                if (r0 == 0) goto L_0x0032
                boolean r0 = r0.isEmpty()
                if (r0 == 0) goto L_0x0046
            L_0x0032:
                java.lang.String r0 = r4.f771q
                if (r0 == 0) goto L_0x003c
                boolean r0 = r0.isEmpty()
                if (r0 == 0) goto L_0x0046
            L_0x003c:
                java.lang.String r0 = r4.f777w
                if (r0 == 0) goto L_0x0047
                boolean r0 = r0.isEmpty()
                if (r0 != 0) goto L_0x0047
            L_0x0046:
                r1 = 1
            L_0x0047:
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: io.flutter.view.j.l.x0():boolean");
        }

        private float y0(float f2, float f3, float f4, float f5) {
            return Math.max(f2, Math.max(f3, Math.max(f4, f5)));
        }

        private float z0(float f2, float f3, float f4, float f5) {
            return Math.min(f2, Math.min(f3, Math.min(f4, f5)));
        }
    }

    private static class m extends n {
        private m() {
            super((a) null);
        }

        /* synthetic */ m(a aVar) {
            this();
        }
    }

    private static class n {

        /* renamed from: a  reason: collision with root package name */
        int f781a;

        /* renamed from: b  reason: collision with root package name */
        int f782b;

        /* renamed from: c  reason: collision with root package name */
        o f783c;

        private n() {
        }

        /* synthetic */ n(a aVar) {
            this();
        }
    }

    private enum o {
        SPELLOUT,
        LOCALE
    }

    private enum p {
        UNKNOWN,
        LTR,
        RTL;

        public static p a(int i2) {
            return i2 != 1 ? i2 != 2 ? UNKNOWN : LTR : RTL;
        }
    }

    public j(View view, y.a aVar, AccessibilityManager accessibilityManager, ContentResolver contentResolver, q qVar) {
        this(view, aVar, accessibilityManager, contentResolver, new AccessibilityViewEmbedder(view, 65536), qVar);
    }

    public j(View view, y.a aVar, AccessibilityManager accessibilityManager, ContentResolver contentResolver, AccessibilityViewEmbedder accessibilityViewEmbedder, q qVar) {
        this.f668g = new HashMap();
        this.f669h = new HashMap();
        this.f673l = 0;
        this.f677p = new ArrayList();
        this.f678q = 0;
        this.f679r = 0;
        this.f681t = false;
        this.f682u = false;
        this.f683v = new a();
        b bVar = new b();
        this.f684w = bVar;
        c cVar = new c(new Handler());
        this.f686y = cVar;
        this.f662a = view;
        this.f663b = aVar;
        this.f664c = accessibilityManager;
        this.f667f = contentResolver;
        this.f665d = accessibilityViewEmbedder;
        this.f666e = qVar;
        bVar.onAccessibilityStateChanged(accessibilityManager.isEnabled());
        accessibilityManager.addAccessibilityStateChangeListener(bVar);
        int i2 = Build.VERSION.SDK_INT;
        d dVar = new d(accessibilityManager);
        this.f685x = dVar;
        dVar.onTouchExplorationStateChanged(accessibilityManager.isTouchExplorationEnabled());
        accessibilityManager.addTouchExplorationStateChangeListener(dVar);
        cVar.onChange(false);
        contentResolver.registerContentObserver(Settings.Global.getUriFor("transition_animation_scale"), false, cVar);
        if (i2 >= 31) {
            X();
        }
        qVar.b(this);
    }

    /* access modifiers changed from: private */
    public l A(int i2) {
        l lVar = this.f668g.get(Integer.valueOf(i2));
        if (lVar != null) {
            return lVar;
        }
        l lVar2 = new l(this);
        int unused = lVar2.f756b = i2;
        this.f668g.put(Integer.valueOf(i2), lVar2);
        return lVar2;
    }

    private l B() {
        return this.f668g.get(0);
    }

    private void C(float f2, float f3, boolean z2) {
        l J;
        if (!this.f668g.isEmpty() && (J = B().w0(new float[]{f2, f3, 0.0f, 1.0f}, z2)) != this.f676o) {
            if (J != null) {
                R(J.f756b, 128);
            }
            l lVar = this.f676o;
            if (lVar != null) {
                R(lVar.f756b, 256);
            }
            this.f676o = J;
        }
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ boolean F(l lVar, l lVar2) {
        return lVar2 == lVar;
    }

    /* access modifiers changed from: private */
    public AccessibilityEvent H(int i2, int i3) {
        AccessibilityEvent obtain = AccessibilityEvent.obtain(i3);
        obtain.setPackageName(this.f662a.getContext().getPackageName());
        obtain.setSource(this.f662a, i2);
        return obtain;
    }

    /* access modifiers changed from: private */
    public void L() {
        l lVar = this.f676o;
        if (lVar != null) {
            R(lVar.f756b, 256);
            this.f676o = null;
        }
    }

    private void M(l lVar) {
        String d02 = lVar.n0();
        if (d02 == null) {
            d02 = " ";
        }
        if (Build.VERSION.SDK_INT >= 28) {
            V(d02);
            return;
        }
        AccessibilityEvent H = H(lVar.f756b, 32);
        H.getText().add(d02);
        S(H);
    }

    @TargetApi(18)
    private boolean N(l lVar, int i2, Bundle bundle, boolean z2) {
        int i3 = bundle.getInt("ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT");
        boolean z3 = bundle.getBoolean("ACTION_ARGUMENT_EXTEND_SELECTION_BOOLEAN");
        int i4 = lVar.f761g;
        int k2 = lVar.f762h;
        P(lVar, i3, z2, z3);
        if (!(i4 == lVar.f761g && k2 == lVar.f762h)) {
            String q2 = lVar.f771q != null ? lVar.f771q : "";
            AccessibilityEvent H = H(lVar.f756b, 8192);
            H.getText().add(q2);
            H.setFromIndex(lVar.f761g);
            H.setToIndex(lVar.f762h);
            H.setItemCount(q2.length());
            S(H);
        }
        if (i3 == 1) {
            if (z2) {
                g gVar = g.MOVE_CURSOR_FORWARD_BY_CHARACTER;
                if (lVar.u0(gVar)) {
                    this.f663b.c(i2, gVar, Boolean.valueOf(z3));
                    return true;
                }
            }
            if (z2) {
                return false;
            }
            g gVar2 = g.MOVE_CURSOR_BACKWARD_BY_CHARACTER;
            if (!lVar.u0(gVar2)) {
                return false;
            }
            this.f663b.c(i2, gVar2, Boolean.valueOf(z3));
            return true;
        } else if (i3 != 2) {
            return i3 == 4 || i3 == 8 || i3 == 16;
        } else {
            if (z2) {
                g gVar3 = g.MOVE_CURSOR_FORWARD_BY_WORD;
                if (lVar.u0(gVar3)) {
                    this.f663b.c(i2, gVar3, Boolean.valueOf(z3));
                    return true;
                }
            }
            if (z2) {
                return false;
            }
            g gVar4 = g.MOVE_CURSOR_BACKWARD_BY_WORD;
            if (!lVar.u0(gVar4)) {
                return false;
            }
            this.f663b.c(i2, gVar4, Boolean.valueOf(z3));
            return true;
        }
    }

    @TargetApi(21)
    private boolean O(l lVar, int i2, Bundle bundle) {
        String string = (bundle == null || !bundle.containsKey("ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE")) ? "" : bundle.getString("ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE");
        this.f663b.c(i2, g.SET_TEXT, string);
        String unused = lVar.f771q = string;
        List unused2 = lVar.f772r = null;
        return true;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0022, code lost:
        if (r6 != false) goto L_0x0024;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0060, code lost:
        if (r5.find() != false) goto L_0x0062;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0062, code lost:
        io.flutter.view.j.l.m(r4, r5.start(1));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x008d, code lost:
        if (r5.find() != false) goto L_0x008f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x008f, code lost:
        r5 = r5.start(1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x00c1, code lost:
        if (r5.find() != false) goto L_0x0062;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x00e6, code lost:
        if (r5.find() != false) goto L_0x008f;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void P(io.flutter.view.j.l r4, int r5, boolean r6, boolean r7) {
        /*
            r3 = this;
            int r0 = r4.f762h
            if (r0 < 0) goto L_0x0111
            int r0 = r4.f761g
            if (r0 >= 0) goto L_0x000e
            goto L_0x0111
        L_0x000e:
            r0 = 1
            if (r5 == r0) goto L_0x00e9
            r1 = 2
            r2 = 0
            if (r5 == r1) goto L_0x0094
            r1 = 4
            if (r5 == r1) goto L_0x0036
            r0 = 8
            if (r5 == r0) goto L_0x0022
            r0 = 16
            if (r5 == r0) goto L_0x0022
            goto L_0x0108
        L_0x0022:
            if (r6 == 0) goto L_0x0031
        L_0x0024:
            java.lang.String r5 = r4.f771q
            int r5 = r5.length()
        L_0x002c:
            int unused = r4.f762h = r5
            goto L_0x0108
        L_0x0031:
            int unused = r4.f762h = r2
            goto L_0x0108
        L_0x0036:
            if (r6 == 0) goto L_0x006b
            int r5 = r4.f762h
            java.lang.String r1 = r4.f771q
            int r1 = r1.length()
            if (r5 >= r1) goto L_0x006b
            java.lang.String r5 = "(?!^)(\\n)"
            java.util.regex.Pattern r5 = java.util.regex.Pattern.compile(r5)
            java.lang.String r6 = r4.f771q
            int r1 = r4.f762h
            java.lang.String r6 = r6.substring(r1)
            java.util.regex.Matcher r5 = r5.matcher(r6)
            boolean r6 = r5.find()
            if (r6 == 0) goto L_0x0024
        L_0x0062:
            int r5 = r5.start(r0)
            io.flutter.view.j.l.m(r4, r5)
            goto L_0x0108
        L_0x006b:
            if (r6 != 0) goto L_0x0108
            int r5 = r4.f762h
            if (r5 <= 0) goto L_0x0108
            java.lang.String r5 = "(?s:.*)(\\n)"
            java.util.regex.Pattern r5 = java.util.regex.Pattern.compile(r5)
            java.lang.String r6 = r4.f771q
            int r1 = r4.f762h
            java.lang.String r6 = r6.substring(r2, r1)
            java.util.regex.Matcher r5 = r5.matcher(r6)
            boolean r6 = r5.find()
            if (r6 == 0) goto L_0x0031
        L_0x008f:
            int r5 = r5.start(r0)
            goto L_0x002c
        L_0x0094:
            if (r6 == 0) goto L_0x00c4
            int r5 = r4.f762h
            java.lang.String r1 = r4.f771q
            int r1 = r1.length()
            if (r5 >= r1) goto L_0x00c4
            java.lang.String r5 = "\\p{L}(\\b)"
            java.util.regex.Pattern r5 = java.util.regex.Pattern.compile(r5)
            java.lang.String r6 = r4.f771q
            int r1 = r4.f762h
            java.lang.String r6 = r6.substring(r1)
            java.util.regex.Matcher r5 = r5.matcher(r6)
            r5.find()
            boolean r6 = r5.find()
            if (r6 == 0) goto L_0x0024
            goto L_0x0062
        L_0x00c4:
            if (r6 != 0) goto L_0x0108
            int r5 = r4.f762h
            if (r5 <= 0) goto L_0x0108
            java.lang.String r5 = "(?s:.*)(\\b)\\p{L}"
            java.util.regex.Pattern r5 = java.util.regex.Pattern.compile(r5)
            java.lang.String r6 = r4.f771q
            int r1 = r4.f762h
            java.lang.String r6 = r6.substring(r2, r1)
            java.util.regex.Matcher r5 = r5.matcher(r6)
            boolean r6 = r5.find()
            if (r6 == 0) goto L_0x0108
            goto L_0x008f
        L_0x00e9:
            if (r6 == 0) goto L_0x00fd
            int r5 = r4.f762h
            java.lang.String r1 = r4.f771q
            int r1 = r1.length()
            if (r5 >= r1) goto L_0x00fd
            io.flutter.view.j.l.m(r4, r0)
            goto L_0x0108
        L_0x00fd:
            if (r6 != 0) goto L_0x0108
            int r5 = r4.f762h
            if (r5 <= 0) goto L_0x0108
            io.flutter.view.j.l.n(r4, r0)
        L_0x0108:
            if (r7 != 0) goto L_0x0111
            int r5 = r4.f762h
            int unused = r4.f761g = r5
        L_0x0111:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.flutter.view.j.P(io.flutter.view.j$l, int, boolean, boolean):void");
    }

    /* access modifiers changed from: private */
    public void R(int i2, int i3) {
        if (this.f664c.isEnabled()) {
            S(H(i2, i3));
        }
    }

    /* access modifiers changed from: private */
    public void S(AccessibilityEvent accessibilityEvent) {
        if (this.f664c.isEnabled()) {
            this.f662a.getParent().requestSendAccessibilityEvent(this.f662a, accessibilityEvent);
        }
    }

    /* access modifiers changed from: private */
    public void T() {
        this.f663b.f(this.f673l);
    }

    private void U(int i2) {
        AccessibilityEvent H = H(i2, 2048);
        H.setContentChangeTypes(1);
        S(H);
    }

    @TargetApi(28)
    private void V(String str) {
        this.f662a.setAccessibilityPaneTitle(str);
    }

    /* access modifiers changed from: private */
    public void W(boolean z2) {
        if (this.f681t != z2) {
            this.f681t = z2;
            this.f673l = z2 ? this.f673l | f.ACCESSIBLE_NAVIGATION.f701d : this.f673l & (f.ACCESSIBLE_NAVIGATION.f701d ^ -1);
            T();
        }
    }

    @TargetApi(31)
    private void X() {
        View view = this.f662a;
        if (view != null && view.getResources() != null) {
            int i2 = this.f662a.getResources().getConfiguration().fontWeightAdjustment;
            this.f673l = i2 != Integer.MAX_VALUE && i2 >= 300 ? this.f673l | f.BOLD_TEXT.f701d : this.f673l & f.BOLD_TEXT.f701d;
            T();
        }
    }

    private boolean Z(l lVar) {
        return lVar.f764j > 0 && (l.A0(this.f670i, new h(lVar)) || !l.A0(this.f670i, new i()));
    }

    @TargetApi(19)
    private void c0(l lVar) {
        View d2;
        Integer num;
        l unused = lVar.Q = null;
        if (!(lVar.f763i == -1 || (num = this.f671j) == null || this.f665d.platformViewOfNode(num.intValue()) != this.f666e.d(lVar.f763i))) {
            R(this.f671j.intValue(), 65536);
            this.f671j = null;
        }
        if (!(lVar.f763i == -1 || (d2 = this.f666e.d(lVar.f763i)) == null)) {
            d2.setImportantForAccessibility(4);
        }
        l lVar2 = this.f670i;
        if (lVar2 == lVar) {
            R(lVar2.f756b, 65536);
            this.f670i = null;
        }
        if (this.f674m == lVar) {
            this.f674m = null;
        }
        if (this.f676o == lVar) {
            this.f676o = null;
        }
    }

    static /* synthetic */ int f(j jVar, int i2) {
        int i3 = i2 & jVar.f673l;
        jVar.f673l = i3;
        return i3;
    }

    static /* synthetic */ int g(j jVar, int i2) {
        int i3 = i2 | jVar.f673l;
        jVar.f673l = i3;
        return i3;
    }

    private AccessibilityEvent v(int i2, String str, String str2) {
        AccessibilityEvent H = H(i2, 16);
        H.setBeforeText(str);
        H.getText().add(str2);
        int i3 = 0;
        while (i3 < str.length() && i3 < str2.length() && str.charAt(i3) == str2.charAt(i3)) {
            i3++;
        }
        if (i3 >= str.length() && i3 >= str2.length()) {
            return null;
        }
        H.setFromIndex(i3);
        int length = str.length() - 1;
        int length2 = str2.length() - 1;
        while (length >= i3 && length2 >= i3 && str.charAt(length) == str2.charAt(length2)) {
            length--;
            length2--;
        }
        H.setRemovedCount((length - i3) + 1);
        H.setAddedCount((length2 - i3) + 1);
        return H;
    }

    @TargetApi(28)
    private boolean w() {
        Activity f2 = d0.j.f(this.f662a.getContext());
        if (f2 == null || f2.getWindow() == null) {
            return false;
        }
        int i2 = f2.getWindow().getAttributes().layoutInDisplayCutoutMode;
        return i2 == 2 || i2 == 0;
    }

    private Rect y(Rect rect) {
        Rect rect2 = new Rect(rect);
        int[] iArr = new int[2];
        this.f662a.getLocationOnScreen(iArr);
        rect2.offset(iArr[0], iArr[1]);
        return rect2;
    }

    /* access modifiers changed from: private */
    public h z(int i2) {
        h hVar = this.f669h.get(Integer.valueOf(i2));
        if (hVar != null) {
            return hVar;
        }
        h hVar2 = new h();
        int unused = hVar2.f726b = i2;
        int unused2 = hVar2.f725a = B + i2;
        this.f669h.put(Integer.valueOf(i2), hVar2);
        return hVar2;
    }

    public boolean D() {
        return this.f664c.isEnabled();
    }

    public boolean E() {
        return this.f664c.isTouchExplorationEnabled();
    }

    public AccessibilityNodeInfo I(View view, int i2) {
        return AccessibilityNodeInfo.obtain(view, i2);
    }

    public boolean J(MotionEvent motionEvent) {
        return K(motionEvent, false);
    }

    public boolean K(MotionEvent motionEvent, boolean z2) {
        if (!this.f664c.isTouchExplorationEnabled() || this.f668g.isEmpty()) {
            return false;
        }
        l J = B().w0(new float[]{motionEvent.getX(), motionEvent.getY(), 0.0f, 1.0f}, z2);
        if (J == null || J.f763i == -1) {
            if (motionEvent.getAction() == 9 || motionEvent.getAction() == 7) {
                C(motionEvent.getX(), motionEvent.getY(), z2);
            } else if (motionEvent.getAction() == 10) {
                L();
            } else {
                m.b.a("flutter", "unexpected accessibility hover event: " + motionEvent);
                return false;
            }
            return true;
        } else if (z2) {
            return false;
        } else {
            return this.f665d.onAccessibilityHoverEvent(J.f756b, motionEvent);
        }
    }

    public void Q() {
        this.f682u = true;
        this.f666e.a();
        Y((k) null);
        this.f664c.removeAccessibilityStateChangeListener(this.f684w);
        this.f664c.removeTouchExplorationStateChangeListener(this.f685x);
        this.f667f.unregisterContentObserver(this.f686y);
        this.f663b.g((a.b) null);
    }

    public void Y(k kVar) {
        this.f680s = kVar;
    }

    /* access modifiers changed from: package-private */
    public void a0(ByteBuffer byteBuffer, String[] strArr) {
        while (byteBuffer.hasRemaining()) {
            h z2 = z(byteBuffer.getInt());
            int unused = z2.f727c = byteBuffer.getInt();
            int i2 = byteBuffer.getInt();
            String str = null;
            String unused2 = z2.f728d = i2 == -1 ? null : strArr[i2];
            int i3 = byteBuffer.getInt();
            if (i3 != -1) {
                str = strArr[i3];
            }
            String unused3 = z2.f729e = str;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v19, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v24, resolved type: io.flutter.view.j$l} */
    /* access modifiers changed from: package-private */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void b0(java.nio.ByteBuffer r9, java.lang.String[] r10, java.nio.ByteBuffer[] r11) {
        /*
            r8 = this;
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
        L_0x0005:
            boolean r1 = r9.hasRemaining()
            r2 = 0
            if (r1 == 0) goto L_0x0056
            int r1 = r9.getInt()
            io.flutter.view.j$l r1 = r8.A(r1)
            r1.D0(r9, r10, r11)
            io.flutter.view.j$i r3 = io.flutter.view.j.i.IS_HIDDEN
            boolean r3 = r1.v0(r3)
            if (r3 == 0) goto L_0x0020
            goto L_0x0005
        L_0x0020:
            io.flutter.view.j$i r3 = io.flutter.view.j.i.IS_FOCUSED
            boolean r3 = r1.v0(r3)
            if (r3 == 0) goto L_0x002a
            r8.f674m = r1
        L_0x002a:
            boolean r3 = r1.B
            if (r3 == 0) goto L_0x0033
            r0.add(r1)
        L_0x0033:
            int r3 = r1.f763i
            r4 = -1
            if (r3 == r4) goto L_0x0005
            io.flutter.plugin.platform.q r3 = r8.f666e
            int r4 = r1.f763i
            boolean r3 = r3.c(r4)
            if (r3 != 0) goto L_0x0005
            io.flutter.plugin.platform.q r3 = r8.f666e
            int r1 = r1.f763i
            android.view.View r1 = r3.d(r1)
            if (r1 == 0) goto L_0x0005
            r1.setImportantForAccessibility(r2)
            goto L_0x0005
        L_0x0056:
            java.util.HashSet r9 = new java.util.HashSet
            r9.<init>()
            io.flutter.view.j$l r10 = r8.B()
            java.util.ArrayList r11 = new java.util.ArrayList
            r11.<init>()
            r1 = 1
            if (r10 == 0) goto L_0x00b7
            r3 = 16
            float[] r3 = new float[r3]
            android.opengl.Matrix.setIdentityM(r3, r2)
            int r4 = android.os.Build.VERSION.SDK_INT
            r5 = 23
            if (r4 < r5) goto L_0x00b1
            r5 = 28
            if (r4 < r5) goto L_0x007d
            boolean r4 = r8.w()
            goto L_0x007e
        L_0x007d:
            r4 = 1
        L_0x007e:
            if (r4 == 0) goto L_0x00b1
            android.view.View r4 = r8.f662a
            android.view.WindowInsets r4 = r4.getRootWindowInsets()
            if (r4 == 0) goto L_0x00b1
            java.lang.Integer r5 = r8.f679r
            int r6 = r4.getSystemWindowInsetLeft()
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            boolean r5 = r5.equals(r6)
            if (r5 != 0) goto L_0x009e
            boolean unused = r10.Y = r1
            boolean unused = r10.W = r1
        L_0x009e:
            int r4 = r4.getSystemWindowInsetLeft()
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            r8.f679r = r4
            int r4 = r4.intValue()
            float r4 = (float) r4
            r5 = 0
            android.opengl.Matrix.translateM(r3, r2, r4, r5, r5)
        L_0x00b1:
            r10.C0(r3, r9, r2)
            r10.e0(r11)
        L_0x00b7:
            java.util.Iterator r10 = r11.iterator()
            r3 = 0
            r4 = r3
        L_0x00bd:
            boolean r5 = r10.hasNext()
            if (r5 == 0) goto L_0x00db
            java.lang.Object r5 = r10.next()
            io.flutter.view.j$l r5 = (io.flutter.view.j.l) r5
            java.util.List<java.lang.Integer> r6 = r8.f677p
            int r7 = r5.f756b
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)
            boolean r6 = r6.contains(r7)
            if (r6 != 0) goto L_0x00bd
            r4 = r5
            goto L_0x00bd
        L_0x00db:
            if (r4 != 0) goto L_0x00ef
            int r10 = r11.size()
            if (r10 <= 0) goto L_0x00ef
            int r10 = r11.size()
            int r10 = r10 - r1
            java.lang.Object r10 = r11.get(r10)
            r4 = r10
            io.flutter.view.j$l r4 = (io.flutter.view.j.l) r4
        L_0x00ef:
            if (r4 == 0) goto L_0x010e
            int r10 = r4.f756b
            int r5 = r8.f678q
            if (r10 != r5) goto L_0x0105
            int r10 = r11.size()
            java.util.List<java.lang.Integer> r5 = r8.f677p
            int r5 = r5.size()
            if (r10 == r5) goto L_0x010e
        L_0x0105:
            int r10 = r4.f756b
            r8.f678q = r10
            r8.M(r4)
        L_0x010e:
            java.util.List<java.lang.Integer> r10 = r8.f677p
            r10.clear()
            java.util.Iterator r10 = r11.iterator()
        L_0x0117:
            boolean r11 = r10.hasNext()
            if (r11 == 0) goto L_0x0131
            java.lang.Object r11 = r10.next()
            io.flutter.view.j$l r11 = (io.flutter.view.j.l) r11
            java.util.List<java.lang.Integer> r4 = r8.f677p
            int r11 = r11.f756b
            java.lang.Integer r11 = java.lang.Integer.valueOf(r11)
            r4.add(r11)
            goto L_0x0117
        L_0x0131:
            java.util.Map<java.lang.Integer, io.flutter.view.j$l> r10 = r8.f668g
            java.util.Set r10 = r10.entrySet()
            java.util.Iterator r10 = r10.iterator()
        L_0x013b:
            boolean r11 = r10.hasNext()
            if (r11 == 0) goto L_0x015a
            java.lang.Object r11 = r10.next()
            java.util.Map$Entry r11 = (java.util.Map.Entry) r11
            java.lang.Object r11 = r11.getValue()
            io.flutter.view.j$l r11 = (io.flutter.view.j.l) r11
            boolean r4 = r9.contains(r11)
            if (r4 != 0) goto L_0x013b
            r8.c0(r11)
            r10.remove()
            goto L_0x013b
        L_0x015a:
            r8.U(r2)
            java.util.Iterator r9 = r0.iterator()
        L_0x0161:
            boolean r10 = r9.hasNext()
            if (r10 == 0) goto L_0x0340
            java.lang.Object r10 = r9.next()
            io.flutter.view.j$l r10 = (io.flutter.view.j.l) r10
            boolean r11 = r10.h0()
            if (r11 == 0) goto L_0x0232
            int r11 = r10.f756b
            r0 = 4096(0x1000, float:5.74E-42)
            android.view.accessibility.AccessibilityEvent r11 = r8.H(r11, r0)
            float r0 = r10.f766l
            float r4 = r10.f767m
            float r5 = r10.f767m
            boolean r5 = java.lang.Float.isInfinite(r5)
            r6 = 1200142336(0x4788b800, float:70000.0)
            r7 = 1203982336(0x47c35000, float:100000.0)
            if (r5 == 0) goto L_0x019f
            int r4 = (r0 > r6 ? 1 : (r0 == r6 ? 0 : -1))
            if (r4 <= 0) goto L_0x019c
            r0 = 1200142336(0x4788b800, float:70000.0)
        L_0x019c:
            r4 = 1203982336(0x47c35000, float:100000.0)
        L_0x019f:
            float r5 = r10.f768n
            boolean r5 = java.lang.Float.isInfinite(r5)
            if (r5 == 0) goto L_0x01b6
            float r4 = r4 + r7
            r5 = -947341312(0xffffffffc788b800, float:-70000.0)
            int r6 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
            if (r6 >= 0) goto L_0x01b4
            r0 = -947341312(0xffffffffc788b800, float:-70000.0)
        L_0x01b4:
            float r0 = r0 + r7
            goto L_0x01c0
        L_0x01b6:
            float r5 = r10.f768n
            float r4 = r4 - r5
            float r5 = r10.f768n
            float r0 = r0 - r5
        L_0x01c0:
            io.flutter.view.j$g r5 = io.flutter.view.j.g.SCROLL_UP
            boolean r5 = r10.s0(r5)
            if (r5 != 0) goto L_0x01ea
            io.flutter.view.j$g r5 = io.flutter.view.j.g.SCROLL_DOWN
            boolean r5 = r10.s0(r5)
            if (r5 == 0) goto L_0x01d1
            goto L_0x01ea
        L_0x01d1:
            io.flutter.view.j$g r5 = io.flutter.view.j.g.SCROLL_LEFT
            boolean r5 = r10.s0(r5)
            if (r5 != 0) goto L_0x01e1
            io.flutter.view.j$g r5 = io.flutter.view.j.g.SCROLL_RIGHT
            boolean r5 = r10.s0(r5)
            if (r5 == 0) goto L_0x01f2
        L_0x01e1:
            int r0 = (int) r0
            r11.setScrollX(r0)
            int r0 = (int) r4
            r11.setMaxScrollX(r0)
            goto L_0x01f2
        L_0x01ea:
            int r0 = (int) r0
            r11.setScrollY(r0)
            int r0 = (int) r4
            r11.setMaxScrollY(r0)
        L_0x01f2:
            int r0 = r10.f764j
            if (r0 <= 0) goto L_0x022f
            int r0 = r10.f764j
            r11.setItemCount(r0)
            int r0 = r10.f765k
            r11.setFromIndex(r0)
            java.util.List r0 = r10.S
            java.util.Iterator r0 = r0.iterator()
            r4 = 0
        L_0x020f:
            boolean r5 = r0.hasNext()
            if (r5 == 0) goto L_0x0226
            java.lang.Object r5 = r0.next()
            io.flutter.view.j$l r5 = (io.flutter.view.j.l) r5
            io.flutter.view.j$i r6 = io.flutter.view.j.i.IS_HIDDEN
            boolean r5 = r5.v0(r6)
            if (r5 != 0) goto L_0x020f
            int r4 = r4 + 1
            goto L_0x020f
        L_0x0226:
            int r0 = r10.f765k
            int r0 = r0 + r4
            int r0 = r0 - r1
            r11.setToIndex(r0)
        L_0x022f:
            r8.S(r11)
        L_0x0232:
            io.flutter.view.j$i r11 = io.flutter.view.j.i.IS_LIVE_REGION
            boolean r11 = r10.v0(r11)
            if (r11 == 0) goto L_0x0247
            boolean r11 = r10.g0()
            if (r11 == 0) goto L_0x0247
            int r11 = r10.f756b
            r8.U(r11)
        L_0x0247:
            io.flutter.view.j$l r11 = r8.f670i
            if (r11 == 0) goto L_0x027a
            int r11 = r11.f756b
            int r0 = r10.f756b
            if (r11 != r0) goto L_0x027a
            io.flutter.view.j$i r11 = io.flutter.view.j.i.IS_SELECTED
            boolean r0 = r10.t0(r11)
            if (r0 != 0) goto L_0x027a
            boolean r11 = r10.v0(r11)
            if (r11 == 0) goto L_0x027a
            int r11 = r10.f756b
            r0 = 4
            android.view.accessibility.AccessibilityEvent r11 = r8.H(r11, r0)
            java.util.List r0 = r11.getText()
            java.lang.String r4 = r10.f769o
            r0.add(r4)
            r8.S(r11)
        L_0x027a:
            io.flutter.view.j$l r11 = r8.f674m
            if (r11 == 0) goto L_0x02aa
            int r11 = r11.f756b
            int r0 = r10.f756b
            if (r11 != r0) goto L_0x02aa
            io.flutter.view.j$l r11 = r8.f675n
            if (r11 == 0) goto L_0x0298
            int r11 = r11.f756b
            io.flutter.view.j$l r0 = r8.f674m
            int r0 = r0.f756b
            if (r11 == r0) goto L_0x02aa
        L_0x0298:
            io.flutter.view.j$l r11 = r8.f674m
            r8.f675n = r11
            int r11 = r10.f756b
            r0 = 8
            android.view.accessibility.AccessibilityEvent r11 = r8.H(r11, r0)
            r8.S(r11)
            goto L_0x02b0
        L_0x02aa:
            io.flutter.view.j$l r11 = r8.f674m
            if (r11 != 0) goto L_0x02b0
            r8.f675n = r3
        L_0x02b0:
            io.flutter.view.j$l r11 = r8.f674m
            if (r11 == 0) goto L_0x0161
            int r11 = r11.f756b
            int r0 = r10.f756b
            if (r11 != r0) goto L_0x0161
            io.flutter.view.j$i r11 = io.flutter.view.j.i.IS_TEXT_FIELD
            boolean r0 = r10.t0(r11)
            if (r0 == 0) goto L_0x0161
            boolean r11 = r10.v0(r11)
            if (r11 == 0) goto L_0x0161
            io.flutter.view.j$l r11 = r8.f670i
            if (r11 == 0) goto L_0x02dc
            int r11 = r11.f756b
            io.flutter.view.j$l r0 = r8.f674m
            int r0 = r0.f756b
            if (r11 != r0) goto L_0x0161
        L_0x02dc:
            java.lang.String r11 = r10.J
            java.lang.String r0 = ""
            if (r11 == 0) goto L_0x02e9
            java.lang.String r11 = r10.J
            goto L_0x02ea
        L_0x02e9:
            r11 = r0
        L_0x02ea:
            java.lang.String r4 = r10.f771q
            if (r4 == 0) goto L_0x02f4
            java.lang.String r0 = r10.f771q
        L_0x02f4:
            int r4 = r10.f756b
            android.view.accessibility.AccessibilityEvent r11 = r8.v(r4, r11, r0)
            if (r11 == 0) goto L_0x0301
            r8.S(r11)
        L_0x0301:
            int r11 = r10.E
            int r4 = r10.f761g
            if (r11 != r4) goto L_0x0315
            int r11 = r10.F
            int r4 = r10.f762h
            if (r11 == r4) goto L_0x0161
        L_0x0315:
            int r11 = r10.f756b
            r4 = 8192(0x2000, float:1.14794E-41)
            android.view.accessibility.AccessibilityEvent r11 = r8.H(r11, r4)
            java.util.List r4 = r11.getText()
            r4.add(r0)
            int r4 = r10.f761g
            r11.setFromIndex(r4)
            int r10 = r10.f762h
            r11.setToIndex(r10)
            int r10 = r0.length()
            r11.setItemCount(r10)
            r8.S(r11)
            goto L_0x0161
        L_0x0340:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: io.flutter.view.j.b0(java.nio.ByteBuffer, java.lang.String[], java.nio.ByteBuffer[]):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:221:0x040e  */
    /* JADX WARNING: Removed duplicated region for block: B:226:0x0421  */
    /* JADX WARNING: Removed duplicated region for block: B:227:0x0424  */
    /* JADX WARNING: Removed duplicated region for block: B:235:0x043f A[LOOP:0: B:233:0x0439->B:235:0x043f, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:239:0x0464  */
    @android.annotation.SuppressLint({"NewApi"})
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.accessibility.AccessibilityNodeInfo createAccessibilityNodeInfo(int r15) {
        /*
            r14 = this;
            r0 = 1
            r14.W(r0)
            r1 = 65536(0x10000, float:9.18355E-41)
            if (r15 < r1) goto L_0x000f
            io.flutter.view.AccessibilityViewEmbedder r0 = r14.f665d
            android.view.accessibility.AccessibilityNodeInfo r15 = r0.createAccessibilityNodeInfo(r15)
            return r15
        L_0x000f:
            r2 = -1
            r3 = 0
            if (r15 != r2) goto L_0x0030
            android.view.View r15 = r14.f662a
            android.view.accessibility.AccessibilityNodeInfo r15 = android.view.accessibility.AccessibilityNodeInfo.obtain(r15)
            android.view.View r0 = r14.f662a
            r0.onInitializeAccessibilityNodeInfo(r15)
            java.util.Map<java.lang.Integer, io.flutter.view.j$l> r0 = r14.f668g
            java.lang.Integer r1 = java.lang.Integer.valueOf(r3)
            boolean r0 = r0.containsKey(r1)
            if (r0 == 0) goto L_0x002f
            android.view.View r0 = r14.f662a
            r15.addChild(r0, r3)
        L_0x002f:
            return r15
        L_0x0030:
            java.util.Map<java.lang.Integer, io.flutter.view.j$l> r4 = r14.f668g
            java.lang.Integer r5 = java.lang.Integer.valueOf(r15)
            java.lang.Object r4 = r4.get(r5)
            io.flutter.view.j$l r4 = (io.flutter.view.j.l) r4
            r5 = 0
            if (r4 != 0) goto L_0x0040
            return r5
        L_0x0040:
            int r6 = r4.f763i
            if (r6 == r2) goto L_0x006e
            io.flutter.plugin.platform.q r6 = r14.f666e
            int r7 = r4.f763i
            boolean r6 = r6.c(r7)
            if (r6 == 0) goto L_0x006e
            io.flutter.plugin.platform.q r15 = r14.f666e
            int r0 = r4.f763i
            android.view.View r15 = r15.d(r0)
            if (r15 != 0) goto L_0x005f
            return r5
        L_0x005f:
            android.graphics.Rect r0 = r4.k0()
            io.flutter.view.AccessibilityViewEmbedder r1 = r14.f665d
            int r2 = r4.f756b
            android.view.accessibility.AccessibilityNodeInfo r15 = r1.getRootNode(r15, r2, r0)
            return r15
        L_0x006e:
            android.view.View r5 = r14.f662a
            android.view.accessibility.AccessibilityNodeInfo r5 = r14.I(r5, r15)
            int r6 = android.os.Build.VERSION.SDK_INT
            java.lang.String r7 = ""
            r5.setViewIdResourceName(r7)
            android.view.View r8 = r14.f662a
            android.content.Context r8 = r8.getContext()
            java.lang.String r8 = r8.getPackageName()
            r5.setPackageName(r8)
            java.lang.String r8 = "android.view.View"
            r5.setClassName(r8)
            android.view.View r8 = r14.f662a
            r5.setSource(r8, r15)
            boolean r8 = r4.x0()
            r5.setFocusable(r8)
            io.flutter.view.j$l r8 = r14.f674m
            if (r8 == 0) goto L_0x00a9
            int r8 = r8.f756b
            if (r8 != r15) goto L_0x00a5
            r8 = 1
            goto L_0x00a6
        L_0x00a5:
            r8 = 0
        L_0x00a6:
            r5.setFocused(r8)
        L_0x00a9:
            io.flutter.view.j$l r8 = r14.f670i
            if (r8 == 0) goto L_0x00b9
            int r8 = r8.f756b
            if (r8 != r15) goto L_0x00b5
            r8 = 1
            goto L_0x00b6
        L_0x00b5:
            r8 = 0
        L_0x00b6:
            r5.setAccessibilityFocused(r8)
        L_0x00b9:
            io.flutter.view.j$i r8 = io.flutter.view.j.i.IS_TEXT_FIELD
            boolean r9 = r4.v0(r8)
            r10 = 21
            if (r9 == 0) goto L_0x016c
            io.flutter.view.j$i r9 = io.flutter.view.j.i.IS_OBSCURED
            boolean r9 = r4.v0(r9)
            r5.setPassword(r9)
            io.flutter.view.j$i r9 = io.flutter.view.j.i.IS_READ_ONLY
            boolean r11 = r4.v0(r9)
            if (r11 != 0) goto L_0x00d9
            java.lang.String r11 = "android.widget.EditText"
            r5.setClassName(r11)
        L_0x00d9:
            boolean r9 = r4.v0(r9)
            r9 = r9 ^ r0
            r5.setEditable(r9)
            int r9 = r4.f761g
            if (r9 == r2) goto L_0x00f8
            int r9 = r4.f762h
            if (r9 == r2) goto L_0x00f8
            int r9 = r4.f761g
            int r11 = r4.f762h
            r5.setTextSelection(r9, r11)
        L_0x00f8:
            io.flutter.view.j$l r9 = r14.f670i
            if (r9 == 0) goto L_0x0105
            int r9 = r9.f756b
            if (r9 != r15) goto L_0x0105
            r5.setLiveRegion(r0)
        L_0x0105:
            io.flutter.view.j$g r9 = io.flutter.view.j.g.MOVE_CURSOR_FORWARD_BY_CHARACTER
            boolean r9 = r4.u0(r9)
            r11 = 256(0x100, float:3.59E-43)
            if (r9 == 0) goto L_0x0114
            r5.addAction(r11)
            r9 = 1
            goto L_0x0115
        L_0x0114:
            r9 = 0
        L_0x0115:
            io.flutter.view.j$g r12 = io.flutter.view.j.g.MOVE_CURSOR_BACKWARD_BY_CHARACTER
            boolean r12 = r4.u0(r12)
            r13 = 512(0x200, float:7.175E-43)
            if (r12 == 0) goto L_0x0124
            r5.addAction(r13)
            r9 = r9 | 1
        L_0x0124:
            io.flutter.view.j$g r12 = io.flutter.view.j.g.MOVE_CURSOR_FORWARD_BY_WORD
            boolean r12 = r4.u0(r12)
            if (r12 == 0) goto L_0x0131
            r5.addAction(r11)
            r9 = r9 | 2
        L_0x0131:
            io.flutter.view.j$g r11 = io.flutter.view.j.g.MOVE_CURSOR_BACKWARD_BY_WORD
            boolean r11 = r4.u0(r11)
            if (r11 == 0) goto L_0x013e
            r5.addAction(r13)
            r9 = r9 | 2
        L_0x013e:
            r5.setMovementGranularities(r9)
            if (r6 < r10) goto L_0x016c
            int r9 = r4.f759e
            if (r9 < 0) goto L_0x016c
            java.lang.String r9 = r4.f771q
            if (r9 != 0) goto L_0x0151
            r9 = 0
            goto L_0x0159
        L_0x0151:
            java.lang.String r9 = r4.f771q
            int r9 = r9.length()
        L_0x0159:
            int unused = r4.f760f
            int unused = r4.f759e
            int r11 = r4.f760f
            int r9 = r9 - r11
            int r11 = r4.f759e
            int r9 = r9 + r11
            r5.setMaxTextLength(r9)
        L_0x016c:
            io.flutter.view.j$g r9 = io.flutter.view.j.g.SET_SELECTION
            boolean r9 = r4.u0(r9)
            if (r9 == 0) goto L_0x0179
            r9 = 131072(0x20000, float:1.83671E-40)
            r5.addAction(r9)
        L_0x0179:
            io.flutter.view.j$g r9 = io.flutter.view.j.g.COPY
            boolean r9 = r4.u0(r9)
            if (r9 == 0) goto L_0x0186
            r9 = 16384(0x4000, float:2.2959E-41)
            r5.addAction(r9)
        L_0x0186:
            io.flutter.view.j$g r9 = io.flutter.view.j.g.CUT
            boolean r9 = r4.u0(r9)
            if (r9 == 0) goto L_0x0191
            r5.addAction(r1)
        L_0x0191:
            io.flutter.view.j$g r1 = io.flutter.view.j.g.PASTE
            boolean r1 = r4.u0(r1)
            if (r1 == 0) goto L_0x019f
            r1 = 32768(0x8000, float:4.5918E-41)
            r5.addAction(r1)
        L_0x019f:
            if (r6 < r10) goto L_0x01ae
            io.flutter.view.j$g r1 = io.flutter.view.j.g.SET_TEXT
            boolean r1 = r4.u0(r1)
            if (r1 == 0) goto L_0x01ae
            r1 = 2097152(0x200000, float:2.938736E-39)
            r5.addAction(r1)
        L_0x01ae:
            io.flutter.view.j$i r1 = io.flutter.view.j.i.IS_BUTTON
            boolean r1 = r4.v0(r1)
            if (r1 != 0) goto L_0x01be
            io.flutter.view.j$i r1 = io.flutter.view.j.i.IS_LINK
            boolean r1 = r4.v0(r1)
            if (r1 == 0) goto L_0x01c3
        L_0x01be:
            java.lang.String r1 = "android.widget.Button"
            r5.setClassName(r1)
        L_0x01c3:
            io.flutter.view.j$i r1 = io.flutter.view.j.i.IS_IMAGE
            boolean r1 = r4.v0(r1)
            if (r1 == 0) goto L_0x01d0
            java.lang.String r1 = "android.widget.ImageView"
            r5.setClassName(r1)
        L_0x01d0:
            io.flutter.view.j$g r1 = io.flutter.view.j.g.DISMISS
            boolean r1 = r4.u0(r1)
            if (r1 == 0) goto L_0x01e0
            r5.setDismissable(r0)
            r1 = 1048576(0x100000, float:1.469368E-39)
            r5.addAction(r1)
        L_0x01e0:
            io.flutter.view.j$l r1 = r4.Q
            if (r1 == 0) goto L_0x01f4
            android.view.View r1 = r14.f662a
            io.flutter.view.j$l r9 = r4.Q
            int r9 = r9.f756b
            r5.setParent(r1, r9)
            goto L_0x01f9
        L_0x01f4:
            android.view.View r1 = r14.f662a
            r5.setParent(r1)
        L_0x01f9:
            int r1 = r4.f780z
            if (r1 == r2) goto L_0x020c
            r1 = 22
            if (r6 < r1) goto L_0x020c
            android.view.View r1 = r14.f662a
            int r9 = r4.f780z
            r5.setTraversalAfter(r1, r9)
        L_0x020c:
            android.graphics.Rect r1 = r4.k0()
            io.flutter.view.j$l r9 = r4.Q
            if (r9 == 0) goto L_0x0230
            io.flutter.view.j$l r9 = r4.Q
            android.graphics.Rect r9 = r9.k0()
            android.graphics.Rect r11 = new android.graphics.Rect
            r11.<init>(r1)
            int r12 = r9.left
            int r12 = -r12
            int r9 = r9.top
            int r9 = -r9
            r11.offset(r12, r9)
            r5.setBoundsInParent(r11)
            goto L_0x0233
        L_0x0230:
            r5.setBoundsInParent(r1)
        L_0x0233:
            android.graphics.Rect r1 = r14.y(r1)
            r5.setBoundsInScreen(r1)
            r5.setVisibleToUser(r0)
            io.flutter.view.j$i r1 = io.flutter.view.j.i.HAS_ENABLED_STATE
            boolean r1 = r4.v0(r1)
            if (r1 == 0) goto L_0x0250
            io.flutter.view.j$i r1 = io.flutter.view.j.i.IS_ENABLED
            boolean r1 = r4.v0(r1)
            if (r1 == 0) goto L_0x024e
            goto L_0x0250
        L_0x024e:
            r1 = 0
            goto L_0x0251
        L_0x0250:
            r1 = 1
        L_0x0251:
            r5.setEnabled(r1)
            io.flutter.view.j$g r1 = io.flutter.view.j.g.TAP
            boolean r1 = r4.u0(r1)
            if (r1 == 0) goto L_0x027d
            r1 = 16
            if (r6 < r10) goto L_0x0277
            io.flutter.view.j$h r9 = r4.U
            if (r9 == 0) goto L_0x0277
            android.view.accessibility.AccessibilityNodeInfo$AccessibilityAction r9 = new android.view.accessibility.AccessibilityNodeInfo$AccessibilityAction
            io.flutter.view.j$h r11 = r4.U
            java.lang.String r11 = r11.f729e
            r9.<init>(r1, r11)
            r5.addAction(r9)
            goto L_0x027a
        L_0x0277:
            r5.addAction(r1)
        L_0x027a:
            r5.setClickable(r0)
        L_0x027d:
            io.flutter.view.j$g r1 = io.flutter.view.j.g.LONG_PRESS
            boolean r1 = r4.u0(r1)
            if (r1 == 0) goto L_0x02a6
            r1 = 32
            if (r6 < r10) goto L_0x02a0
            io.flutter.view.j$h r9 = r4.V
            if (r9 == 0) goto L_0x02a0
            android.view.accessibility.AccessibilityNodeInfo$AccessibilityAction r9 = new android.view.accessibility.AccessibilityNodeInfo$AccessibilityAction
            io.flutter.view.j$h r11 = r4.V
            java.lang.String r11 = r11.f729e
            r9.<init>(r1, r11)
            r5.addAction(r9)
            goto L_0x02a3
        L_0x02a0:
            r5.addAction(r1)
        L_0x02a3:
            r5.setLongClickable(r0)
        L_0x02a6:
            io.flutter.view.j$g r1 = io.flutter.view.j.g.SCROLL_LEFT
            boolean r9 = r4.u0(r1)
            r11 = 8192(0x2000, float:1.14794E-41)
            r12 = 4096(0x1000, float:5.74E-42)
            if (r9 != 0) goto L_0x02ca
            io.flutter.view.j$g r9 = io.flutter.view.j.g.SCROLL_UP
            boolean r9 = r4.u0(r9)
            if (r9 != 0) goto L_0x02ca
            io.flutter.view.j$g r9 = io.flutter.view.j.g.SCROLL_RIGHT
            boolean r9 = r4.u0(r9)
            if (r9 != 0) goto L_0x02ca
            io.flutter.view.j$g r9 = io.flutter.view.j.g.SCROLL_DOWN
            boolean r9 = r4.u0(r9)
            if (r9 == 0) goto L_0x0335
        L_0x02ca:
            r5.setScrollable(r0)
            io.flutter.view.j$i r9 = io.flutter.view.j.i.HAS_IMPLICIT_SCROLLING
            boolean r9 = r4.v0(r9)
            if (r9 == 0) goto L_0x0311
            boolean r9 = r4.u0(r1)
            if (r9 != 0) goto L_0x02f6
            io.flutter.view.j$g r9 = io.flutter.view.j.g.SCROLL_RIGHT
            boolean r9 = r4.u0(r9)
            if (r9 == 0) goto L_0x02e4
            goto L_0x02f6
        L_0x02e4:
            boolean r9 = r14.Z(r4)
            if (r9 == 0) goto L_0x02f3
            int r9 = r4.f764j
            android.view.accessibility.AccessibilityNodeInfo$CollectionInfo r9 = android.view.accessibility.AccessibilityNodeInfo.CollectionInfo.obtain(r9, r3, r3)
            goto L_0x0308
        L_0x02f3:
            java.lang.String r9 = "android.widget.ScrollView"
            goto L_0x030e
        L_0x02f6:
            r9 = 19
            if (r6 <= r9) goto L_0x030c
            boolean r9 = r14.Z(r4)
            if (r9 == 0) goto L_0x030c
            int r9 = r4.f764j
            android.view.accessibility.AccessibilityNodeInfo$CollectionInfo r9 = android.view.accessibility.AccessibilityNodeInfo.CollectionInfo.obtain(r3, r9, r3)
        L_0x0308:
            r5.setCollectionInfo(r9)
            goto L_0x0311
        L_0x030c:
            java.lang.String r9 = "android.widget.HorizontalScrollView"
        L_0x030e:
            r5.setClassName(r9)
        L_0x0311:
            boolean r1 = r4.u0(r1)
            if (r1 != 0) goto L_0x031f
            io.flutter.view.j$g r1 = io.flutter.view.j.g.SCROLL_UP
            boolean r1 = r4.u0(r1)
            if (r1 == 0) goto L_0x0322
        L_0x031f:
            r5.addAction(r12)
        L_0x0322:
            io.flutter.view.j$g r1 = io.flutter.view.j.g.SCROLL_RIGHT
            boolean r1 = r4.u0(r1)
            if (r1 != 0) goto L_0x0332
            io.flutter.view.j$g r1 = io.flutter.view.j.g.SCROLL_DOWN
            boolean r1 = r4.u0(r1)
            if (r1 == 0) goto L_0x0335
        L_0x0332:
            r5.addAction(r11)
        L_0x0335:
            io.flutter.view.j$g r1 = io.flutter.view.j.g.INCREASE
            boolean r9 = r4.u0(r1)
            if (r9 != 0) goto L_0x0345
            io.flutter.view.j$g r9 = io.flutter.view.j.g.DECREASE
            boolean r9 = r4.u0(r9)
            if (r9 == 0) goto L_0x035e
        L_0x0345:
            java.lang.String r9 = "android.widget.SeekBar"
            r5.setClassName(r9)
            boolean r1 = r4.u0(r1)
            if (r1 == 0) goto L_0x0353
            r5.addAction(r12)
        L_0x0353:
            io.flutter.view.j$g r1 = io.flutter.view.j.g.DECREASE
            boolean r1 = r4.u0(r1)
            if (r1 == 0) goto L_0x035e
            r5.addAction(r11)
        L_0x035e:
            io.flutter.view.j$i r1 = io.flutter.view.j.i.IS_LIVE_REGION
            boolean r1 = r4.v0(r1)
            if (r1 == 0) goto L_0x0369
            r5.setLiveRegion(r0)
        L_0x0369:
            boolean r1 = r4.v0(r8)
            r8 = 28
            if (r1 == 0) goto L_0x0382
            java.lang.CharSequence r1 = r4.q0()
            r5.setText(r1)
            if (r6 < r8) goto L_0x03b6
            java.lang.CharSequence r1 = r4.p0()
            r5.setHintText(r1)
            goto L_0x03b6
        L_0x0382:
            io.flutter.view.j$i r1 = io.flutter.view.j.i.SCOPES_ROUTE
            boolean r1 = r4.v0(r1)
            if (r1 != 0) goto L_0x03b6
            java.lang.CharSequence r1 = r4.r0()
            if (r6 >= r8) goto L_0x03b1
            java.lang.String r9 = r4.f779y
            if (r9 == 0) goto L_0x03b1
            if (r1 == 0) goto L_0x0399
            r7 = r1
        L_0x0399:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r7)
            java.lang.String r7 = "\n"
            r1.append(r7)
            java.lang.String r7 = r4.f779y
            r1.append(r7)
            java.lang.String r1 = r1.toString()
        L_0x03b1:
            if (r1 == 0) goto L_0x03b6
            r5.setContentDescription(r1)
        L_0x03b6:
            if (r6 < r8) goto L_0x03c5
            java.lang.String r1 = r4.f779y
            if (r1 == 0) goto L_0x03c5
            java.lang.String r1 = r4.f779y
            r5.setTooltipText(r1)
        L_0x03c5:
            io.flutter.view.j$i r1 = io.flutter.view.j.i.HAS_CHECKED_STATE
            boolean r1 = r4.v0(r1)
            io.flutter.view.j$i r7 = io.flutter.view.j.i.HAS_TOGGLED_STATE
            boolean r7 = r4.v0(r7)
            if (r1 != 0) goto L_0x03d7
            if (r7 == 0) goto L_0x03d6
            goto L_0x03d7
        L_0x03d6:
            r0 = 0
        L_0x03d7:
            r5.setCheckable(r0)
            if (r1 == 0) goto L_0x03f3
            io.flutter.view.j$i r0 = io.flutter.view.j.i.IS_CHECKED
            boolean r0 = r4.v0(r0)
            r5.setChecked(r0)
            io.flutter.view.j$i r0 = io.flutter.view.j.i.IS_IN_MUTUALLY_EXCLUSIVE_GROUP
            boolean r0 = r4.v0(r0)
            if (r0 == 0) goto L_0x03f0
            java.lang.String r0 = "android.widget.RadioButton"
            goto L_0x0400
        L_0x03f0:
            java.lang.String r0 = "android.widget.CheckBox"
            goto L_0x0400
        L_0x03f3:
            if (r7 == 0) goto L_0x0403
            io.flutter.view.j$i r0 = io.flutter.view.j.i.IS_TOGGLED
            boolean r0 = r4.v0(r0)
            r5.setChecked(r0)
            java.lang.String r0 = "android.widget.Switch"
        L_0x0400:
            r5.setClassName(r0)
        L_0x0403:
            io.flutter.view.j$i r0 = io.flutter.view.j.i.IS_SELECTED
            boolean r0 = r4.v0(r0)
            r5.setSelected(r0)
            if (r6 < r8) goto L_0x0417
            io.flutter.view.j$i r0 = io.flutter.view.j.i.IS_HEADER
            boolean r0 = r4.v0(r0)
            r5.setHeading(r0)
        L_0x0417:
            io.flutter.view.j$l r0 = r14.f670i
            if (r0 == 0) goto L_0x0424
            int r0 = r0.f756b
            if (r0 != r15) goto L_0x0424
            r15 = 128(0x80, float:1.794E-43)
            goto L_0x0426
        L_0x0424:
            r15 = 64
        L_0x0426:
            r5.addAction(r15)
            if (r6 < r10) goto L_0x0456
            java.util.List r15 = r4.T
            if (r15 == 0) goto L_0x0456
            java.util.List r15 = r4.T
            java.util.Iterator r15 = r15.iterator()
        L_0x0439:
            boolean r0 = r15.hasNext()
            if (r0 == 0) goto L_0x0456
            java.lang.Object r0 = r15.next()
            io.flutter.view.j$h r0 = (io.flutter.view.j.h) r0
            android.view.accessibility.AccessibilityNodeInfo$AccessibilityAction r1 = new android.view.accessibility.AccessibilityNodeInfo$AccessibilityAction
            int r3 = r0.f725a
            java.lang.String r0 = r0.f728d
            r1.<init>(r3, r0)
            r5.addAction(r1)
            goto L_0x0439
        L_0x0456:
            java.util.List r15 = r4.R
            java.util.Iterator r15 = r15.iterator()
        L_0x045e:
            boolean r0 = r15.hasNext()
            if (r0 == 0) goto L_0x049d
            java.lang.Object r0 = r15.next()
            io.flutter.view.j$l r0 = (io.flutter.view.j.l) r0
            io.flutter.view.j$i r1 = io.flutter.view.j.i.IS_HIDDEN
            boolean r1 = r0.v0(r1)
            if (r1 == 0) goto L_0x0473
            goto L_0x045e
        L_0x0473:
            int r1 = r0.f763i
            if (r1 == r2) goto L_0x0493
            io.flutter.plugin.platform.q r1 = r14.f666e
            int r3 = r0.f763i
            android.view.View r1 = r1.d(r3)
            io.flutter.plugin.platform.q r3 = r14.f666e
            int r4 = r0.f763i
            boolean r3 = r3.c(r4)
            if (r3 != 0) goto L_0x0493
            r5.addChild(r1)
            goto L_0x045e
        L_0x0493:
            android.view.View r1 = r14.f662a
            int r0 = r0.f756b
            r5.addChild(r1, r0)
            goto L_0x045e
        L_0x049d:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: io.flutter.view.j.createAccessibilityNodeInfo(int):android.view.accessibility.AccessibilityNodeInfo");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0016, code lost:
        if (r2 != null) goto L_0x0018;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.accessibility.AccessibilityNodeInfo findFocus(int r2) {
        /*
            r1 = this;
            r0 = 1
            if (r2 == r0) goto L_0x0007
            r0 = 2
            if (r2 == r0) goto L_0x001d
            goto L_0x0027
        L_0x0007:
            io.flutter.view.j$l r2 = r1.f674m
            if (r2 == 0) goto L_0x0014
        L_0x000b:
            int r2 = r2.f756b
        L_0x000f:
            android.view.accessibility.AccessibilityNodeInfo r2 = r1.createAccessibilityNodeInfo(r2)
            return r2
        L_0x0014:
            java.lang.Integer r2 = r1.f672k
            if (r2 == 0) goto L_0x001d
        L_0x0018:
            int r2 = r2.intValue()
            goto L_0x000f
        L_0x001d:
            io.flutter.view.j$l r2 = r1.f670i
            if (r2 == 0) goto L_0x0022
            goto L_0x000b
        L_0x0022:
            java.lang.Integer r2 = r1.f671j
            if (r2 == 0) goto L_0x0027
            goto L_0x0018
        L_0x0027:
            r2 = 0
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: io.flutter.view.j.findFocus(int):android.view.accessibility.AccessibilityNodeInfo");
    }

    public boolean performAction(int i2, int i3, Bundle bundle) {
        int i4;
        if (i2 >= 65536) {
            boolean performAction = this.f665d.performAction(i2, i3, bundle);
            if (performAction && i3 == 128) {
                this.f671j = null;
            }
            return performAction;
        }
        l lVar = this.f668g.get(Integer.valueOf(i2));
        boolean z2 = false;
        if (lVar == null) {
            return false;
        }
        switch (i3) {
            case 16:
                this.f663b.b(i2, g.TAP);
                return true;
            case 32:
                this.f663b.b(i2, g.LONG_PRESS);
                return true;
            case 64:
                if (this.f670i == null) {
                    this.f662a.invalidate();
                }
                this.f670i = lVar;
                this.f663b.b(i2, g.DID_GAIN_ACCESSIBILITY_FOCUS);
                R(i2, 32768);
                if (lVar.u0(g.INCREASE) || lVar.u0(g.DECREASE)) {
                    R(i2, 4);
                }
                return true;
            case 128:
                l lVar2 = this.f670i;
                if (lVar2 != null && lVar2.f756b == i2) {
                    this.f670i = null;
                }
                Integer num = this.f671j;
                if (num != null && num.intValue() == i2) {
                    this.f671j = null;
                }
                this.f663b.b(i2, g.DID_LOSE_ACCESSIBILITY_FOCUS);
                R(i2, 65536);
                return true;
            case 256:
                return N(lVar, i2, bundle, true);
            case 512:
                return N(lVar, i2, bundle, false);
            case 4096:
                g gVar = g.SCROLL_UP;
                if (!lVar.u0(gVar)) {
                    gVar = g.SCROLL_LEFT;
                    if (!lVar.u0(gVar)) {
                        gVar = g.INCREASE;
                        if (!lVar.u0(gVar)) {
                            return false;
                        }
                        String unused = lVar.f771q = lVar.f773s;
                        List unused2 = lVar.f772r = lVar.f774t;
                        R(i2, 4);
                    }
                }
                this.f663b.b(i2, gVar);
                return true;
            case 8192:
                g gVar2 = g.SCROLL_DOWN;
                if (!lVar.u0(gVar2)) {
                    gVar2 = g.SCROLL_RIGHT;
                    if (!lVar.u0(gVar2)) {
                        gVar2 = g.DECREASE;
                        if (!lVar.u0(gVar2)) {
                            return false;
                        }
                        String unused3 = lVar.f771q = lVar.f775u;
                        List unused4 = lVar.f772r = lVar.f776v;
                        R(i2, 4);
                    }
                }
                this.f663b.b(i2, gVar2);
                return true;
            case 16384:
                this.f663b.b(i2, g.COPY);
                return true;
            case 32768:
                this.f663b.b(i2, g.PASTE);
                return true;
            case 65536:
                this.f663b.b(i2, g.CUT);
                return true;
            case 131072:
                HashMap hashMap = new HashMap();
                if (bundle != null && bundle.containsKey("ACTION_ARGUMENT_SELECTION_START_INT") && bundle.containsKey("ACTION_ARGUMENT_SELECTION_END_INT")) {
                    z2 = true;
                }
                if (z2) {
                    hashMap.put("base", Integer.valueOf(bundle.getInt("ACTION_ARGUMENT_SELECTION_START_INT")));
                    i4 = bundle.getInt("ACTION_ARGUMENT_SELECTION_END_INT");
                } else {
                    hashMap.put("base", Integer.valueOf(lVar.f762h));
                    i4 = lVar.f762h;
                }
                hashMap.put("extent", Integer.valueOf(i4));
                this.f663b.c(i2, g.SET_SELECTION, hashMap);
                l lVar3 = this.f668g.get(Integer.valueOf(i2));
                int unused5 = lVar3.f761g = ((Integer) hashMap.get("base")).intValue();
                int unused6 = lVar3.f762h = ((Integer) hashMap.get("extent")).intValue();
                return true;
            case 1048576:
                this.f663b.b(i2, g.DISMISS);
                return true;
            case 2097152:
                if (Build.VERSION.SDK_INT < 21) {
                    return false;
                }
                return O(lVar, i2, bundle);
            case 16908342:
                this.f663b.b(i2, g.SHOW_ON_SCREEN);
                return true;
            default:
                h hVar = this.f669h.get(Integer.valueOf(i3 - B));
                if (hVar == null) {
                    return false;
                }
                this.f663b.c(i2, g.CUSTOM_ACTION, Integer.valueOf(hVar.f726b));
                return true;
        }
    }

    @SuppressLint({"SwitchIntDef"})
    public boolean x(View view, View view2, AccessibilityEvent accessibilityEvent) {
        Integer recordFlutterId;
        if (!this.f665d.requestSendAccessibilityEvent(view, view2, accessibilityEvent) || (recordFlutterId = this.f665d.getRecordFlutterId(view, accessibilityEvent)) == null) {
            return false;
        }
        int eventType = accessibilityEvent.getEventType();
        if (eventType == 8) {
            this.f672k = recordFlutterId;
            this.f674m = null;
            return true;
        } else if (eventType == 128) {
            this.f676o = null;
            return true;
        } else if (eventType == 32768) {
            this.f671j = recordFlutterId;
            this.f670i = null;
            return true;
        } else if (eventType != 65536) {
            return true;
        } else {
            this.f672k = null;
            this.f671j = null;
            return true;
        }
    }
}
