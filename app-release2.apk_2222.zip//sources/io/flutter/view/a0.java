package io.flutter.view;

import android.annotation.TargetApi;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.view.Choreographer;
import io.flutter.embedding.engine.FlutterJNI;
import java.util.Objects;

public class a0 {

    /* renamed from: e  reason: collision with root package name */
    private static a0 f649e;

    /* renamed from: f  reason: collision with root package name */
    private static b f650f;
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public long f651a = -1;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public FlutterJNI f652b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public c f653c = new c(0);

    /* renamed from: d  reason: collision with root package name */
    private final FlutterJNI.b f654d = new a();

    class a implements FlutterJNI.b {
        a() {
        }

        private Choreographer.FrameCallback b(long j2) {
            if (a0.this.f653c == null) {
                return new c(j2);
            }
            long unused = a0.this.f653c.f658a = j2;
            c d2 = a0.this.f653c;
            c unused2 = a0.this.f653c = null;
            return d2;
        }

        public void a(long j2) {
            Choreographer.getInstance().postFrameCallback(b(j2));
        }
    }

    @TargetApi(17)
    class b implements DisplayManager.DisplayListener {

        /* renamed from: a  reason: collision with root package name */
        private DisplayManager f656a;

        b(DisplayManager displayManager) {
            this.f656a = displayManager;
        }

        /* access modifiers changed from: package-private */
        public void a() {
            this.f656a.registerDisplayListener(this, (Handler) null);
        }

        public void onDisplayAdded(int i2) {
        }

        public void onDisplayChanged(int i2) {
            if (i2 == 0) {
                float refreshRate = this.f656a.getDisplay(0).getRefreshRate();
                a0 a0Var = a0.this;
                double d2 = (double) refreshRate;
                Double.isNaN(d2);
                long unused = a0Var.f651a = (long) (1.0E9d / d2);
                a0.this.f652b.setRefreshRateFPS(refreshRate);
            }
        }

        public void onDisplayRemoved(int i2) {
        }
    }

    private class c implements Choreographer.FrameCallback {
        /* access modifiers changed from: private */

        /* renamed from: a  reason: collision with root package name */
        public long f658a;

        c(long j2) {
            this.f658a = j2;
        }

        public void doFrame(long j2) {
            long nanoTime = System.nanoTime() - j2;
            a0.this.f652b.onVsync(nanoTime < 0 ? 0 : nanoTime, a0.this.f651a, this.f658a);
            c unused = a0.this.f653c = this;
        }
    }

    private a0(FlutterJNI flutterJNI) {
        this.f652b = flutterJNI;
    }

    @TargetApi(17)
    public static a0 f(DisplayManager displayManager, FlutterJNI flutterJNI) {
        if (f649e == null) {
            f649e = new a0(flutterJNI);
        }
        if (f650f == null) {
            a0 a0Var = f649e;
            Objects.requireNonNull(a0Var);
            b bVar = new b(displayManager);
            f650f = bVar;
            bVar.a();
        }
        if (f649e.f651a == -1) {
            float refreshRate = displayManager.getDisplay(0).getRefreshRate();
            a0 a0Var2 = f649e;
            double d2 = (double) refreshRate;
            Double.isNaN(d2);
            a0Var2.f651a = (long) (1.0E9d / d2);
            flutterJNI.setRefreshRateFPS(refreshRate);
        }
        return f649e;
    }

    public void g() {
        this.f652b.setAsyncWaitForVsyncDelegate(this.f654d);
    }
}
