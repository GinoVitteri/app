package io.flutter.view;

import d0.f;
import io.flutter.view.j;

public final /* synthetic */ class h implements f {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ j.l f660a;

    public /* synthetic */ h(j.l lVar) {
        this.f660a = lVar;
    }

    public final boolean test(Object obj) {
        return j.F(this.f660a, (j.l) obj);
    }
}
