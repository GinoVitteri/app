package io.flutter.view;

import android.graphics.SurfaceTexture;

public interface z {

    public interface a {
        void a();
    }

    public interface b {
        void onTrimMemory(int i2);
    }

    public interface c {
        long a();

        void b(b bVar);

        void c(a aVar);

        SurfaceTexture d();
    }

    c a();
}
