package a0;

import io.flutter.embedding.android.a0;
import java.util.Map;
import y.e;

public class a implements e.b {

    /* renamed from: a  reason: collision with root package name */
    private final e f14a;

    /* renamed from: b  reason: collision with root package name */
    private final a0 f15b;

    public a(a0 a0Var, e eVar) {
        this.f15b = a0Var;
        this.f14a = eVar;
        eVar.b(this);
    }

    public Map<Long, Long> a() {
        return this.f15b.d();
    }

    public void b() {
        this.f14a.b((e.b) null);
    }
}
