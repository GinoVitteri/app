package i;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

public class f {

    /* renamed from: b  reason: collision with root package name */
    public static final f f179b = (Build.VERSION.SDK_INT >= 30 ? k.f210r : l.f211b);

    /* renamed from: a  reason: collision with root package name */
    private final l f180a;

    static class a {

        /* renamed from: a  reason: collision with root package name */
        private static Field f181a;

        /* renamed from: b  reason: collision with root package name */
        private static Field f182b;

        /* renamed from: c  reason: collision with root package name */
        private static Field f183c;

        /* renamed from: d  reason: collision with root package name */
        private static boolean f184d = true;

        static {
            try {
                Field declaredField = View.class.getDeclaredField("mAttachInfo");
                f181a = declaredField;
                declaredField.setAccessible(true);
                Class<?> cls = Class.forName("android.view.View$AttachInfo");
                Field declaredField2 = cls.getDeclaredField("mStableInsets");
                f182b = declaredField2;
                declaredField2.setAccessible(true);
                Field declaredField3 = cls.getDeclaredField("mContentInsets");
                f183c = declaredField3;
                declaredField3.setAccessible(true);
            } catch (ReflectiveOperationException e2) {
                Log.w("WindowInsetsCompat", "Failed to get visible insets from AttachInfo " + e2.getMessage(), e2);
            }
        }

        public static f a(View view) {
            if (f184d && view.isAttachedToWindow()) {
                try {
                    Object obj = f181a.get(view.getRootView());
                    if (obj != null) {
                        Rect rect = (Rect) f182b.get(obj);
                        Rect rect2 = (Rect) f183c.get(obj);
                        if (!(rect == null || rect2 == null)) {
                            f a2 = new b().b(e.a.c(rect)).c(e.a.c(rect2)).a();
                            a2.k(a2);
                            a2.d(view.getRootView());
                            return a2;
                        }
                    }
                } catch (IllegalAccessException e2) {
                    Log.w("WindowInsetsCompat", "Failed to get insets from AttachInfo. " + e2.getMessage(), e2);
                }
            }
            return null;
        }
    }

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        private final C0007f f185a;

        public b() {
            int i2 = Build.VERSION.SDK_INT;
            this.f185a = i2 >= 30 ? new e() : i2 >= 29 ? new d() : i2 >= 20 ? new c() : new C0007f();
        }

        public f a() {
            return this.f185a.b();
        }

        @Deprecated
        public b b(e.a aVar) {
            this.f185a.d(aVar);
            return this;
        }

        @Deprecated
        public b c(e.a aVar) {
            this.f185a.f(aVar);
            return this;
        }
    }

    private static class c extends C0007f {

        /* renamed from: e  reason: collision with root package name */
        private static Field f186e = null;

        /* renamed from: f  reason: collision with root package name */
        private static boolean f187f = false;

        /* renamed from: g  reason: collision with root package name */
        private static Constructor<WindowInsets> f188g = null;

        /* renamed from: h  reason: collision with root package name */
        private static boolean f189h = false;

        /* renamed from: c  reason: collision with root package name */
        private WindowInsets f190c = h();

        /* renamed from: d  reason: collision with root package name */
        private e.a f191d;

        c() {
        }

        private static WindowInsets h() {
            if (!f187f) {
                try {
                    f186e = WindowInsets.class.getDeclaredField("CONSUMED");
                } catch (ReflectiveOperationException e2) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e2);
                }
                f187f = true;
            }
            Field field = f186e;
            if (field != null) {
                try {
                    WindowInsets windowInsets = (WindowInsets) field.get((Object) null);
                    if (windowInsets != null) {
                        return new WindowInsets(windowInsets);
                    }
                } catch (ReflectiveOperationException e3) {
                    Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e3);
                }
            }
            if (!f189h) {
                try {
                    f188g = WindowInsets.class.getConstructor(new Class[]{Rect.class});
                } catch (ReflectiveOperationException e4) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e4);
                }
                f189h = true;
            }
            Constructor<WindowInsets> constructor = f188g;
            if (constructor != null) {
                try {
                    return constructor.newInstance(new Object[]{new Rect()});
                } catch (ReflectiveOperationException e5) {
                    Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e5);
                }
            }
            return null;
        }

        /* access modifiers changed from: package-private */
        public f b() {
            a();
            f m2 = f.m(this.f190c);
            m2.i(this.f194b);
            m2.l(this.f191d);
            return m2;
        }

        /* access modifiers changed from: package-private */
        public void d(e.a aVar) {
            this.f191d = aVar;
        }

        /* access modifiers changed from: package-private */
        public void f(e.a aVar) {
            WindowInsets windowInsets = this.f190c;
            if (windowInsets != null) {
                this.f190c = windowInsets.replaceSystemWindowInsets(aVar.f135a, aVar.f136b, aVar.f137c, aVar.f138d);
            }
        }
    }

    private static class d extends C0007f {

        /* renamed from: c  reason: collision with root package name */
        final WindowInsets.Builder f192c = new WindowInsets.Builder();

        d() {
        }

        /* access modifiers changed from: package-private */
        public f b() {
            a();
            f m2 = f.m(this.f192c.build());
            m2.i(this.f194b);
            return m2;
        }

        /* access modifiers changed from: package-private */
        public void c(e.a aVar) {
            this.f192c.setMandatorySystemGestureInsets(aVar.e());
        }

        /* access modifiers changed from: package-private */
        public void d(e.a aVar) {
            this.f192c.setStableInsets(aVar.e());
        }

        /* access modifiers changed from: package-private */
        public void e(e.a aVar) {
            this.f192c.setSystemGestureInsets(aVar.e());
        }

        /* access modifiers changed from: package-private */
        public void f(e.a aVar) {
            this.f192c.setSystemWindowInsets(aVar.e());
        }

        /* access modifiers changed from: package-private */
        public void g(e.a aVar) {
            this.f192c.setTappableElementInsets(aVar.e());
        }
    }

    private static class e extends d {
        e() {
        }
    }

    /* renamed from: i.f$f  reason: collision with other inner class name */
    private static class C0007f {

        /* renamed from: a  reason: collision with root package name */
        private final f f193a;

        /* renamed from: b  reason: collision with root package name */
        e.a[] f194b;

        C0007f() {
            this(new f((f) null));
        }

        C0007f(f fVar) {
            this.f193a = fVar;
        }

        /* access modifiers changed from: protected */
        public final void a() {
            e.a[] aVarArr = this.f194b;
            if (aVarArr != null) {
                e.a aVar = aVarArr[m.b(1)];
                e.a aVar2 = this.f194b[m.b(2)];
                if (aVar2 == null) {
                    aVar2 = this.f193a.f(2);
                }
                if (aVar == null) {
                    aVar = this.f193a.f(1);
                }
                f(e.a.a(aVar, aVar2));
                e.a aVar3 = this.f194b[m.b(16)];
                if (aVar3 != null) {
                    e(aVar3);
                }
                e.a aVar4 = this.f194b[m.b(32)];
                if (aVar4 != null) {
                    c(aVar4);
                }
                e.a aVar5 = this.f194b[m.b(64)];
                if (aVar5 != null) {
                    g(aVar5);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public f b() {
            a();
            return this.f193a;
        }

        /* access modifiers changed from: package-private */
        public void c(e.a aVar) {
        }

        /* access modifiers changed from: package-private */
        public void d(e.a aVar) {
        }

        /* access modifiers changed from: package-private */
        public void e(e.a aVar) {
        }

        /* access modifiers changed from: package-private */
        public void f(e.a aVar) {
        }

        /* access modifiers changed from: package-private */
        public void g(e.a aVar) {
        }
    }

    private static class g extends l {

        /* renamed from: h  reason: collision with root package name */
        private static boolean f195h = false;

        /* renamed from: i  reason: collision with root package name */
        private static Method f196i;

        /* renamed from: j  reason: collision with root package name */
        private static Class<?> f197j;

        /* renamed from: k  reason: collision with root package name */
        private static Class<?> f198k;

        /* renamed from: l  reason: collision with root package name */
        private static Field f199l;

        /* renamed from: m  reason: collision with root package name */
        private static Field f200m;

        /* renamed from: c  reason: collision with root package name */
        final WindowInsets f201c;

        /* renamed from: d  reason: collision with root package name */
        private e.a[] f202d;

        /* renamed from: e  reason: collision with root package name */
        private e.a f203e;

        /* renamed from: f  reason: collision with root package name */
        private f f204f;

        /* renamed from: g  reason: collision with root package name */
        e.a f205g;

        g(f fVar, WindowInsets windowInsets) {
            super(fVar);
            this.f203e = null;
            this.f201c = windowInsets;
        }

        g(f fVar, g gVar) {
            this(fVar, new WindowInsets(gVar.f201c));
        }

        @SuppressLint({"WrongConstant"})
        private e.a t(int i2, boolean z2) {
            e.a aVar = e.a.f134e;
            for (int i3 = 1; i3 <= 256; i3 <<= 1) {
                if ((i2 & i3) != 0) {
                    aVar = e.a.a(aVar, u(i3, z2));
                }
            }
            return aVar;
        }

        private e.a v() {
            f fVar = this.f204f;
            return fVar != null ? fVar.g() : e.a.f134e;
        }

        private e.a w(View view) {
            if (Build.VERSION.SDK_INT < 30) {
                if (!f195h) {
                    y();
                }
                Method method = f196i;
                if (!(method == null || f198k == null || f199l == null)) {
                    try {
                        Object invoke = method.invoke(view, new Object[0]);
                        if (invoke == null) {
                            Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                            return null;
                        }
                        Rect rect = (Rect) f199l.get(f200m.get(invoke));
                        if (rect != null) {
                            return e.a.c(rect);
                        }
                        return null;
                    } catch (ReflectiveOperationException e2) {
                        Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
                    }
                }
                return null;
            }
            throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
        }

        @SuppressLint({"PrivateApi"})
        private static void y() {
            try {
                f196i = View.class.getDeclaredMethod("getViewRootImpl", new Class[0]);
                f197j = Class.forName("android.view.ViewRootImpl");
                Class<?> cls = Class.forName("android.view.View$AttachInfo");
                f198k = cls;
                f199l = cls.getDeclaredField("mVisibleInsets");
                f200m = f197j.getDeclaredField("mAttachInfo");
                f199l.setAccessible(true);
                f200m.setAccessible(true);
            } catch (ReflectiveOperationException e2) {
                Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
            }
            f195h = true;
        }

        /* access modifiers changed from: package-private */
        public void d(View view) {
            e.a w2 = w(view);
            if (w2 == null) {
                w2 = e.a.f134e;
            }
            q(w2);
        }

        /* access modifiers changed from: package-private */
        public void e(f fVar) {
            fVar.k(this.f204f);
            fVar.j(this.f205g);
        }

        public boolean equals(Object obj) {
            if (!super.equals(obj)) {
                return false;
            }
            return Objects.equals(this.f205g, ((g) obj).f205g);
        }

        public e.a g(int i2) {
            return t(i2, false);
        }

        /* access modifiers changed from: package-private */
        public final e.a k() {
            if (this.f203e == null) {
                this.f203e = e.a.b(this.f201c.getSystemWindowInsetLeft(), this.f201c.getSystemWindowInsetTop(), this.f201c.getSystemWindowInsetRight(), this.f201c.getSystemWindowInsetBottom());
            }
            return this.f203e;
        }

        /* access modifiers changed from: package-private */
        public boolean n() {
            return this.f201c.isRound();
        }

        /* access modifiers changed from: package-private */
        @SuppressLint({"WrongConstant"})
        public boolean o(int i2) {
            for (int i3 = 1; i3 <= 256; i3 <<= 1) {
                if ((i2 & i3) != 0 && !x(i3)) {
                    return false;
                }
            }
            return true;
        }

        public void p(e.a[] aVarArr) {
            this.f202d = aVarArr;
        }

        /* access modifiers changed from: package-private */
        public void q(e.a aVar) {
            this.f205g = aVar;
        }

        /* access modifiers changed from: package-private */
        public void r(f fVar) {
            this.f204f = fVar;
        }

        /* access modifiers changed from: protected */
        public e.a u(int i2, boolean z2) {
            int i3;
            if (i2 == 1) {
                return z2 ? e.a.b(0, Math.max(v().f136b, k().f136b), 0, 0) : e.a.b(0, k().f136b, 0, 0);
            }
            e.a aVar = null;
            if (i2 != 2) {
                if (i2 == 8) {
                    e.a[] aVarArr = this.f202d;
                    if (aVarArr != null) {
                        aVar = aVarArr[m.b(8)];
                    }
                    if (aVar != null) {
                        return aVar;
                    }
                    e.a k2 = k();
                    e.a v2 = v();
                    int i4 = k2.f138d;
                    if (i4 > v2.f138d) {
                        return e.a.b(0, 0, 0, i4);
                    }
                    e.a aVar2 = this.f205g;
                    return (aVar2 == null || aVar2.equals(e.a.f134e) || (i3 = this.f205g.f138d) <= v2.f138d) ? e.a.f134e : e.a.b(0, 0, 0, i3);
                } else if (i2 == 16) {
                    return j();
                } else {
                    if (i2 == 32) {
                        return h();
                    }
                    if (i2 == 64) {
                        return l();
                    }
                    if (i2 != 128) {
                        return e.a.f134e;
                    }
                    f fVar = this.f204f;
                    a e2 = fVar != null ? fVar.e() : f();
                    return e2 != null ? e.a.b(e2.b(), e2.d(), e2.c(), e2.a()) : e.a.f134e;
                }
            } else if (z2) {
                e.a v3 = v();
                e.a i5 = i();
                return e.a.b(Math.max(v3.f135a, i5.f135a), 0, Math.max(v3.f137c, i5.f137c), Math.max(v3.f138d, i5.f138d));
            } else {
                e.a k3 = k();
                f fVar2 = this.f204f;
                if (fVar2 != null) {
                    aVar = fVar2.g();
                }
                int i6 = k3.f138d;
                if (aVar != null) {
                    i6 = Math.min(i6, aVar.f138d);
                }
                return e.a.b(k3.f135a, 0, k3.f137c, i6);
            }
        }

        /* access modifiers changed from: protected */
        public boolean x(int i2) {
            if (!(i2 == 1 || i2 == 2)) {
                if (i2 == 4) {
                    return false;
                }
                if (!(i2 == 8 || i2 == 128)) {
                    return true;
                }
            }
            return !u(i2, false).equals(e.a.f134e);
        }
    }

    private static class h extends g {

        /* renamed from: n  reason: collision with root package name */
        private e.a f206n = null;

        h(f fVar, WindowInsets windowInsets) {
            super(fVar, windowInsets);
        }

        h(f fVar, h hVar) {
            super(fVar, (g) hVar);
            this.f206n = hVar.f206n;
        }

        /* access modifiers changed from: package-private */
        public f b() {
            return f.m(this.f201c.consumeStableInsets());
        }

        /* access modifiers changed from: package-private */
        public f c() {
            return f.m(this.f201c.consumeSystemWindowInsets());
        }

        /* access modifiers changed from: package-private */
        public final e.a i() {
            if (this.f206n == null) {
                this.f206n = e.a.b(this.f201c.getStableInsetLeft(), this.f201c.getStableInsetTop(), this.f201c.getStableInsetRight(), this.f201c.getStableInsetBottom());
            }
            return this.f206n;
        }

        /* access modifiers changed from: package-private */
        public boolean m() {
            return this.f201c.isConsumed();
        }

        public void s(e.a aVar) {
            this.f206n = aVar;
        }
    }

    private static class i extends h {
        i(f fVar, WindowInsets windowInsets) {
            super(fVar, windowInsets);
        }

        i(f fVar, i iVar) {
            super(fVar, (h) iVar);
        }

        /* access modifiers changed from: package-private */
        public f a() {
            return f.m(this.f201c.consumeDisplayCutout());
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof i)) {
                return false;
            }
            i iVar = (i) obj;
            return Objects.equals(this.f201c, iVar.f201c) && Objects.equals(this.f205g, iVar.f205g);
        }

        /* access modifiers changed from: package-private */
        public a f() {
            return a.e(this.f201c.getDisplayCutout());
        }

        public int hashCode() {
            return this.f201c.hashCode();
        }
    }

    private static class j extends i {

        /* renamed from: o  reason: collision with root package name */
        private e.a f207o = null;

        /* renamed from: p  reason: collision with root package name */
        private e.a f208p = null;

        /* renamed from: q  reason: collision with root package name */
        private e.a f209q = null;

        j(f fVar, WindowInsets windowInsets) {
            super(fVar, windowInsets);
        }

        j(f fVar, j jVar) {
            super(fVar, (i) jVar);
        }

        /* access modifiers changed from: package-private */
        public e.a h() {
            if (this.f208p == null) {
                this.f208p = e.a.d(this.f201c.getMandatorySystemGestureInsets());
            }
            return this.f208p;
        }

        /* access modifiers changed from: package-private */
        public e.a j() {
            if (this.f207o == null) {
                this.f207o = e.a.d(this.f201c.getSystemGestureInsets());
            }
            return this.f207o;
        }

        /* access modifiers changed from: package-private */
        public e.a l() {
            if (this.f209q == null) {
                this.f209q = e.a.d(this.f201c.getTappableElementInsets());
            }
            return this.f209q;
        }

        public void s(e.a aVar) {
        }
    }

    private static class k extends j {

        /* renamed from: r  reason: collision with root package name */
        static final f f210r = f.m(WindowInsets.CONSUMED);

        k(f fVar, WindowInsets windowInsets) {
            super(fVar, windowInsets);
        }

        k(f fVar, k kVar) {
            super(fVar, (j) kVar);
        }

        /* access modifiers changed from: package-private */
        public final void d(View view) {
        }

        public e.a g(int i2) {
            return e.a.d(this.f201c.getInsets(n.a(i2)));
        }

        public boolean o(int i2) {
            return this.f201c.isVisible(n.a(i2));
        }
    }

    private static class l {

        /* renamed from: b  reason: collision with root package name */
        static final f f211b = new b().a().a().b().c();

        /* renamed from: a  reason: collision with root package name */
        final f f212a;

        l(f fVar) {
            this.f212a = fVar;
        }

        /* access modifiers changed from: package-private */
        public f a() {
            return this.f212a;
        }

        /* access modifiers changed from: package-private */
        public f b() {
            return this.f212a;
        }

        /* access modifiers changed from: package-private */
        public f c() {
            return this.f212a;
        }

        /* access modifiers changed from: package-private */
        public void d(View view) {
        }

        /* access modifiers changed from: package-private */
        public void e(f fVar) {
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof l)) {
                return false;
            }
            l lVar = (l) obj;
            return n() == lVar.n() && m() == lVar.m() && h.b.a(k(), lVar.k()) && h.b.a(i(), lVar.i()) && h.b.a(f(), lVar.f());
        }

        /* access modifiers changed from: package-private */
        public a f() {
            return null;
        }

        /* access modifiers changed from: package-private */
        public e.a g(int i2) {
            return e.a.f134e;
        }

        /* access modifiers changed from: package-private */
        public e.a h() {
            return k();
        }

        public int hashCode() {
            return h.b.b(Boolean.valueOf(n()), Boolean.valueOf(m()), k(), i(), f());
        }

        /* access modifiers changed from: package-private */
        public e.a i() {
            return e.a.f134e;
        }

        /* access modifiers changed from: package-private */
        public e.a j() {
            return k();
        }

        /* access modifiers changed from: package-private */
        public e.a k() {
            return e.a.f134e;
        }

        /* access modifiers changed from: package-private */
        public e.a l() {
            return k();
        }

        /* access modifiers changed from: package-private */
        public boolean m() {
            return false;
        }

        /* access modifiers changed from: package-private */
        public boolean n() {
            return false;
        }

        /* access modifiers changed from: package-private */
        public boolean o(int i2) {
            return true;
        }

        public void p(e.a[] aVarArr) {
        }

        /* access modifiers changed from: package-private */
        public void q(e.a aVar) {
        }

        /* access modifiers changed from: package-private */
        public void r(f fVar) {
        }

        public void s(e.a aVar) {
        }
    }

    public static final class m {
        public static int a() {
            return 8;
        }

        static int b(int i2) {
            if (i2 == 1) {
                return 0;
            }
            if (i2 == 2) {
                return 1;
            }
            if (i2 == 4) {
                return 2;
            }
            if (i2 == 8) {
                return 3;
            }
            if (i2 == 16) {
                return 4;
            }
            if (i2 == 32) {
                return 5;
            }
            if (i2 == 64) {
                return 6;
            }
            if (i2 == 128) {
                return 7;
            }
            if (i2 == 256) {
                return 8;
            }
            throw new IllegalArgumentException("type needs to be >= FIRST and <= LAST, type=" + i2);
        }
    }

    private static final class n {
        static int a(int i2) {
            int i3;
            int i4 = 0;
            for (int i5 = 1; i5 <= 256; i5 <<= 1) {
                if ((i2 & i5) != 0) {
                    if (i5 == 1) {
                        i3 = WindowInsets.Type.statusBars();
                    } else if (i5 == 2) {
                        i3 = WindowInsets.Type.navigationBars();
                    } else if (i5 == 4) {
                        i3 = WindowInsets.Type.captionBar();
                    } else if (i5 == 8) {
                        i3 = WindowInsets.Type.ime();
                    } else if (i5 == 16) {
                        i3 = WindowInsets.Type.systemGestures();
                    } else if (i5 == 32) {
                        i3 = WindowInsets.Type.mandatorySystemGestures();
                    } else if (i5 == 64) {
                        i3 = WindowInsets.Type.tappableElement();
                    } else if (i5 == 128) {
                        i3 = WindowInsets.Type.displayCutout();
                    }
                    i4 |= i3;
                }
            }
            return i4;
        }
    }

    private f(WindowInsets windowInsets) {
        l gVar;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            gVar = new k(this, windowInsets);
        } else if (i2 >= 29) {
            gVar = new j(this, windowInsets);
        } else if (i2 >= 28) {
            gVar = new i(this, windowInsets);
        } else if (i2 >= 21) {
            gVar = new h(this, windowInsets);
        } else if (i2 >= 20) {
            gVar = new g(this, windowInsets);
        } else {
            this.f180a = new l(this);
            return;
        }
        this.f180a = gVar;
    }

    public f(f fVar) {
        if (fVar != null) {
            l lVar = fVar.f180a;
            int i2 = Build.VERSION.SDK_INT;
            this.f180a = (i2 < 30 || !(lVar instanceof k)) ? (i2 < 29 || !(lVar instanceof j)) ? (i2 < 28 || !(lVar instanceof i)) ? (i2 < 21 || !(lVar instanceof h)) ? (i2 < 20 || !(lVar instanceof g)) ? new l(this) : new g(this, (g) lVar) : new h(this, (h) lVar) : new i(this, (i) lVar) : new j(this, (j) lVar) : new k(this, (k) lVar);
            lVar.e(this);
            return;
        }
        this.f180a = new l(this);
    }

    public static f m(WindowInsets windowInsets) {
        return n(windowInsets, (View) null);
    }

    public static f n(WindowInsets windowInsets, View view) {
        f fVar = new f((WindowInsets) h.c.a(windowInsets));
        if (view != null && view.isAttachedToWindow()) {
            fVar.k(c.d(view));
            fVar.d(view.getRootView());
        }
        return fVar;
    }

    @Deprecated
    public f a() {
        return this.f180a.a();
    }

    @Deprecated
    public f b() {
        return this.f180a.b();
    }

    @Deprecated
    public f c() {
        return this.f180a.c();
    }

    /* access modifiers changed from: package-private */
    public void d(View view) {
        this.f180a.d(view);
    }

    public a e() {
        return this.f180a.f();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        return h.b.a(this.f180a, ((f) obj).f180a);
    }

    public e.a f(int i2) {
        return this.f180a.g(i2);
    }

    @Deprecated
    public e.a g() {
        return this.f180a.i();
    }

    public boolean h(int i2) {
        return this.f180a.o(i2);
    }

    public int hashCode() {
        l lVar = this.f180a;
        if (lVar == null) {
            return 0;
        }
        return lVar.hashCode();
    }

    /* access modifiers changed from: package-private */
    public void i(e.a[] aVarArr) {
        this.f180a.p(aVarArr);
    }

    /* access modifiers changed from: package-private */
    public void j(e.a aVar) {
        this.f180a.q(aVar);
    }

    /* access modifiers changed from: package-private */
    public void k(f fVar) {
        this.f180a.r(fVar);
    }

    /* access modifiers changed from: package-private */
    public void l(e.a aVar) {
        this.f180a.s(aVar);
    }
}
