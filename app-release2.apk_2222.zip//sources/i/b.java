package i;

public interface b {
}
