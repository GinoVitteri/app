package i;

import android.os.Build;
import android.view.DisplayCutout;
import h.b;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    private final Object f167a;

    private a(Object obj) {
        this.f167a = obj;
    }

    static a e(Object obj) {
        if (obj == null) {
            return null;
        }
        return new a(obj);
    }

    public int a() {
        if (Build.VERSION.SDK_INT >= 28) {
            return ((DisplayCutout) this.f167a).getSafeInsetBottom();
        }
        return 0;
    }

    public int b() {
        if (Build.VERSION.SDK_INT >= 28) {
            return ((DisplayCutout) this.f167a).getSafeInsetLeft();
        }
        return 0;
    }

    public int c() {
        if (Build.VERSION.SDK_INT >= 28) {
            return ((DisplayCutout) this.f167a).getSafeInsetRight();
        }
        return 0;
    }

    public int d() {
        if (Build.VERSION.SDK_INT >= 28) {
            return ((DisplayCutout) this.f167a).getSafeInsetTop();
        }
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || a.class != obj.getClass()) {
            return false;
        }
        return b.a(this.f167a, ((a) obj).f167a);
    }

    public int hashCode() {
        Object obj = this.f167a;
        if (obj == null) {
            return 0;
        }
        return obj.hashCode();
    }

    public String toString() {
        return "DisplayCutoutCompat{" + this.f167a + "}";
    }
}
