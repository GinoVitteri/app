package i;

import android.annotation.SuppressLint;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import i.f;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint({"PrivateConstructorForUtilityClass"})
public class c {

    /* renamed from: a  reason: collision with root package name */
    private static final AtomicInteger f168a = new AtomicInteger(1);

    /* renamed from: b  reason: collision with root package name */
    private static WeakHashMap<View, Object> f169b = null;

    /* renamed from: c  reason: collision with root package name */
    private static boolean f170c = false;

    /* renamed from: d  reason: collision with root package name */
    private static final int[] f171d = {c.a.accessibility_custom_action_0, c.a.accessibility_custom_action_1, c.a.accessibility_custom_action_2, c.a.accessibility_custom_action_3, c.a.accessibility_custom_action_4, c.a.accessibility_custom_action_5, c.a.accessibility_custom_action_6, c.a.accessibility_custom_action_7, c.a.accessibility_custom_action_8, c.a.accessibility_custom_action_9, c.a.accessibility_custom_action_10, c.a.accessibility_custom_action_11, c.a.accessibility_custom_action_12, c.a.accessibility_custom_action_13, c.a.accessibility_custom_action_14, c.a.accessibility_custom_action_15, c.a.accessibility_custom_action_16, c.a.accessibility_custom_action_17, c.a.accessibility_custom_action_18, c.a.accessibility_custom_action_19, c.a.accessibility_custom_action_20, c.a.accessibility_custom_action_21, c.a.accessibility_custom_action_22, c.a.accessibility_custom_action_23, c.a.accessibility_custom_action_24, c.a.accessibility_custom_action_25, c.a.accessibility_custom_action_26, c.a.accessibility_custom_action_27, c.a.accessibility_custom_action_28, c.a.accessibility_custom_action_29, c.a.accessibility_custom_action_30, c.a.accessibility_custom_action_31};

    /* renamed from: e  reason: collision with root package name */
    private static final b f172e = new a();

    /* renamed from: f  reason: collision with root package name */
    private static C0006c f173f = new C0006c();

    class a implements b {
        a() {
        }
    }

    class b extends d<CharSequence> {
        b(int i2, Class cls, int i3, int i4) {
            super(i2, cls, i3, i4);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: e */
        public CharSequence c(View view) {
            return view.getAccessibilityPaneTitle();
        }
    }

    /* renamed from: i.c$c  reason: collision with other inner class name */
    static class C0006c implements ViewTreeObserver.OnGlobalLayoutListener, View.OnAttachStateChangeListener {

        /* renamed from: a  reason: collision with root package name */
        private WeakHashMap<View, Boolean> f174a = new WeakHashMap<>();

        C0006c() {
        }

        private void a(View view, boolean z2) {
            boolean z3 = view.getVisibility() == 0;
            if (z2 != z3) {
                c.e(view, z3 ? 16 : 32);
                this.f174a.put(view, Boolean.valueOf(z3));
            }
        }

        private void b(View view) {
            view.getViewTreeObserver().addOnGlobalLayoutListener(this);
        }

        public void onGlobalLayout() {
            if (Build.VERSION.SDK_INT < 28) {
                for (Map.Entry next : this.f174a.entrySet()) {
                    a((View) next.getKey(), ((Boolean) next.getValue()).booleanValue());
                }
            }
        }

        public void onViewAttachedToWindow(View view) {
            b(view);
        }

        public void onViewDetachedFromWindow(View view) {
        }
    }

    static abstract class d<T> {

        /* renamed from: a  reason: collision with root package name */
        private final int f175a;

        /* renamed from: b  reason: collision with root package name */
        private final Class<T> f176b;

        /* renamed from: c  reason: collision with root package name */
        private final int f177c;

        /* renamed from: d  reason: collision with root package name */
        private final int f178d;

        d(int i2, Class<T> cls, int i3, int i4) {
            this.f175a = i2;
            this.f176b = cls;
            this.f178d = i3;
            this.f177c = i4;
        }

        private boolean a() {
            return true;
        }

        private boolean b() {
            return Build.VERSION.SDK_INT >= this.f177c;
        }

        /* access modifiers changed from: package-private */
        public abstract T c(View view);

        /* access modifiers changed from: package-private */
        public T d(View view) {
            if (b()) {
                return c(view);
            }
            if (!a()) {
                return null;
            }
            T tag = view.getTag(this.f175a);
            if (this.f176b.isInstance(tag)) {
                return tag;
            }
            return null;
        }
    }

    private static class e {
        public static f a(View view) {
            return f.a.a(view);
        }
    }

    private static class f {
        public static f a(View view) {
            WindowInsets a2 = view.getRootWindowInsets();
            if (a2 == null) {
                return null;
            }
            f m2 = f.m(a2);
            m2.k(m2);
            m2.d(view.getRootView());
            return m2;
        }
    }

    public static int a(View view) {
        return view.getAccessibilityLiveRegion();
    }

    public static CharSequence b(View view) {
        return f().d(view);
    }

    public static int c(View view) {
        return view.getImportantForAccessibility();
    }

    public static f d(View view) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 23) {
            return f.a(view);
        }
        if (i2 >= 21) {
            return e.a(view);
        }
        return null;
    }

    static void e(View view, int i2) {
        AccessibilityManager accessibilityManager = (AccessibilityManager) view.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled()) {
            boolean z2 = b(view) != null && view.getVisibility() == 0;
            int i3 = 32;
            if (a(view) != 0 || z2) {
                AccessibilityEvent obtain = AccessibilityEvent.obtain();
                if (!z2) {
                    i3 = 2048;
                }
                obtain.setEventType(i3);
                obtain.setContentChangeTypes(i2);
                if (z2) {
                    obtain.getText().add(b(view));
                    h(view);
                }
                view.sendAccessibilityEventUnchecked(obtain);
            } else if (i2 == 32) {
                AccessibilityEvent obtain2 = AccessibilityEvent.obtain();
                view.onInitializeAccessibilityEvent(obtain2);
                obtain2.setEventType(32);
                obtain2.setContentChangeTypes(i2);
                obtain2.setSource(view);
                view.onPopulateAccessibilityEvent(obtain2);
                obtain2.getText().add(b(view));
                accessibilityManager.sendAccessibilityEvent(obtain2);
            } else if (view.getParent() != null) {
                try {
                    view.getParent().notifySubtreeAccessibilityStateChanged(view, view, i2);
                } catch (AbstractMethodError e2) {
                    Log.e("ViewCompat", view.getParent().getClass().getSimpleName() + " does not fully implement ViewParent", e2);
                }
            }
        }
    }

    private static d<CharSequence> f() {
        return new b(c.a.tag_accessibility_pane_title, CharSequence.class, 8, 28);
    }

    public static void g(View view, int i2) {
        view.setImportantForAccessibility(i2);
    }

    private static void h(View view) {
        if (c(view) == 0) {
            g(view, 1);
        }
        for (ViewParent parent = view.getParent(); parent instanceof View; parent = parent.getParent()) {
            if (c((View) parent) == 4) {
                g(view, 2);
                return;
            }
        }
    }
}
