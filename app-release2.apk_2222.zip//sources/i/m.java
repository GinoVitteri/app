package i;

public final /* synthetic */ class m {
}
