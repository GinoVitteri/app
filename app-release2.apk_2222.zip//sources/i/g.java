package i;

public final /* synthetic */ class g {
}
