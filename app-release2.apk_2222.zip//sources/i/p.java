package i;

public final /* synthetic */ class p {
}
