package i;

import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;

public final class t {

    /* renamed from: a  reason: collision with root package name */
    private final e f213a;

    private static class a extends e {

        /* renamed from: a  reason: collision with root package name */
        protected final Window f214a;

        /* renamed from: b  reason: collision with root package name */
        private final View f215b;

        a(Window window, View view) {
            this.f214a = window;
            this.f215b = view;
        }

        /* access modifiers changed from: protected */
        public void c(int i2) {
            View decorView = this.f214a.getDecorView();
            decorView.setSystemUiVisibility(i2 | decorView.getSystemUiVisibility());
        }

        /* access modifiers changed from: protected */
        public void d(int i2) {
            this.f214a.addFlags(i2);
        }

        /* access modifiers changed from: protected */
        public void e(int i2) {
            View decorView = this.f214a.getDecorView();
            decorView.setSystemUiVisibility((i2 ^ -1) & decorView.getSystemUiVisibility());
        }

        /* access modifiers changed from: protected */
        public void f(int i2) {
            this.f214a.clearFlags(i2);
        }
    }

    private static class b extends a {
        b(Window window, View view) {
            super(window, view);
        }

        public void b(boolean z2) {
            if (z2) {
                f(67108864);
                d(Integer.MIN_VALUE);
                c(8192);
                return;
            }
            e(8192);
        }
    }

    private static class c extends b {
        c(Window window, View view) {
            super(window, view);
        }

        public void a(boolean z2) {
            if (z2) {
                f(134217728);
                d(Integer.MIN_VALUE);
                c(16);
                return;
            }
            e(16);
        }
    }

    private static class d extends e {

        /* renamed from: a  reason: collision with root package name */
        final t f216a;

        /* renamed from: b  reason: collision with root package name */
        final WindowInsetsController f217b;

        /* renamed from: c  reason: collision with root package name */
        private final b.d<Object, WindowInsetsController.OnControllableInsetsChangedListener> f218c;

        d(Window window, t tVar) {
            this(window.getInsetsController(), tVar);
        }

        d(WindowInsetsController windowInsetsController, t tVar) {
            this.f218c = new b.d<>();
            this.f217b = windowInsetsController;
            this.f216a = tVar;
        }

        public void a(boolean z2) {
            if (z2) {
                this.f217b.setSystemBarsAppearance(16, 16);
            } else {
                this.f217b.setSystemBarsAppearance(0, 16);
            }
        }

        public void b(boolean z2) {
            if (z2) {
                this.f217b.setSystemBarsAppearance(8, 8);
            } else {
                this.f217b.setSystemBarsAppearance(0, 8);
            }
        }
    }

    private static class e {
        e() {
        }

        public void a(boolean z2) {
        }

        public void b(boolean z2) {
        }
    }

    public t(Window window, View view) {
        e aVar;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            this.f213a = new d(window, this);
            return;
        }
        if (i2 >= 26) {
            aVar = new c(window, view);
        } else if (i2 >= 23) {
            aVar = new b(window, view);
        } else if (i2 >= 20) {
            aVar = new a(window, view);
        } else {
            this.f213a = new e();
            return;
        }
        this.f213a = aVar;
    }

    public void a(boolean z2) {
        this.f213a.a(z2);
    }

    public void b(boolean z2) {
        this.f213a.b(z2);
    }
}
