package i;

public final /* synthetic */ class e {
}
