package b0;

public final /* synthetic */ class b {
}
