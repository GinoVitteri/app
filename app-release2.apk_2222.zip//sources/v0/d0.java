package v0;

import f0.k;
import f0.l;
import f0.q;
import h0.d;
import kotlin.jvm.internal.e;

public final class d0 {
    public static final <T> Object a(Object obj, d<? super T> dVar) {
        if (obj instanceof z) {
            k.a aVar = k.f146d;
            obj = l.a(((z) obj).f1169a);
        }
        return k.a(obj);
    }

    public static final <T> Object b(Object obj, o0.l<? super Throwable, q> lVar) {
        Throwable b2 = k.b(obj);
        return b2 == null ? lVar != null ? new a0(obj, lVar) : obj : new z(b2, false, 2, (e) null);
    }

    public static final <T> Object c(Object obj, k<?> kVar) {
        Throwable b2 = k.b(obj);
        return b2 == null ? obj : new z(b2, false, 2, (e) null);
    }

    public static /* synthetic */ Object d(Object obj, o0.l lVar, int i2, Object obj2) {
        if ((i2 & 1) != 0) {
            lVar = null;
        }
        return b(obj, lVar);
    }
}
