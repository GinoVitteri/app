package v0;

public final class f extends w0 {

    /* renamed from: j  reason: collision with root package name */
    private final Thread f1091j;

    public f(Thread thread) {
        this.f1091j = thread;
    }

    /* access modifiers changed from: protected */
    public Thread y() {
        return this.f1091j;
    }
}
