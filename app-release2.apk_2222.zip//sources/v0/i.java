package v0;

public abstract class i extends j implements x1 {
}
