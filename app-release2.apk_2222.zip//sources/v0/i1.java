package v0;

import f0.q;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import o0.l;

final class i1 extends m1 {

    /* renamed from: i  reason: collision with root package name */
    private static final /* synthetic */ AtomicIntegerFieldUpdater f1099i = AtomicIntegerFieldUpdater.newUpdater(i1.class, "_invoked");
    private volatile /* synthetic */ int _invoked = 0;

    /* renamed from: h  reason: collision with root package name */
    private final l<Throwable, q> f1100h;

    public i1(l<? super Throwable, q> lVar) {
        this.f1100h = lVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        y((Throwable) obj);
        return q.f152a;
    }

    public void y(Throwable th) {
        if (f1099i.compareAndSet(this, 0, 1)) {
            this.f1100h.invoke(th);
        }
    }
}
