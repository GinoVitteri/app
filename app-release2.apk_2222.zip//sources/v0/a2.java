package v0;

import h0.g;

public interface a2<S> extends g.b {
    S f(g gVar);

    void r(g gVar, S s2);
}
