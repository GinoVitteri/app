package v0;

import java.util.concurrent.CancellationException;

public interface y1 extends k1 {
    CancellationException c();
}
