package v0;

import kotlinx.coroutines.internal.p;
import kotlinx.coroutines.scheduling.b;

public final class s0 {

    /* renamed from: a  reason: collision with root package name */
    public static final s0 f1136a = new s0();

    /* renamed from: b  reason: collision with root package name */
    private static final f0 f1137b = e0.a();

    /* renamed from: c  reason: collision with root package name */
    private static final f0 f1138c = c2.f1084e;

    /* renamed from: d  reason: collision with root package name */
    private static final f0 f1139d = b.f911k.q();

    private s0() {
    }

    public static final f0 a() {
        return f1137b;
    }

    public static final f0 b() {
        return f1139d;
    }

    public static final u1 c() {
        return p.f871c;
    }
}
