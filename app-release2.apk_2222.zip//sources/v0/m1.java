package v0;

public abstract class m1 extends q1 {
}
