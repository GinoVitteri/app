package v0;

import java.util.concurrent.Executor;

public final class d1 {
    public static final f0 a(Executor executor) {
        r0 r0Var = executor instanceof r0 ? (r0) executor : null;
        return r0Var == null ? new c1(executor) : r0Var.f1125d;
    }
}
