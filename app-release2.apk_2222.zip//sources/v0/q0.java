package v0;

import f0.k;
import f0.l;
import f0.q;
import h0.d;
import h0.g;
import kotlinx.coroutines.internal.b0;
import kotlinx.coroutines.internal.f;

public final class q0 {
    public static final <T> void a(p0<? super T> p0Var, int i2) {
        d<? super T> c2 = p0Var.c();
        boolean z2 = i2 == 4;
        if (z2 || !(c2 instanceof f) || b(i2) != b(p0Var.f1122f)) {
            d(p0Var, c2, z2);
            return;
        }
        f0 f0Var = ((f) c2).f844g;
        g context = c2.getContext();
        if (f0Var.h(context)) {
            f0Var.g(context, p0Var);
        } else {
            e(p0Var);
        }
    }

    public static final boolean b(int i2) {
        return i2 == 1 || i2 == 2;
    }

    public static final boolean c(int i2) {
        return i2 == 2;
    }

    public static final <T> void d(p0<? super T> p0Var, d<? super T> dVar, boolean z2) {
        Object obj;
        Object j2 = p0Var.j();
        Throwable e2 = p0Var.e(j2);
        if (e2 != null) {
            k.a aVar = k.f146d;
            obj = l.a(e2);
        } else {
            k.a aVar2 = k.f146d;
            obj = p0Var.f(j2);
        }
        Object a2 = k.a(obj);
        if (z2) {
            f fVar = (f) dVar;
            d<T> dVar2 = fVar.f845h;
            Object obj2 = fVar.f847j;
            g context = dVar2.getContext();
            Object c2 = b0.c(context, obj2);
            d2<?> e3 = c2 != b0.f828a ? e0.e(dVar2, context, c2) : null;
            try {
                fVar.f845h.resumeWith(a2);
                q qVar = q.f152a;
            } finally {
                if (e3 == null || e3.x0()) {
                    b0.a(context, c2);
                }
            }
        } else {
            dVar.resumeWith(a2);
        }
    }

    private static final void e(p0<?> p0Var) {
        v0 a2 = b2.f1081a.a();
        if (a2.v()) {
            a2.q(p0Var);
            return;
        }
        a2.t(true);
        try {
            d(p0Var, p0Var.c(), true);
            do {
            } while (a2.x());
        } catch (Throwable th) {
            a2.i(true);
            throw th;
        }
        a2.i(true);
    }
}
