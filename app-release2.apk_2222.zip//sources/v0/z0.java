package v0;

import kotlinx.coroutines.internal.x;

public final class z0 {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public static final x f1170a = new x("REMOVED_TASK");
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public static final x f1171b = new x("CLOSED_EMPTY");
}
