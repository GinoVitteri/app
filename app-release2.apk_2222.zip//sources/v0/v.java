package v0;

public final /* synthetic */ class v implements Runnable {
    public final void run() {
        w.x();
    }
}
