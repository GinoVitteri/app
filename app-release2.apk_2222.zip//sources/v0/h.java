package v0;

import f0.q;
import h0.d;
import h0.g;
import o0.p;

final /* synthetic */ class h {
    public static final k1 a(i0 i0Var, g gVar, k0 k0Var, p<? super i0, ? super d<? super q>, ? extends Object> pVar) {
        g c2 = e0.c(i0Var, gVar);
        a t1Var = k0Var.c() ? new t1(c2, pVar) : new z1(c2, true);
        t1Var.v0(k0Var, t1Var, pVar);
        return t1Var;
    }

    public static /* synthetic */ k1 b(i0 i0Var, g gVar, k0 k0Var, p pVar, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            gVar = h0.h.f166d;
        }
        if ((i2 & 2) != 0) {
            k0Var = k0.DEFAULT;
        }
        return g.a(i0Var, gVar, k0Var, pVar);
    }
}
