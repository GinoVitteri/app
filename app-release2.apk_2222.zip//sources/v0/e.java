package v0;

public abstract class e extends i {
}
