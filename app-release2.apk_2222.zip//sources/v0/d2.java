package v0;

import f0.q;
import h0.d;
import h0.g;
import kotlinx.coroutines.internal.b0;
import kotlinx.coroutines.internal.v;

public final class d2<T> extends v<T> {

    /* renamed from: g  reason: collision with root package name */
    private g f1086g;

    /* renamed from: h  reason: collision with root package name */
    private Object f1087h;

    /* access modifiers changed from: protected */
    public void s0(Object obj) {
        g gVar = this.f1086g;
        d2<?> d2Var = null;
        if (gVar != null) {
            b0.a(gVar, this.f1087h);
            this.f1086g = d2Var;
            this.f1087h = d2Var;
        }
        Object a2 = d0.a(obj, this.f879f);
        d<T> dVar = this.f879f;
        g context = dVar.getContext();
        Object c2 = b0.c(context, d2Var);
        if (c2 != b0.f828a) {
            d2Var = e0.e(dVar, context, c2);
        }
        try {
            this.f879f.resumeWith(a2);
            q qVar = q.f152a;
        } finally {
            if (d2Var == null || d2Var.x0()) {
                b0.a(context, c2);
            }
        }
    }

    public final boolean x0() {
        if (this.f1086g == null) {
            return false;
        }
        this.f1086g = null;
        this.f1087h = null;
        return true;
    }

    public final void y0(g gVar, Object obj) {
        this.f1086g = gVar;
        this.f1087h = obj;
    }
}
