package v0;

import kotlinx.coroutines.internal.x;

public final class n {

    /* renamed from: a  reason: collision with root package name */
    public static final x f1116a = new x("RESUME_TOKEN");
}
