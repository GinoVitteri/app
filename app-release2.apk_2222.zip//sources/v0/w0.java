package v0;

import h0.g;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.jvm.internal.i;
import kotlinx.coroutines.internal.c0;
import kotlinx.coroutines.internal.d0;
import kotlinx.coroutines.internal.o;

public abstract class w0 extends x0 {

    /* renamed from: h  reason: collision with root package name */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f1156h;

    /* renamed from: i  reason: collision with root package name */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f1157i;
    private volatile /* synthetic */ Object _delayed = null;
    private volatile /* synthetic */ int _isCompleted = 0;
    private volatile /* synthetic */ Object _queue = null;

    public static abstract class a implements Runnable, Comparable<a>, t0, d0 {

        /* renamed from: d  reason: collision with root package name */
        public long f1158d;

        /* renamed from: e  reason: collision with root package name */
        private Object f1159e;

        /* renamed from: f  reason: collision with root package name */
        private int f1160f;

        public final synchronized void a() {
            Object obj = this.f1159e;
            if (obj != z0.f1170a) {
                b bVar = obj instanceof b ? (b) obj : null;
                if (bVar != null) {
                    bVar.g(this);
                }
                this.f1159e = z0.f1170a;
            }
        }

        public void b(int i2) {
            this.f1160f = i2;
        }

        public void c(c0<?> c0Var) {
            if (this.f1159e != z0.f1170a) {
                this.f1159e = c0Var;
                return;
            }
            throw new IllegalArgumentException("Failed requirement.".toString());
        }

        public c0<?> e() {
            Object obj = this.f1159e;
            if (obj instanceof c0) {
                return (c0) obj;
            }
            return null;
        }

        public int f() {
            return this.f1160f;
        }

        /* renamed from: g */
        public int compareTo(a aVar) {
            long j2 = this.f1158d - aVar.f1158d;
            if (j2 > 0) {
                return 1;
            }
            return j2 < 0 ? -1 : 0;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:34:0x0046, code lost:
            r8 = 0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:6:0x000b, code lost:
            return r8;
         */
        /* JADX WARNING: Removed duplicated region for block: B:30:0x0040  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final synchronized int h(long r8, v0.w0.b r10, v0.w0 r11) {
            /*
                r7 = this;
                monitor-enter(r7)
                java.lang.Object r0 = r7.f1159e     // Catch:{ all -> 0x004b }
                kotlinx.coroutines.internal.x r1 = v0.z0.f1170a     // Catch:{ all -> 0x004b }
                if (r0 != r1) goto L_0x000c
                r8 = 2
            L_0x000a:
                monitor-exit(r7)
                return r8
            L_0x000c:
                monitor-enter(r10)     // Catch:{ all -> 0x004b }
                kotlinx.coroutines.internal.d0 r0 = r10.b()     // Catch:{ all -> 0x0048 }
                v0.w0$a r0 = (v0.w0.a) r0     // Catch:{ all -> 0x0048 }
                boolean r11 = r11.G()     // Catch:{ all -> 0x0048 }
                if (r11 == 0) goto L_0x001d
                r8 = 1
                monitor-exit(r10)     // Catch:{ all -> 0x004b }
                monitor-exit(r7)
                return r8
            L_0x001d:
                r1 = 0
                if (r0 != 0) goto L_0x0024
            L_0x0021:
                r10.f1161b = r8     // Catch:{ all -> 0x0048 }
                goto L_0x0037
            L_0x0024:
                long r3 = r0.f1158d     // Catch:{ all -> 0x0048 }
                long r5 = r3 - r8
                int r11 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1))
                if (r11 < 0) goto L_0x002d
                goto L_0x002e
            L_0x002d:
                r8 = r3
            L_0x002e:
                long r3 = r10.f1161b     // Catch:{ all -> 0x0048 }
                long r3 = r8 - r3
                int r11 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
                if (r11 <= 0) goto L_0x0037
                goto L_0x0021
            L_0x0037:
                long r8 = r7.f1158d     // Catch:{ all -> 0x0048 }
                long r3 = r10.f1161b     // Catch:{ all -> 0x0048 }
                long r8 = r8 - r3
                int r11 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1))
                if (r11 >= 0) goto L_0x0042
                r7.f1158d = r3     // Catch:{ all -> 0x0048 }
            L_0x0042:
                r10.a(r7)     // Catch:{ all -> 0x0048 }
                monitor-exit(r10)     // Catch:{ all -> 0x004b }
                r8 = 0
                goto L_0x000a
            L_0x0048:
                r8 = move-exception
                monitor-exit(r10)     // Catch:{ all -> 0x004b }
                throw r8     // Catch:{ all -> 0x004b }
            L_0x004b:
                r8 = move-exception
                monitor-exit(r7)
                goto L_0x004f
            L_0x004e:
                throw r8
            L_0x004f:
                goto L_0x004e
            */
            throw new UnsupportedOperationException("Method not decompiled: v0.w0.a.h(long, v0.w0$b, v0.w0):int");
        }

        public final boolean i(long j2) {
            return j2 - this.f1158d >= 0;
        }

        public String toString() {
            return "Delayed[nanos=" + this.f1158d + ']';
        }
    }

    public static final class b extends c0<a> {

        /* renamed from: b  reason: collision with root package name */
        public long f1161b;

        public b(long j2) {
            this.f1161b = j2;
        }
    }

    static {
        Class<Object> cls = Object.class;
        Class<w0> cls2 = w0.class;
        f1156h = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_queue");
        f1157i = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_delayed");
    }

    private final void C() {
        while (true) {
            Object obj = this._queue;
            if (obj == null) {
                if (l.a(f1156h, this, (Object) null, z0.f1171b)) {
                    return;
                }
            } else if (obj instanceof o) {
                ((o) obj).d();
                return;
            } else if (obj != z0.f1171b) {
                o oVar = new o(8, true);
                oVar.a((Runnable) obj);
                if (l.a(f1156h, this, obj, oVar)) {
                    return;
                }
            } else {
                return;
            }
        }
    }

    private final Runnable D() {
        while (true) {
            Object obj = this._queue;
            if (obj == null) {
                return null;
            }
            if (obj instanceof o) {
                o oVar = (o) obj;
                Object j2 = oVar.j();
                if (j2 != o.f863h) {
                    return (Runnable) j2;
                }
                l.a(f1156h, this, obj, oVar.i());
            } else if (obj == z0.f1171b) {
                return null;
            } else {
                if (l.a(f1156h, this, obj, (Object) null)) {
                    return (Runnable) obj;
                }
            }
        }
    }

    private final boolean F(Runnable runnable) {
        while (true) {
            Object obj = this._queue;
            if (G()) {
                return false;
            }
            if (obj == null) {
                if (l.a(f1156h, this, (Object) null, runnable)) {
                    return true;
                }
            } else if (obj instanceof o) {
                o oVar = (o) obj;
                int a2 = oVar.a(runnable);
                if (a2 == 0) {
                    return true;
                }
                if (a2 == 1) {
                    l.a(f1156h, this, obj, oVar.i());
                } else if (a2 == 2) {
                    return false;
                }
            } else if (obj == z0.f1171b) {
                return false;
            } else {
                o oVar2 = new o(8, true);
                oVar2.a((Runnable) obj);
                oVar2.a(runnable);
                if (l.a(f1156h, this, obj, oVar2)) {
                    return true;
                }
            }
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [int, boolean] */
    /* access modifiers changed from: private */
    public final boolean G() {
        return this._isCompleted;
    }

    private final void J() {
        c.a();
        long nanoTime = System.nanoTime();
        while (true) {
            b bVar = (b) this._delayed;
            a aVar = bVar == null ? null : (a) bVar.i();
            if (aVar != null) {
                z(nanoTime, aVar);
            } else {
                return;
            }
        }
    }

    private final int M(long j2, a aVar) {
        if (G()) {
            return 1;
        }
        b bVar = (b) this._delayed;
        if (bVar == null) {
            l.a(f1157i, this, (Object) null, new b(j2));
            Object obj = this._delayed;
            i.b(obj);
            bVar = (b) obj;
        }
        return aVar.h(j2, bVar, this);
    }

    private final void N(boolean z2) {
        this._isCompleted = z2 ? 1 : 0;
    }

    private final boolean O(a aVar) {
        b bVar = (b) this._delayed;
        return (bVar == null ? null : (a) bVar.e()) == aVar;
    }

    public final void E(Runnable runnable) {
        if (F(runnable)) {
            A();
        } else {
            n0.f1117j.E(runnable);
        }
    }

    /* access modifiers changed from: protected */
    public boolean H() {
        if (!w()) {
            return false;
        }
        b bVar = (b) this._delayed;
        if (bVar != null && !bVar.d()) {
            return false;
        }
        Object obj = this._queue;
        if (obj != null) {
            return obj instanceof o ? ((o) obj).g() : obj == z0.f1171b;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:29:0x004b  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x004f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public long I() {
        /*
            r9 = this;
            boolean r0 = r9.x()
            r1 = 0
            if (r0 == 0) goto L_0x0009
            return r1
        L_0x0009:
            java.lang.Object r0 = r9._delayed
            v0.w0$b r0 = (v0.w0.b) r0
            if (r0 == 0) goto L_0x0045
            boolean r3 = r0.d()
            if (r3 != 0) goto L_0x0045
            v0.c.a()
            long r3 = java.lang.System.nanoTime()
        L_0x001c:
            monitor-enter(r0)
            kotlinx.coroutines.internal.d0 r5 = r0.b()     // Catch:{ all -> 0x0042 }
            r6 = 0
            if (r5 != 0) goto L_0x0026
        L_0x0024:
            monitor-exit(r0)
            goto L_0x003d
        L_0x0026:
            v0.w0$a r5 = (v0.w0.a) r5     // Catch:{ all -> 0x0042 }
            boolean r7 = r5.i(r3)     // Catch:{ all -> 0x0042 }
            r8 = 0
            if (r7 == 0) goto L_0x0034
            boolean r5 = r9.F(r5)     // Catch:{ all -> 0x0042 }
            goto L_0x0035
        L_0x0034:
            r5 = 0
        L_0x0035:
            if (r5 == 0) goto L_0x0024
            kotlinx.coroutines.internal.d0 r5 = r0.h(r8)     // Catch:{ all -> 0x0042 }
            r6 = r5
            goto L_0x0024
        L_0x003d:
            v0.w0$a r6 = (v0.w0.a) r6
            if (r6 != 0) goto L_0x001c
            goto L_0x0045
        L_0x0042:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
        L_0x0045:
            java.lang.Runnable r0 = r9.D()
            if (r0 == 0) goto L_0x004f
            r0.run()
            return r1
        L_0x004f:
            long r0 = r9.s()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: v0.w0.I():long");
    }

    /* access modifiers changed from: protected */
    public final void K() {
        this._queue = null;
        this._delayed = null;
    }

    public final void L(long j2, a aVar) {
        int M = M(j2, aVar);
        if (M != 0) {
            if (M == 1) {
                z(j2, aVar);
            } else if (M != 2) {
                throw new IllegalStateException("unexpected result".toString());
            }
        } else if (O(aVar)) {
            A();
        }
    }

    public final void g(g gVar, Runnable runnable) {
        E(runnable);
    }

    /* access modifiers changed from: protected */
    public long s() {
        if (super.s() == 0) {
            return 0;
        }
        Object obj = this._queue;
        if (obj != null) {
            if (!(obj instanceof o)) {
                return obj == z0.f1171b ? Long.MAX_VALUE : 0;
            }
            if (!((o) obj).g()) {
                return 0;
            }
        }
        b bVar = (b) this._delayed;
        a aVar = bVar == null ? null : (a) bVar.e();
        if (aVar == null) {
            return Long.MAX_VALUE;
        }
        long j2 = aVar.f1158d;
        c.a();
        return f.b(j2 - System.nanoTime(), 0);
    }

    /* access modifiers changed from: protected */
    public void shutdown() {
        b2.f1081a.b();
        N(true);
        C();
        do {
        } while (I() <= 0);
        J();
    }
}
