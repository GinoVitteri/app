package v0;

import kotlinx.coroutines.internal.a;

public abstract class v0 extends f0 {

    /* renamed from: e  reason: collision with root package name */
    private long f1150e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f1151f;

    /* renamed from: g  reason: collision with root package name */
    private a<p0<?>> f1152g;

    private final long o(boolean z2) {
        return z2 ? 4294967296L : 1;
    }

    public static /* synthetic */ void u(v0 v0Var, boolean z2, int i2, Object obj) {
        if (obj == null) {
            if ((i2 & 1) != 0) {
                z2 = false;
            }
            v0Var.t(z2);
            return;
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: incrementUseCount");
    }

    public final void i(boolean z2) {
        long o2 = this.f1150e - o(z2);
        this.f1150e = o2;
        if (o2 <= 0 && this.f1151f) {
            shutdown();
        }
    }

    public final void q(p0<?> p0Var) {
        a<p0<?>> aVar = this.f1152g;
        if (aVar == null) {
            aVar = new a<>();
            this.f1152g = aVar;
        }
        aVar.a(p0Var);
    }

    /* access modifiers changed from: protected */
    public long s() {
        a<p0<?>> aVar = this.f1152g;
        return (aVar != null && !aVar.c()) ? 0 : Long.MAX_VALUE;
    }

    /* access modifiers changed from: protected */
    public void shutdown() {
    }

    public final void t(boolean z2) {
        this.f1150e += o(z2);
        if (!z2) {
            this.f1151f = true;
        }
    }

    public final boolean v() {
        return this.f1150e >= o(true);
    }

    public final boolean w() {
        a<p0<?>> aVar = this.f1152g;
        if (aVar == null) {
            return true;
        }
        return aVar.c();
    }

    public final boolean x() {
        p0 d2;
        a<p0<?>> aVar = this.f1152g;
        if (aVar == null || (d2 = aVar.d()) == null) {
            return false;
        }
        d2.run();
        return true;
    }
}
