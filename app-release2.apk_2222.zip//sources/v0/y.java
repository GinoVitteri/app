package v0;

import f0.q;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.i;
import o0.l;

final class y {

    /* renamed from: a  reason: collision with root package name */
    public final Object f1163a;

    /* renamed from: b  reason: collision with root package name */
    public final i f1164b;

    /* renamed from: c  reason: collision with root package name */
    public final l<Throwable, q> f1165c;

    /* renamed from: d  reason: collision with root package name */
    public final Object f1166d;

    /* renamed from: e  reason: collision with root package name */
    public final Throwable f1167e;

    public y(Object obj, i iVar, l<? super Throwable, q> lVar, Object obj2, Throwable th) {
        this.f1163a = obj;
        this.f1164b = iVar;
        this.f1165c = lVar;
        this.f1166d = obj2;
        this.f1167e = th;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ y(Object obj, i iVar, l lVar, Object obj2, Throwable th, int i2, e eVar) {
        this(obj, (i2 & 2) != 0 ? null : iVar, (i2 & 4) != 0 ? null : lVar, (i2 & 8) != 0 ? null : obj2, (i2 & 16) != 0 ? null : th);
    }

    public static /* synthetic */ y b(y yVar, Object obj, i iVar, l<Throwable, q> lVar, Object obj2, Throwable th, int i2, Object obj3) {
        if ((i2 & 1) != 0) {
            obj = yVar.f1163a;
        }
        if ((i2 & 2) != 0) {
            iVar = yVar.f1164b;
        }
        i iVar2 = iVar;
        if ((i2 & 4) != 0) {
            lVar = yVar.f1165c;
        }
        l<Throwable, q> lVar2 = lVar;
        if ((i2 & 8) != 0) {
            obj2 = yVar.f1166d;
        }
        Object obj4 = obj2;
        if ((i2 & 16) != 0) {
            th = yVar.f1167e;
        }
        return yVar.a(obj, iVar2, lVar2, obj4, th);
    }

    public final y a(Object obj, i iVar, l<? super Throwable, q> lVar, Object obj2, Throwable th) {
        return new y(obj, iVar, lVar, obj2, th);
    }

    public final boolean c() {
        return this.f1167e != null;
    }

    public final void d(m<?> mVar, Throwable th) {
        i iVar = this.f1164b;
        if (iVar != null) {
            mVar.m(iVar, th);
        }
        l<Throwable, q> lVar = this.f1165c;
        if (lVar != null) {
            mVar.n(lVar, th);
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof y)) {
            return false;
        }
        y yVar = (y) obj;
        return i.a(this.f1163a, yVar.f1163a) && i.a(this.f1164b, yVar.f1164b) && i.a(this.f1165c, yVar.f1165c) && i.a(this.f1166d, yVar.f1166d) && i.a(this.f1167e, yVar.f1167e);
    }

    public int hashCode() {
        Object obj = this.f1163a;
        int i2 = 0;
        int hashCode = (obj == null ? 0 : obj.hashCode()) * 31;
        i iVar = this.f1164b;
        int hashCode2 = (hashCode + (iVar == null ? 0 : iVar.hashCode())) * 31;
        l<Throwable, q> lVar = this.f1165c;
        int hashCode3 = (hashCode2 + (lVar == null ? 0 : lVar.hashCode())) * 31;
        Object obj2 = this.f1166d;
        int hashCode4 = (hashCode3 + (obj2 == null ? 0 : obj2.hashCode())) * 31;
        Throwable th = this.f1167e;
        if (th != null) {
            i2 = th.hashCode();
        }
        return hashCode4 + i2;
    }

    public String toString() {
        return "CompletedContinuation(result=" + this.f1163a + ", cancelHandler=" + this.f1164b + ", onCancellation=" + this.f1165c + ", idempotentResume=" + this.f1166d + ", cancelCause=" + this.f1167e + ')';
    }
}
