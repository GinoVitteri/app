package v0;

import f0.q;
import kotlin.jvm.internal.i;
import o0.l;

public final class a0 {

    /* renamed from: a  reason: collision with root package name */
    public final Object f1077a;

    /* renamed from: b  reason: collision with root package name */
    public final l<Throwable, q> f1078b;

    public a0(Object obj, l<? super Throwable, q> lVar) {
        this.f1077a = obj;
        this.f1078b = lVar;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a0)) {
            return false;
        }
        a0 a0Var = (a0) obj;
        return i.a(this.f1077a, a0Var.f1077a) && i.a(this.f1078b, a0Var.f1078b);
    }

    public int hashCode() {
        Object obj = this.f1077a;
        return ((obj == null ? 0 : obj.hashCode()) * 31) + this.f1078b.hashCode();
    }

    public String toString() {
        return "CompletedWithCancellation(result=" + this.f1077a + ", onCancellation=" + this.f1078b + ')';
    }
}
