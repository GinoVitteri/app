package v0;

import h0.g;
import kotlin.jvm.internal.e;

public final class f2 extends h0.a {

    /* renamed from: e  reason: collision with root package name */
    public static final a f1094e = new a((e) null);

    /* renamed from: d  reason: collision with root package name */
    public boolean f1095d;

    public static final class a implements g.c<f2> {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }
    }

    public f2() {
        super(f1094e);
    }
}
