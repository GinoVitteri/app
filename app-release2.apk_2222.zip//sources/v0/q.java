package v0;

public final class q extends m1 {

    /* renamed from: h  reason: collision with root package name */
    public final m<?> f1123h;

    public q(m<?> mVar) {
        this.f1123h = mVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        y((Throwable) obj);
        return f0.q.f152a;
    }

    public void y(Throwable th) {
        m<?> mVar = this.f1123h;
        mVar.E(mVar.v(z()));
    }
}
