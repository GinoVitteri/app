package v0;

public abstract class b {
}
