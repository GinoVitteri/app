package v0;

import kotlinx.coroutines.internal.x;

public final class s1 {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public static final x f1140a = new x("COMPLETING_ALREADY");

    /* renamed from: b  reason: collision with root package name */
    public static final x f1141b = new x("COMPLETING_WAITING_CHILDREN");
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public static final x f1142c = new x("COMPLETING_RETRY");
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public static final x f1143d = new x("TOO_LATE_TO_CANCEL");
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public static final x f1144e = new x("SEALED");
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public static final u0 f1145f = new u0(false);
    /* access modifiers changed from: private */

    /* renamed from: g  reason: collision with root package name */
    public static final u0 f1146g = new u0(true);

    public static final Object g(Object obj) {
        return obj instanceof f1 ? new g1((f1) obj) : obj;
    }
}
