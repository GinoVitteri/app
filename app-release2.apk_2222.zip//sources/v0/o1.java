package v0;

import h0.g;
import java.util.concurrent.CancellationException;

public final class o1 {
    public static final x a(k1 k1Var) {
        return p1.a(k1Var);
    }

    public static final void c(g gVar, CancellationException cancellationException) {
        p1.c(gVar, cancellationException);
    }

    public static final void d(g gVar) {
        p1.d(gVar);
    }

    public static final void e(k1 k1Var) {
        p1.e(k1Var);
    }
}
