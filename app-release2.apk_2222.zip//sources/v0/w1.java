package v0;

public final class w1 implements t0, r {

    /* renamed from: d  reason: collision with root package name */
    public static final w1 f1162d = new w1();

    private w1() {
    }

    public void a() {
    }

    public boolean d(Throwable th) {
        return false;
    }

    public k1 getParent() {
        return null;
    }

    public String toString() {
        return "NonDisposableHandle";
    }
}
