package v0;

public final class e1 implements f1 {

    /* renamed from: d  reason: collision with root package name */
    private final v1 f1089d;

    public e1(v1 v1Var) {
        this.f1089d = v1Var;
    }

    public boolean b() {
        return false;
    }

    public v1 f() {
        return this.f1089d;
    }

    public String toString() {
        return super.toString();
    }
}
