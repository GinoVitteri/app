package v0;

import h0.d;
import kotlinx.coroutines.internal.f;

public final class o {
    public static final <T> m<T> a(d<? super T> dVar) {
        if (!(dVar instanceof f)) {
            return new m<>(dVar, 1);
        }
        m<T> l2 = ((f) dVar).l();
        if (l2 == null || !l2.G()) {
            l2 = null;
        }
        return l2 == null ? new m<>(dVar, 2) : l2;
    }
}
