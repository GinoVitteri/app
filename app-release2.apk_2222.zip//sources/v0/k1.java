package v0;

import f0.q;
import h0.g;
import java.util.concurrent.CancellationException;
import o0.l;
import o0.p;

public interface k1 extends g.b {

    /* renamed from: c  reason: collision with root package name */
    public static final b f1108c = b.f1109d;

    public static final class a {
        public static /* synthetic */ void a(k1 k1Var, CancellationException cancellationException, int i2, Object obj) {
            if (obj == null) {
                if ((i2 & 1) != 0) {
                    cancellationException = null;
                }
                k1Var.k(cancellationException);
                return;
            }
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: cancel");
        }

        public static <R> R b(k1 k1Var, R r2, p<? super R, ? super g.b, ? extends R> pVar) {
            return g.b.a.a(k1Var, r2, pVar);
        }

        public static <E extends g.b> E c(k1 k1Var, g.c<E> cVar) {
            return g.b.a.b(k1Var, cVar);
        }

        public static /* synthetic */ t0 d(k1 k1Var, boolean z2, boolean z3, l lVar, int i2, Object obj) {
            if (obj == null) {
                if ((i2 & 1) != 0) {
                    z2 = false;
                }
                if ((i2 & 2) != 0) {
                    z3 = true;
                }
                return k1Var.m(z2, z3, lVar);
            }
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: invokeOnCompletion");
        }

        public static g e(k1 k1Var, g.c<?> cVar) {
            return g.b.a.c(k1Var, cVar);
        }

        public static g f(k1 k1Var, g gVar) {
            return g.b.a.d(k1Var, gVar);
        }
    }

    public static final class b implements g.c<k1> {

        /* renamed from: d  reason: collision with root package name */
        static final /* synthetic */ b f1109d = new b();

        private b() {
        }
    }

    boolean b();

    CancellationException e();

    void k(CancellationException cancellationException);

    t0 m(boolean z2, boolean z3, l<? super Throwable, q> lVar);

    r p(t tVar);

    boolean start();
}
