package v0;

import f0.q;
import kotlinx.coroutines.internal.m;
import o0.l;

public abstract class b0 extends m implements l<Throwable, q> {
    public abstract void y(Throwable th);
}
