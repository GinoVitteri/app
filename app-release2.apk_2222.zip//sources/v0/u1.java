package v0;

public abstract class u1 extends f0 {
    public abstract u1 i();

    /* access modifiers changed from: protected */
    public final String o() {
        u1 u1Var;
        u1 c2 = s0.c();
        if (this == c2) {
            return "Dispatchers.Main";
        }
        try {
            u1Var = c2.i();
        } catch (UnsupportedOperationException unused) {
            u1Var = null;
        }
        if (this == u1Var) {
            return "Dispatchers.Main.immediate";
        }
        return null;
    }

    public String toString() {
        String o2 = o();
        if (o2 != null) {
            return o2;
        }
        return m0.a(this) + '@' + m0.b(this);
    }
}
