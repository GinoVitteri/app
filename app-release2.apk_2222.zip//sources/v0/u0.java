package v0;

final class u0 implements f1 {

    /* renamed from: d  reason: collision with root package name */
    private final boolean f1149d;

    public u0(boolean z2) {
        this.f1149d = z2;
    }

    public boolean b() {
        return this.f1149d;
    }

    public v1 f() {
        return null;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Empty{");
        sb.append(b() ? "Active" : "New");
        sb.append('}');
        return sb.toString();
    }
}
