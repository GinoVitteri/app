package v0;

import f0.q;
import h0.d;
import h0.g;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.coroutines.jvm.internal.e;
import kotlin.jvm.internal.i;
import kotlinx.coroutines.internal.f;
import kotlinx.coroutines.internal.x;
import o0.l;
import v0.k1;

public class m<T> extends p0<T> implements k<T>, e {

    /* renamed from: j  reason: collision with root package name */
    private static final /* synthetic */ AtomicIntegerFieldUpdater f1111j = AtomicIntegerFieldUpdater.newUpdater(m.class, "_decision");

    /* renamed from: k  reason: collision with root package name */
    private static final /* synthetic */ AtomicReferenceFieldUpdater f1112k = AtomicReferenceFieldUpdater.newUpdater(m.class, Object.class, "_state");
    private volatile /* synthetic */ int _decision = 0;
    private volatile /* synthetic */ Object _state = d.f1085d;

    /* renamed from: g  reason: collision with root package name */
    private final d<T> f1113g;

    /* renamed from: h  reason: collision with root package name */
    private final g f1114h;

    /* renamed from: i  reason: collision with root package name */
    private t0 f1115i;

    public m(d<? super T> dVar, int i2) {
        super(i2);
        this.f1113g = dVar;
        this.f1114h = dVar.getContext();
    }

    private final boolean A() {
        return q0.c(this.f1122f) && ((f) this.f1113g).n();
    }

    private final i B(l<? super Throwable, q> lVar) {
        return lVar instanceof i ? (i) lVar : new h1(lVar);
    }

    private final void C(l<? super Throwable, q> lVar, Object obj) {
        throw new IllegalStateException(("It's prohibited to register multiple handlers, tried to register " + lVar + ", already has " + obj).toString());
    }

    private final void F() {
        d<T> dVar = this.f1113g;
        Throwable th = null;
        f fVar = dVar instanceof f ? (f) dVar : null;
        if (fVar != null) {
            th = fVar.s(this);
        }
        if (th != null) {
            s();
            p(th);
        }
    }

    private final void H(Object obj, int i2, l<? super Throwable, q> lVar) {
        Object obj2;
        do {
            obj2 = this._state;
            if (obj2 instanceof x1) {
            } else {
                if (obj2 instanceof p) {
                    p pVar = (p) obj2;
                    if (pVar.c()) {
                        if (lVar != null) {
                            n(lVar, pVar.f1169a);
                            return;
                        }
                        return;
                    }
                }
                k(obj);
                throw new f0.d();
            }
        } while (!l.a(f1112k, this, obj2, J((x1) obj2, obj, i2, lVar, (Object) null)));
        t();
        u(i2);
    }

    static /* synthetic */ void I(m mVar, Object obj, int i2, l lVar, int i3, Object obj2) {
        if (obj2 == null) {
            if ((i3 & 4) != 0) {
                lVar = null;
            }
            mVar.H(obj, i2, lVar);
            return;
        }
        throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: resumeImpl");
    }

    private final Object J(x1 x1Var, Object obj, int i2, l<? super Throwable, q> lVar, Object obj2) {
        if (obj instanceof z) {
            return obj;
        }
        if (!q0.b(i2) && obj2 == null) {
            return obj;
        }
        if (lVar == null && ((!(x1Var instanceof i) || (x1Var instanceof e)) && obj2 == null)) {
            return obj;
        }
        return new y(obj, x1Var instanceof i ? (i) x1Var : null, lVar, obj2, (Throwable) null, 16, (kotlin.jvm.internal.e) null);
    }

    private final boolean K() {
        do {
            int i2 = this._decision;
            if (i2 != 0) {
                if (i2 == 1) {
                    return false;
                }
                throw new IllegalStateException("Already resumed".toString());
            }
        } while (!f1111j.compareAndSet(this, 0, 2));
        return true;
    }

    private final x L(Object obj, Object obj2, l<? super Throwable, q> lVar) {
        Object obj3;
        do {
            obj3 = this._state;
            if (obj3 instanceof x1) {
            } else if (!(obj3 instanceof y) || obj2 == null || ((y) obj3).f1166d != obj2) {
                return null;
            } else {
                return n.f1116a;
            }
        } while (!l.a(f1112k, this, obj3, J((x1) obj3, obj, this.f1122f, lVar, obj2)));
        t();
        return n.f1116a;
    }

    private final boolean M() {
        do {
            int i2 = this._decision;
            if (i2 != 0) {
                if (i2 == 2) {
                    return false;
                }
                throw new IllegalStateException("Already suspended".toString());
            }
        } while (!f1111j.compareAndSet(this, 0, 1));
        return true;
    }

    private final Void k(Object obj) {
        throw new IllegalStateException(i.j("Already resumed, but proposed with update ", obj).toString());
    }

    private final void l(l<? super Throwable, q> lVar, Throwable th) {
        try {
            lVar.invoke(th);
        } catch (Throwable th2) {
            h0.a(getContext(), new c0(i.j("Exception in invokeOnCancellation handler for ", this), th2));
        }
    }

    private final boolean r(Throwable th) {
        if (!A()) {
            return false;
        }
        return ((f) this.f1113g).p(th);
    }

    private final void t() {
        if (!A()) {
            s();
        }
    }

    private final void u(int i2) {
        if (!K()) {
            q0.a(this, i2);
        }
    }

    private final String y() {
        Object x2 = x();
        return x2 instanceof x1 ? "Active" : x2 instanceof p ? "Cancelled" : "Completed";
    }

    private final t0 z() {
        k1 k1Var = (k1) getContext().get(k1.f1108c);
        if (k1Var == null) {
            return null;
        }
        t0 d2 = k1.a.d(k1Var, true, false, new q(this), 2, (Object) null);
        this.f1115i = d2;
        return d2;
    }

    /* access modifiers changed from: protected */
    public String D() {
        return "CancellableContinuation";
    }

    public final void E(Throwable th) {
        if (!r(th)) {
            p(th);
            t();
        }
    }

    public final boolean G() {
        Object obj = this._state;
        if (!(obj instanceof y) || ((y) obj).f1166d == null) {
            this._decision = 0;
            this._state = d.f1085d;
            return true;
        }
        s();
        return false;
    }

    public void a(l<? super Throwable, q> lVar) {
        i B = B(lVar);
        while (true) {
            Object obj = this._state;
            if (obj instanceof d) {
                if (l.a(f1112k, this, obj, B)) {
                    return;
                }
            } else if (obj instanceof i) {
                C(lVar, obj);
            } else {
                boolean z2 = obj instanceof z;
                if (z2) {
                    z zVar = (z) obj;
                    if (!zVar.b()) {
                        C(lVar, obj);
                    }
                    if (obj instanceof p) {
                        Throwable th = null;
                        if (!z2) {
                            zVar = null;
                        }
                        if (zVar != null) {
                            th = zVar.f1169a;
                        }
                        l(lVar, th);
                        return;
                    }
                    return;
                } else if (obj instanceof y) {
                    y yVar = (y) obj;
                    if (yVar.f1164b != null) {
                        C(lVar, obj);
                    }
                    if (!(B instanceof e)) {
                        if (yVar.c()) {
                            l(lVar, yVar.f1167e);
                            return;
                        }
                        if (l.a(f1112k, this, obj, y.b(yVar, (Object) null, B, (l) null, (Object) null, (Throwable) null, 29, (Object) null))) {
                            return;
                        }
                    } else {
                        return;
                    }
                } else if (!(B instanceof e)) {
                    if (l.a(f1112k, this, obj, new y(obj, B, (l) null, (Object) null, (Throwable) null, 28, (kotlin.jvm.internal.e) null))) {
                        return;
                    }
                } else {
                    return;
                }
            }
        }
    }

    public void b(Object obj, Throwable th) {
        while (true) {
            Object obj2 = this._state;
            if (obj2 instanceof x1) {
                throw new IllegalStateException("Not completed".toString());
            } else if (!(obj2 instanceof z)) {
                if (obj2 instanceof y) {
                    y yVar = (y) obj2;
                    if (!yVar.c()) {
                        if (l.a(f1112k, this, obj2, y.b(yVar, (Object) null, (i) null, (l) null, (Object) null, th, 15, (Object) null))) {
                            yVar.d(this, th);
                            return;
                        }
                    } else {
                        throw new IllegalStateException("Must be called at most once".toString());
                    }
                } else if (l.a(f1112k, this, obj2, new y(obj2, (i) null, (l) null, (Object) null, th, 14, (kotlin.jvm.internal.e) null))) {
                    return;
                }
            } else {
                return;
            }
        }
    }

    public final d<T> c() {
        return this.f1113g;
    }

    public Object d(T t2, Object obj) {
        return L(t2, obj, (l<? super Throwable, q>) null);
    }

    public Throwable e(Object obj) {
        Throwable e2 = super.e(obj);
        if (e2 == null) {
            return null;
        }
        c();
        return e2;
    }

    public <T> T f(Object obj) {
        return obj instanceof y ? ((y) obj).f1163a : obj;
    }

    public Object g(T t2, Object obj, l<? super Throwable, q> lVar) {
        return L(t2, obj, lVar);
    }

    public e getCallerFrame() {
        d<T> dVar = this.f1113g;
        if (dVar instanceof e) {
            return (e) dVar;
        }
        return null;
    }

    public g getContext() {
        return this.f1114h;
    }

    public void i(T t2, l<? super Throwable, q> lVar) {
        H(t2, this.f1122f, lVar);
    }

    public Object j() {
        return x();
    }

    public final void m(i iVar, Throwable th) {
        try {
            iVar.a(th);
        } catch (Throwable th2) {
            h0.a(getContext(), new c0(i.j("Exception in invokeOnCancellation handler for ", this), th2));
        }
    }

    public final void n(l<? super Throwable, q> lVar, Throwable th) {
        try {
            lVar.invoke(th);
        } catch (Throwable th2) {
            h0.a(getContext(), new c0(i.j("Exception in resume onCancellation handler for ", this), th2));
        }
    }

    public Object o(Throwable th) {
        return L(new z(th, false, 2, (kotlin.jvm.internal.e) null), (Object) null, (l<? super Throwable, q>) null);
    }

    public boolean p(Throwable th) {
        Object obj;
        boolean z2;
        do {
            obj = this._state;
            if (!(obj instanceof x1)) {
                return false;
            }
            z2 = obj instanceof i;
        } while (!l.a(f1112k, this, obj, new p(this, th, z2)));
        i iVar = z2 ? (i) obj : null;
        if (iVar != null) {
            m(iVar, th);
        }
        t();
        u(this.f1122f);
        return true;
    }

    public void q(Object obj) {
        u(this.f1122f);
    }

    public void resumeWith(Object obj) {
        I(this, d0.c(obj, this), this.f1122f, (l) null, 4, (Object) null);
    }

    public final void s() {
        t0 t0Var = this.f1115i;
        if (t0Var != null) {
            t0Var.a();
            this.f1115i = w1.f1162d;
        }
    }

    public String toString() {
        return D() + '(' + m0.c(this.f1113g) + "){" + y() + "}@" + m0.b(this);
    }

    public Throwable v(k1 k1Var) {
        return k1Var.e();
    }

    public final Object w() {
        k1 k1Var;
        boolean A = A();
        if (M()) {
            if (this.f1115i == null) {
                z();
            }
            if (A) {
                F();
            }
            return d.c();
        }
        if (A) {
            F();
        }
        Object x2 = x();
        if (x2 instanceof z) {
            throw ((z) x2).f1169a;
        } else if (!q0.b(this.f1122f) || (k1Var = (k1) getContext().get(k1.f1108c)) == null || k1Var.b()) {
            return f(x2);
        } else {
            CancellationException e2 = k1Var.e();
            b(x2, e2);
            throw e2;
        }
    }

    public final Object x() {
        return this._state;
    }
}
