package v0;

import h0.g;
import kotlinx.coroutines.internal.e;

public final class j0 {
    public static final i0 a(g gVar) {
        if (gVar.get(k1.f1108c) == null) {
            gVar = gVar.plus(p1.b((k1) null, 1, (Object) null));
        }
        return new e(gVar);
    }
}
