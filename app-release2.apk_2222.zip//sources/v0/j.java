package v0;

import f0.q;
import o0.l;

public abstract class j implements l<Throwable, q> {
    public abstract void a(Throwable th);
}
