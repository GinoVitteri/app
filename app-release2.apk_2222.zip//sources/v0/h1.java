package v0;

import f0.q;
import o0.l;

final class h1 extends i {

    /* renamed from: d  reason: collision with root package name */
    private final l<Throwable, q> f1098d;

    public h1(l<? super Throwable, q> lVar) {
        this.f1098d = lVar;
    }

    public void a(Throwable th) {
        this.f1098d.invoke(th);
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        a((Throwable) obj);
        return q.f152a;
    }

    public String toString() {
        return "InvokeOnCancel[" + m0.a(this.f1098d) + '@' + m0.b(this) + ']';
    }
}
