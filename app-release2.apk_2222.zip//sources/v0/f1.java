package v0;

public interface f1 {
    boolean b();

    v1 f();
}
