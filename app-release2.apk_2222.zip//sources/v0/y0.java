package v0;

public final class y0 {
    public static final v0 a() {
        return new f(Thread.currentThread());
    }
}
