package v0;

public final class b2 {

    /* renamed from: a  reason: collision with root package name */
    public static final b2 f1081a = new b2();

    /* renamed from: b  reason: collision with root package name */
    private static final ThreadLocal<v0> f1082b = new ThreadLocal<>();

    private b2() {
    }

    public final v0 a() {
        ThreadLocal<v0> threadLocal = f1082b;
        v0 v0Var = threadLocal.get();
        if (v0Var != null) {
            return v0Var;
        }
        v0 a2 = y0.a();
        threadLocal.set(a2);
        return a2;
    }

    public final void b() {
        f1082b.set((Object) null);
    }

    public final void c(v0 v0Var) {
        f1082b.set(v0Var);
    }
}
