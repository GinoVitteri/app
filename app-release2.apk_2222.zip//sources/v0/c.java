package v0;

public final class c {
    public static final b a() {
        return null;
    }
}
