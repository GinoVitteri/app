package v0;

import h0.g;
import java.util.concurrent.CancellationException;

final /* synthetic */ class p1 {
    public static final x a(k1 k1Var) {
        return new n1(k1Var);
    }

    public static /* synthetic */ x b(k1 k1Var, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            k1Var = null;
        }
        return o1.a(k1Var);
    }

    public static final void c(g gVar, CancellationException cancellationException) {
        k1 k1Var = (k1) gVar.get(k1.f1108c);
        if (k1Var != null) {
            k1Var.k(cancellationException);
        }
    }

    public static final void d(g gVar) {
        k1 k1Var = (k1) gVar.get(k1.f1108c);
        if (k1Var != null) {
            o1.e(k1Var);
        }
    }

    public static final void e(k1 k1Var) {
        if (!k1Var.b()) {
            throw k1Var.e();
        }
    }
}
