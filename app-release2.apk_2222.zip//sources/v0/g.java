package v0;

import f0.q;
import h0.d;
import o0.p;

public final class g {
    public static final k1 a(i0 i0Var, h0.g gVar, k0 k0Var, p<? super i0, ? super d<? super q>, ? extends Object> pVar) {
        return h.a(i0Var, gVar, k0Var, pVar);
    }
}
