package v0;

final class d implements x1 {

    /* renamed from: d  reason: collision with root package name */
    public static final d f1085d = new d();

    private d() {
    }

    public String toString() {
        return "Active";
    }
}
