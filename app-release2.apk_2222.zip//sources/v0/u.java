package v0;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public final /* synthetic */ class u implements ThreadFactory {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ AtomicInteger f1148a;

    public /* synthetic */ u(AtomicInteger atomicInteger) {
        this.f1148a = atomicInteger;
    }

    public final Thread newThread(Runnable runnable) {
        return w.s(this.f1148a, runnable);
    }
}
