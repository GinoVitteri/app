package v0;

import a1.b;
import f0.i;
import h0.d;
import h0.f;
import o0.l;
import o0.p;

public enum k0 {
    DEFAULT,
    LAZY,
    ATOMIC,
    UNDISPATCHED;

    public /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f1107a = null;

        static {
            int[] iArr = new int[k0.values().length];
            iArr[k0.DEFAULT.ordinal()] = 1;
            iArr[k0.ATOMIC.ordinal()] = 2;
            iArr[k0.UNDISPATCHED.ordinal()] = 3;
            iArr[k0.LAZY.ordinal()] = 4;
            f1107a = iArr;
        }
    }

    public final <R, T> void b(p<? super R, ? super d<? super T>, ? extends Object> pVar, R r2, d<? super T> dVar) {
        int i2 = a.f1107a[ordinal()];
        if (i2 == 1) {
            a1.a.e(pVar, r2, dVar, (l) null, 4, (Object) null);
        } else if (i2 == 2) {
            f.a(pVar, r2, dVar);
        } else if (i2 == 3) {
            b.a(pVar, r2, dVar);
        } else if (i2 != 4) {
            throw new i();
        }
    }

    public final boolean c() {
        return this == LAZY;
    }
}
