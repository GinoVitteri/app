package v0;

import h0.g;

public interface i0 {
    g h();
}
