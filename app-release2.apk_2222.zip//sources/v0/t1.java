package v0;

import a1.a;
import f0.q;
import h0.d;
import h0.g;
import o0.p;

final class t1 extends z1 {

    /* renamed from: f  reason: collision with root package name */
    private final d<q> f1147f;

    public t1(g gVar, p<? super i0, ? super d<? super q>, ? extends Object> pVar) {
        super(gVar, false);
        this.f1147f = c.a(pVar, this, this);
    }

    /* access modifiers changed from: protected */
    public void d0() {
        a.c(this.f1147f, this);
    }
}
