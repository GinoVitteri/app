package v0;

public interface t0 {
    void a();
}
