package v0;

import kotlinx.coroutines.internal.k;

public final class v1 extends k implements f1 {
    public boolean b() {
        return true;
    }

    public v1 f() {
        return this;
    }

    public String toString() {
        return super.toString();
    }
}
