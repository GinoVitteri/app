package v0;

public class n1 extends r1 implements x {

    /* renamed from: e  reason: collision with root package name */
    private final boolean f1119e = s0();

    public n1(k1 k1Var) {
        super(true);
        R(k1Var);
    }

    private final boolean s0() {
        s sVar;
        r N = N();
        s sVar2 = N instanceof s ? (s) N : null;
        if (sVar2 == null) {
            return false;
        }
        do {
            r1 z2 = sVar2.z();
            if (z2.K()) {
                return true;
            }
            r N2 = z2.N();
            if (N2 instanceof s) {
                sVar = (s) N2;
                continue;
            } else {
                sVar = null;
                continue;
            }
        } while (sVar2 != null);
        return false;
    }

    public boolean K() {
        return this.f1119e;
    }

    public boolean L() {
        return true;
    }
}
