package v0;

import h0.b;
import h0.g;
import java.io.Closeable;
import kotlin.jvm.internal.e;
import kotlin.jvm.internal.j;
import o0.l;

public abstract class b1 extends f0 implements Closeable {

    /* renamed from: e  reason: collision with root package name */
    public static final a f1079e = new a((e) null);

    public static final class a extends b<f0, b1> {

        /* renamed from: v0.b1$a$a  reason: collision with other inner class name */
        static final class C0025a extends j implements l<g.b, b1> {

            /* renamed from: d  reason: collision with root package name */
            public static final C0025a f1080d = new C0025a();

            C0025a() {
                super(1);
            }

            /* renamed from: a */
            public final b1 invoke(g.b bVar) {
                if (bVar instanceof b1) {
                    return (b1) bVar;
                }
                return null;
            }
        }

        private a() {
            super(f0.f1092d, C0025a.f1080d);
        }

        public /* synthetic */ a(e eVar) {
            this();
        }
    }
}
