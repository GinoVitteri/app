package v0;

import f0.q;

public final class s extends m1 implements r {

    /* renamed from: h  reason: collision with root package name */
    public final t f1135h;

    public s(t tVar) {
        this.f1135h = tVar;
    }

    public boolean d(Throwable th) {
        return z().C(th);
    }

    public k1 getParent() {
        return z();
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        y((Throwable) obj);
        return q.f152a;
    }

    public void y(Throwable th) {
        this.f1135h.l(z());
    }
}
