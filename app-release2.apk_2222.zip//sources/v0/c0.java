package v0;

public final class c0 extends RuntimeException {
    public c0(String str, Throwable th) {
        super(str, th);
    }
}
