package v0;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

public final class n0 extends w0 implements Runnable {
    private static volatile Thread _thread;
    private static volatile int debugStatus;

    /* renamed from: j  reason: collision with root package name */
    public static final n0 f1117j;

    /* renamed from: k  reason: collision with root package name */
    private static final long f1118k;

    static {
        Long l2;
        n0 n0Var = new n0();
        f1117j = n0Var;
        v0.u(n0Var, false, 1, (Object) null);
        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
        try {
            l2 = Long.getLong("kotlinx.coroutines.DefaultExecutor.keepAlive", 1000);
        } catch (SecurityException unused) {
            l2 = 1000L;
        }
        f1118k = timeUnit.toNanos(l2.longValue());
    }

    private n0() {
    }

    private final synchronized void P() {
        if (R()) {
            debugStatus = 3;
            K();
            notifyAll();
        }
    }

    private final synchronized Thread Q() {
        Thread thread;
        thread = _thread;
        if (thread == null) {
            thread = new Thread(this, "kotlinx.coroutines.DefaultExecutor");
            _thread = thread;
            thread.setDaemon(true);
            thread.start();
        }
        return thread;
    }

    private final boolean R() {
        int i2 = debugStatus;
        return i2 == 2 || i2 == 3;
    }

    private final synchronized boolean S() {
        if (R()) {
            return false;
        }
        debugStatus = 1;
        notifyAll();
        return true;
    }

    public void run() {
        b2.f1081a.c(this);
        c.a();
        try {
            if (S()) {
                long j2 = Long.MAX_VALUE;
                while (true) {
                    Thread.interrupted();
                    long I = I();
                    if (I == Long.MAX_VALUE) {
                        c.a();
                        long nanoTime = System.nanoTime();
                        if (j2 == Long.MAX_VALUE) {
                            j2 = f1118k + nanoTime;
                        }
                        long j3 = j2 - nanoTime;
                        if (j3 <= 0) {
                            _thread = null;
                            P();
                            c.a();
                            if (!H()) {
                                y();
                                return;
                            }
                            return;
                        }
                        I = f.d(I, j3);
                    } else {
                        j2 = Long.MAX_VALUE;
                    }
                    if (I > 0) {
                        if (R()) {
                            _thread = null;
                            P();
                            c.a();
                            if (!H()) {
                                y();
                                return;
                            }
                            return;
                        }
                        c.a();
                        LockSupport.parkNanos(this, I);
                    }
                }
            }
        } finally {
            _thread = null;
            P();
            c.a();
            if (!H()) {
                y();
            }
        }
    }

    /* access modifiers changed from: protected */
    public Thread y() {
        Thread thread = _thread;
        return thread == null ? Q() : thread;
    }
}
