package v0;

import f0.q;
import h0.g;

class z1 extends a<q> {
    public z1(g gVar, boolean z2) {
        super(gVar, true, z2);
    }

    /* access modifiers changed from: protected */
    public boolean P(Throwable th) {
        h0.a(getContext(), th);
        return true;
    }
}
