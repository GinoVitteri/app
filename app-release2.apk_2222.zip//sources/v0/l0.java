package v0;

public final class l0 extends Error {
    public l0(String str, Throwable th) {
        super(str, th);
    }
}
