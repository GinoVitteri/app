package v0;

final class g1 {

    /* renamed from: a  reason: collision with root package name */
    public final f1 f1097a;

    public g1(f1 f1Var) {
        this.f1097a = f1Var;
    }
}
