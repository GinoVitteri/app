package v0;

import f0.k;
import f0.l;
import h0.d;
import kotlinx.coroutines.internal.f;

public final class m0 {
    public static final String a(Object obj) {
        return obj.getClass().getSimpleName();
    }

    public static final String b(Object obj) {
        return Integer.toHexString(System.identityHashCode(obj));
    }

    public static final String c(d<?> dVar) {
        Object obj;
        if (dVar instanceof f) {
            return dVar.toString();
        }
        try {
            k.a aVar = k.f146d;
            obj = k.a(dVar + '@' + b(dVar));
        } catch (Throwable th) {
            k.a aVar2 = k.f146d;
            obj = k.a(l.a(th));
        }
        Throwable b2 = k.b(obj);
        String str = obj;
        if (b2 != null) {
            str = dVar.getClass().getName() + '@' + b(dVar);
        }
        return (String) str;
    }
}
