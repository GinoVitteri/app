package v0;

import h0.h;
import java.util.concurrent.Executor;

final class r0 implements Executor {

    /* renamed from: d  reason: collision with root package name */
    public final f0 f1125d;

    public void execute(Runnable runnable) {
        this.f1125d.g(h.f166d, runnable);
    }

    public String toString() {
        return this.f1125d.toString();
    }
}
