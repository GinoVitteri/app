package v0;

public interface x1 {
}
