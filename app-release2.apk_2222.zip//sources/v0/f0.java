package v0;

import h0.b;
import h0.d;
import h0.e;
import h0.g;
import kotlin.jvm.internal.j;
import kotlinx.coroutines.internal.f;
import o0.l;

public abstract class f0 extends h0.a implements e {

    /* renamed from: d  reason: collision with root package name */
    public static final a f1092d = new a((kotlin.jvm.internal.e) null);

    public static final class a extends b<e, f0> {

        /* renamed from: v0.f0$a$a  reason: collision with other inner class name */
        static final class C0026a extends j implements l<g.b, f0> {

            /* renamed from: d  reason: collision with root package name */
            public static final C0026a f1093d = new C0026a();

            C0026a() {
                super(1);
            }

            /* renamed from: a */
            public final f0 invoke(g.b bVar) {
                if (bVar instanceof f0) {
                    return (f0) bVar;
                }
                return null;
            }
        }

        private a() {
            super(e.f163a, C0026a.f1093d);
        }

        public /* synthetic */ a(kotlin.jvm.internal.e eVar) {
            this();
        }
    }

    public f0() {
        super(e.f163a);
    }

    public abstract void g(g gVar, Runnable runnable);

    public <E extends g.b> E get(g.c<E> cVar) {
        return e.a.a(this, cVar);
    }

    public boolean h(g gVar) {
        return true;
    }

    public final <T> d<T> j(d<? super T> dVar) {
        return new f(this, dVar);
    }

    public g minusKey(g.c<?> cVar) {
        return e.a.b(this, cVar);
    }

    public final void n(d<?> dVar) {
        ((f) dVar).r();
    }

    public String toString() {
        return m0.a(this) + '@' + m0.b(this);
    }
}
