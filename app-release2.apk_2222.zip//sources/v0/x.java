package v0;

public interface x extends k1 {
}
