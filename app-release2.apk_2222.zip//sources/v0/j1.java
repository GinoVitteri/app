package v0;

import f0.q;
import o0.l;

final class j1 extends q1 {

    /* renamed from: h  reason: collision with root package name */
    private final l<Throwable, q> f1101h;

    public j1(l<? super Throwable, q> lVar) {
        this.f1101h = lVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        y((Throwable) obj);
        return q.f152a;
    }

    public void y(Throwable th) {
        this.f1101h.invoke(th);
    }
}
