package v0;

import java.util.concurrent.locks.LockSupport;
import v0.w0;

public abstract class x0 extends v0 {
    /* access modifiers changed from: protected */
    public final void A() {
        Thread y2 = y();
        if (Thread.currentThread() != y2) {
            c.a();
            LockSupport.unpark(y2);
        }
    }

    /* access modifiers changed from: protected */
    public abstract Thread y();

    /* access modifiers changed from: protected */
    public final void z(long j2, w0.a aVar) {
        n0.f1117j.L(j2, aVar);
    }
}
