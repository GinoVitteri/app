package v0;

public interface t extends k1 {
    void l(y1 y1Var);
}
