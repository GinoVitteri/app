package v0;

import h0.g;
import o0.p;

final class e2 implements g.b, g.c<e2> {

    /* renamed from: d  reason: collision with root package name */
    public static final e2 f1090d = new e2();

    private e2() {
    }

    public <R> R fold(R r2, p<? super R, ? super g.b, ? extends R> pVar) {
        return g.b.a.a(this, r2, pVar);
    }

    public <E extends g.b> E get(g.c<E> cVar) {
        return g.b.a.b(this, cVar);
    }

    public g.c<?> getKey() {
        return this;
    }

    public g minusKey(g.c<?> cVar) {
        return g.b.a.c(this, cVar);
    }

    public g plus(g gVar) {
        return g.b.a.d(this, gVar);
    }
}
