package v0;

import h0.d;
import h0.g;
import kotlin.jvm.internal.i;
import o0.l;
import o0.p;

public abstract class a<T> extends r1 implements d<T>, i0 {

    /* renamed from: e  reason: collision with root package name */
    private final g f1076e;

    public a(g gVar, boolean z2, boolean z3) {
        super(z3);
        if (z2) {
            R((k1) gVar.get(k1.f1108c));
        }
        this.f1076e = gVar.plus(this);
    }

    /* access modifiers changed from: protected */
    public String B() {
        return i.j(m0.a(this), " was cancelled");
    }

    public final void Q(Throwable th) {
        h0.a(this.f1076e, th);
    }

    public String X() {
        String b2 = e0.b(this.f1076e);
        if (b2 == null) {
            return super.X();
        }
        return '\"' + b2 + "\":" + super.X();
    }

    public boolean b() {
        return super.b();
    }

    /* access modifiers changed from: protected */
    public final void c0(Object obj) {
        if (obj instanceof z) {
            z zVar = (z) obj;
            t0(zVar.f1169a, zVar.a());
            return;
        }
        u0(obj);
    }

    public final g getContext() {
        return this.f1076e;
    }

    public g h() {
        return this.f1076e;
    }

    public final void resumeWith(Object obj) {
        Object V = V(d0.d(obj, (l) null, 1, (Object) null));
        if (V != s1.f1141b) {
            s0(V);
        }
    }

    /* access modifiers changed from: protected */
    public void s0(Object obj) {
        w(obj);
    }

    /* access modifiers changed from: protected */
    public void t0(Throwable th, boolean z2) {
    }

    /* access modifiers changed from: protected */
    public void u0(T t2) {
    }

    public final <R> void v0(k0 k0Var, R r2, p<? super R, ? super d<? super T>, ? extends Object> pVar) {
        k0Var.b(pVar, r2, this);
    }
}
