package v0;

import h0.g;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import kotlinx.coroutines.internal.d;

public final class c1 extends b1 {

    /* renamed from: f  reason: collision with root package name */
    private final Executor f1083f;

    public c1(Executor executor) {
        this.f1083f = executor;
        d.a(o());
    }

    private final void i(g gVar, RejectedExecutionException rejectedExecutionException) {
        o1.c(gVar, a1.a("The task was rejected", rejectedExecutionException));
    }

    public void close() {
        Executor o2 = o();
        ExecutorService executorService = o2 instanceof ExecutorService ? (ExecutorService) o2 : null;
        if (executorService != null) {
            executorService.shutdown();
        }
    }

    public boolean equals(Object obj) {
        return (obj instanceof c1) && ((c1) obj).o() == o();
    }

    public void g(g gVar, Runnable runnable) {
        try {
            Executor o2 = o();
            c.a();
            o2.execute(runnable);
        } catch (RejectedExecutionException e2) {
            c.a();
            i(gVar, e2);
            s0.b().g(gVar, runnable);
        }
    }

    public int hashCode() {
        return System.identityHashCode(o());
    }

    public Executor o() {
        return this.f1083f;
    }

    public String toString() {
        return o().toString();
    }
}
