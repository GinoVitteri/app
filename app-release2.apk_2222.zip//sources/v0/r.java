package v0;

public interface r extends t0 {
    boolean d(Throwable th);

    k1 getParent();
}
