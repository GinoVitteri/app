package v0;

import f0.q;
import h0.d;
import o0.l;

public interface k<T> extends d<T> {

    public static final class a {
        public static /* synthetic */ Object a(k kVar, Object obj, Object obj2, int i2, Object obj3) {
            if (obj3 == null) {
                if ((i2 & 2) != 0) {
                    obj2 = null;
                }
                return kVar.d(obj, obj2);
            }
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: tryResume");
        }
    }

    void a(l<? super Throwable, q> lVar);

    Object d(T t2, Object obj);

    Object g(T t2, Object obj, l<? super Throwable, q> lVar);

    void i(T t2, l<? super Throwable, q> lVar);

    Object o(Throwable th);

    void q(Object obj);
}
